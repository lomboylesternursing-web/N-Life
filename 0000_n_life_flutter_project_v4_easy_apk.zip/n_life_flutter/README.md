# N-Life v4 Prototype

N-Life is a personal hospital duty companion for Android.

## Added in v4
- Official N-Life logo asset in splash, app header, and About page
- Fast Add Monthly Duty
- Fixed duty templates: AM, PM, Graveyard, 12H AM, 12H PM, OFF, Leave, Manual
- Monthly calendar view with duty labels
- Visual DTR Sheet table
- DTR filters: 1-15, 16-End, Whole Month
- Corrected paid-hours rule:
  - AM/PM/Graveyard = paid as 8 hours even if actual log is earlier/later
  - 12H duty = paid as 12 hours; 4 excess hours count toward additional day credit
- Editable DTR name and hospital name
- Export DTR PDF option
- Custom color theme and Light/Dark/System appearance
- Developer Credit page

## Developer Credit
Developed by Lester Andrei Lomboy, RN

Follow:
Instagram: @Itslester.l
Facebook: Lester Andrei Lomboy

Contact:
lomboylester.nursing@gmail.com

## GitHub APK Build
If you upload this ZIP to a GitHub repo that already has the builder workflow, run the workflow again.

For official app name and launcher icon, update your repo workflow using `GITHUB_WORKFLOW_BUILD_APK_V4.yml`.
