# N-Life v1.2 Update Patch

This update keeps the same Flutter Android package setup as the previous N-Life debug/update builds and is designed to install over v1.0/v1.1 when the same GitHub workflow/signing key is used.

## Added / Fixed

- Native Android notification permission request.
- Native duty reminder scheduling for duties with Reminder ON.
  - 12:00 AM reminder on duty date.
  - 5:00 AM reminder on duty date.
- Settings button: Enable Duty Notifications.
- Home-screen widget integration strengthened.
- Settings button: Add / Pin Duty Widget for supported launchers.
- Fast Add date picker changed from plain numbers to a calendar-style grid with weekdays.
- Version updated to N-Life v1.2.

## Important

Install this over the current app first. Do not uninstall if you want to preserve duty schedules and DTR logs.
