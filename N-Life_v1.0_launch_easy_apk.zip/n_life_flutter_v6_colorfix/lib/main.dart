import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = AppState();
  await state.load();
  runApp(NLifeApp(state: state));
}

const Color kDefaultPrimary = Color(0xFF0B1F3A);
const Color kSecondary = Color(0xFF123B6D);
const Color kAccent = Color(0xFF2F80ED);
const Color kLightBackground = Color(0xFFF5F7FA);
const Color kDarkBackground = Color(0xFF07111F);
const String kAppTagline = 'Schedule. Track. Manage. Thrive.';
const String kDeveloperName = 'Lester Andrei Lomboy, RN';

class NLifeApp extends StatelessWidget {
  const NLifeApp({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: state,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'N-Life',
          themeMode: state.themeMode,
          theme: buildTheme(state.primaryColor, Brightness.light),
          darkTheme: buildTheme(state.primaryColor, Brightness.dark),
          home: SplashScreen(state: state),
        );
      },
    );
  }
}

ThemeData buildTheme(Color primary, Brightness brightness) {
  final isDark = brightness == Brightness.dark;
  final background = isDark ? kDarkBackground : kLightBackground;
  final surface = isDark ? const Color(0xFF101827) : Colors.white;
  final onSurface = isDark ? const Color(0xFFE8EEF7) : const Color(0xFF1E293B);
  final onSurfaceVariant = isDark ? const Color(0xFFB8C4D6) : const Color(0xFF64748B);
  final schemePrimary = isDark ? const Color(0xFF60A5FA) : primary;
  return ThemeData(
    useMaterial3: true,
    brightness: brightness,
    colorScheme: ColorScheme.fromSeed(
      seedColor: primary,
      brightness: brightness,
      primary: schemePrimary,
      secondary: kAccent,
      surface: surface,
      onSurface: onSurface,
      onSurfaceVariant: onSurfaceVariant,
    ),
    scaffoldBackgroundColor: background,
    appBarTheme: AppBarTheme(
      backgroundColor: primary,
      foregroundColor: Colors.white,
      centerTitle: false,
      elevation: 0,
    ),
    drawerTheme: DrawerThemeData(backgroundColor: surface),
    textTheme: ThemeData(brightness: brightness).textTheme.apply(
      bodyColor: onSurface,
      displayColor: onSurface,
    ),
    iconTheme: IconThemeData(color: onSurfaceVariant),
    listTileTheme: ListTileThemeData(
      textColor: onSurface,
      iconColor: onSurfaceVariant,
      subtitleTextStyle: TextStyle(color: onSurfaceVariant, fontSize: 13),
    ),
    dataTableTheme: DataTableThemeData(
      headingTextStyle: TextStyle(color: onSurface, fontWeight: FontWeight.w900),
      dataTextStyle: TextStyle(color: onSurface),
    ),
    dropdownMenuTheme: DropdownMenuThemeData(textStyle: TextStyle(color: onSurface)),
    dialogTheme: DialogThemeData(
      backgroundColor: surface,
      titleTextStyle: TextStyle(color: onSurface, fontSize: 20, fontWeight: FontWeight.w900),
      contentTextStyle: TextStyle(color: onSurface, fontSize: 14),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: isDark ? const Color(0xFF172033) : const Color(0xFFEAF0F8),
      selectedColor: primary.withOpacity(isDark ? 0.45 : 0.18),
      labelStyle: TextStyle(color: onSurface),
      secondaryLabelStyle: TextStyle(color: onSurface),
      checkmarkColor: isDark ? Colors.white : primary,
      side: BorderSide(color: isDark ? Colors.white24 : Colors.black12),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((states) => states.contains(WidgetState.selected) ? Colors.white : onSurfaceVariant),
      trackColor: WidgetStateProperty.resolveWith((states) => states.contains(WidgetState.selected) ? primary.withOpacity(0.65) : onSurfaceVariant.withOpacity(0.30)),
    ),
    cardTheme: CardThemeData(
      color: surface,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: primary,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: isDark ? Colors.white : primary,
        side: BorderSide(color: isDark ? Colors.white70 : primary.withOpacity(0.70)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: isDark ? const Color(0xFF93C5FD) : primary),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: isDark ? const Color(0xFF172033) : Colors.white,
      labelStyle: TextStyle(color: onSurfaceVariant),
      floatingLabelStyle: TextStyle(color: isDark ? const Color(0xFF9CCBFF) : primary),
      hintStyle: TextStyle(color: onSurfaceVariant),
      prefixStyle: TextStyle(color: onSurface),
      suffixStyle: TextStyle(color: onSurface),
      helperStyle: TextStyle(color: onSurfaceVariant),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: isDark ? Colors.white24 : Colors.grey.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: isDark ? Colors.white24 : Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: primary, width: 1.6),
      ),
    ),
  );
}

class ShiftTemplate {
  const ShiftTemplate({
    required this.key,
    required this.label,
    this.startMinutes,
    this.endMinutes,
    this.description,
  });

  final String key;
  final String label;
  final int? startMinutes;
  final int? endMinutes;
  final String? description;

  bool get isOff => key == 'OFF' || key == 'LEAVE';
  bool get isTwelveHour => key == '12H_AM' || key == '12H_PM';
}

const List<ShiftTemplate> kShiftTemplates = [
  ShiftTemplate(key: 'AM', label: 'AM', startMinutes: 7 * 60, endMinutes: 15 * 60, description: '7:00 AM - 3:00 PM'),
  ShiftTemplate(key: 'PM', label: 'PM', startMinutes: 15 * 60, endMinutes: 23 * 60, description: '3:00 PM - 11:00 PM'),
  ShiftTemplate(key: 'GRAVEYARD', label: 'Graveyard', startMinutes: 23 * 60, endMinutes: 7 * 60, description: '11:00 PM - 7:00 AM'),
  ShiftTemplate(key: '12H_AM', label: '12H AM', startMinutes: 7 * 60, endMinutes: 19 * 60, description: '7:00 AM - 7:00 PM'),
  ShiftTemplate(key: '12H_PM', label: '12H PM', startMinutes: 19 * 60, endMinutes: 7 * 60, description: '7:00 PM - 7:00 AM'),
  ShiftTemplate(key: 'OFF', label: 'OFF', description: 'No duty'),
  ShiftTemplate(key: 'LEAVE', label: 'Leave', description: 'Leave'),
  ShiftTemplate(key: 'MANUAL', label: 'Manual', description: 'Custom duty'),
];

ShiftTemplate templateByKey(String key) {
  return kShiftTemplates.firstWhere(
    (template) => template.key == key,
    orElse: () => kShiftTemplates.first,
  );
}

Color dutyColorForKey(String key) {
  // Distinct duty colors for easier recognition in the monthly calendar.
  switch (key) {
    case 'AM':
      return const Color(0xFF2563EB); // Blue
    case 'PM':
      return const Color(0xFFDC2626); // Red
    case 'GRAVEYARD':
      return const Color(0xFF111827); // Near-black / night shade
    case '12H_AM':
      return const Color(0xFFF97316); // Orange
    case '12H_PM':
      return const Color(0xFF0891B2); // Cyan/teal
    case 'OFF':
      return const Color(0xFF64748B); // Slate gray
    case 'LEAVE':
      return const Color(0xFF16A34A); // Green
    case 'MANUAL':
      return const Color(0xFFA855F7); // Purple
    default:
      return kAccent;
  }
}

String calendarLabelForDuty(DutyItem duty) {
  switch (duty.templateKey) {
    case 'GRAVEYARD':
      return 'GY';
    case '12H_AM':
      return '12H AM';
    case '12H_PM':
      return '12H PM';
    case 'LEAVE':
      return 'Leave';
    default:
      return duty.label.trim().isEmpty ? templateByKey(duty.templateKey).label : duty.label;
  }
}

class DutyItem {
  DutyItem({
    required this.id,
    required this.date,
    required this.templateKey,
    required this.label,
    this.startMinutes,
    this.endMinutes,
    this.ward = '',
    this.notes = '',
    this.reminderOn = false,
  });

  final String id;
  final DateTime date;
  final String templateKey;
  final String label;
  final int? startMinutes;
  final int? endMinutes;
  final String ward;
  final String notes;
  final bool reminderOn;

  bool get isOff => templateKey == 'OFF' || templateKey == 'LEAVE';
  bool get isTwelveHour => templateKey == '12H_AM' || templateKey == '12H_PM';

  double get scheduledHours {
    if (startMinutes == null || endMinutes == null) return 0.0;
    var end = endMinutes!;
    if (end <= startMinutes!) end += 24 * 60;
    return (end - startMinutes!) / 60.0;
  }

  String get timeRange {
    if (isOff) return label;
    if (startMinutes == null || endMinutes == null) return 'Manual';
    return '${formatMinutes(startMinutes!)} - ${formatMinutes(endMinutes!)}';
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': DateFormat('yyyy-MM-dd').format(date),
        'templateKey': templateKey,
        'label': label,
        'startMinutes': startMinutes,
        'endMinutes': endMinutes,
        'ward': ward,
        'notes': notes,
        'reminderOn': reminderOn,
      };

  factory DutyItem.fromJson(Map<String, dynamic> json) {
    final templateKey = (json['templateKey'] ?? json['label'] ?? 'AM') as String;
    return DutyItem(
      id: json['id'] as String,
      date: DateTime.parse(json['date'] as String),
      templateKey: templateKey,
      label: (json['label'] ?? templateByKey(templateKey).label) as String,
      startMinutes: json['startMinutes'] as int?,
      endMinutes: json['endMinutes'] as int?,
      ward: (json['ward'] ?? '') as String,
      notes: (json['notes'] ?? '') as String,
      reminderOn: (json['reminderOn'] ?? false) as bool,
    );
  }
}

class DtrLog {
  DtrLog({
    required this.id,
    required this.date,
    this.timeIn,
    this.timeOut,
  });

  final String id;
  final DateTime date;
  DateTime? timeIn;
  DateTime? timeOut;

  double get actualHours {
    if (timeIn == null || timeOut == null) return 0.0;
    var out = timeOut!;
    if (out.isBefore(timeIn!)) out = out.add(const Duration(days: 1));
    final diff = out.difference(timeIn!);
    if (diff.isNegative) return 0.0;
    return diff.inMinutes / 60.0;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': DateFormat('yyyy-MM-dd').format(date),
        'timeIn': timeIn?.toIso8601String(),
        'timeOut': timeOut?.toIso8601String(),
      };

  factory DtrLog.fromJson(Map<String, dynamic> json) {
    return DtrLog(
      id: json['id'] as String,
      date: DateTime.parse(json['date'] as String),
      timeIn: json['timeIn'] == null ? null : DateTime.parse(json['timeIn'] as String),
      timeOut: json['timeOut'] == null ? null : DateTime.parse(json['timeOut'] as String),
    );
  }
}

enum DtrPeriod { firstHalf, secondHalf, wholeMonth }

extension DtrPeriodText on DtrPeriod {
  String get label {
    switch (this) {
      case DtrPeriod.firstHalf:
        return '1-15 Cut-off';
      case DtrPeriod.secondHalf:
        return '16-End Cut-off';
      case DtrPeriod.wholeMonth:
        return 'Whole Month';
    }
  }
}

class AppState extends ChangeNotifier {
  List<DutyItem> duties = [];
  List<DtrLog> logs = [];

  double dailyRate = 1165;
  double requiredHours = 8;

  String dtrName = 'Lester Andrei Lomboy, RN';
  String hospitalName = '';
  String position = 'Registered Nurse';
  String department = '';

  Color primaryColor = kDefaultPrimary;
  ThemeMode themeMode = ThemeMode.light;

  double get hourlyRate => requiredHours <= 0 ? 0.0 : dailyRate / requiredHours;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    dailyRate = prefs.getDouble('dailyRate') ?? 1165;
    requiredHours = prefs.getDouble('requiredHours') ?? 8;
    dtrName = prefs.getString('dtrName') ?? 'Lester Andrei Lomboy, RN';
    hospitalName = prefs.getString('hospitalName') ?? '';
    position = prefs.getString('position') ?? 'Registered Nurse';
    department = prefs.getString('department') ?? '';
    primaryColor = Color(prefs.getInt('primaryColor') ?? kDefaultPrimary.value);
    themeMode = ThemeMode.values[prefs.getInt('themeMode') ?? ThemeMode.light.index];

    final dutyRaw = prefs.getStringList('duties') ?? [];
    duties = dutyRaw.map((e) => DutyItem.fromJson(jsonDecode(e) as Map<String, dynamic>)).toList();
    duties.sort((a, b) => a.date.compareTo(b.date));

    final logRaw = prefs.getStringList('logs') ?? [];
    logs = logRaw.map((e) => DtrLog.fromJson(jsonDecode(e) as Map<String, dynamic>)).toList();
    logs.sort((a, b) => b.date.compareTo(a.date));
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('dailyRate', dailyRate);
    await prefs.setDouble('requiredHours', requiredHours);
    await prefs.setString('dtrName', dtrName);
    await prefs.setString('hospitalName', hospitalName);
    await prefs.setString('position', position);
    await prefs.setString('department', department);
    await prefs.setInt('primaryColor', primaryColor.value);
    await prefs.setInt('themeMode', themeMode.index);
    await prefs.setStringList('duties', duties.map((e) => jsonEncode(e.toJson())).toList());
    await prefs.setStringList('logs', logs.map((e) => jsonEncode(e.toJson())).toList());
  }

  DutyItem? dutyForDate(DateTime date) {
    for (final duty in duties) {
      if (isSameDate(duty.date, date)) return duty;
    }
    return null;
  }

  DtrLog? logForDate(DateTime date) {
    for (final log in logs) {
      if (isSameDate(log.date, date)) return log;
    }
    return null;
  }

  List<DutyItem> dutiesForMonth(DateTime month) {
    return duties.where((d) => d.date.year == month.year && d.date.month == month.month).toList()
      ..sort((a, b) => a.date.compareTo(b.date));
  }

  DtrLog? openLog() {
    final openLogs = logs.where((log) => log.timeIn != null && log.timeOut == null).toList()
      ..sort((a, b) => b.timeIn!.compareTo(a.timeIn!));
    return openLogs.isEmpty ? null : openLogs.first;
  }

  Future<void> timeInNow() async {
    final now = DateTime.now();
    var log = logForDate(now);
    if (log == null) {
      log = DtrLog(id: now.microsecondsSinceEpoch.toString(), date: dateOnly(now), timeIn: now);
      logs.add(log);
    } else {
      log.timeIn = now;
    }
    logs.sort((a, b) => b.date.compareTo(a.date));
    await save();
    notifyListeners();
  }

  Future<void> timeOutNow() async {
    final now = DateTime.now();
    var log = openLog() ?? logForDate(now);
    if (log == null) {
      log = DtrLog(id: now.microsecondsSinceEpoch.toString(), date: dateOnly(now), timeOut: now);
      logs.add(log);
    } else {
      log.timeOut = now;
    }
    logs.sort((a, b) => b.date.compareTo(a.date));
    await save();
    notifyListeners();
  }

  Future<void> addOrReplaceDuties(List<DutyItem> newDuties) async {
    final dates = newDuties.map((d) => DateFormat('yyyy-MM-dd').format(d.date)).toSet();
    duties.removeWhere((old) => dates.contains(DateFormat('yyyy-MM-dd').format(old.date)));
    duties.addAll(newDuties);
    duties.sort((a, b) => a.date.compareTo(b.date));
    await save();
    notifyListeners();
  }

  Future<void> deleteDuty(String id) async {
    duties.removeWhere((d) => d.id == id);
    await save();
    notifyListeners();
  }

  Future<void> addManualLog(DtrLog log) async {
    logs.removeWhere((e) => isSameDate(e.date, log.date));
    logs.add(log);
    logs.sort((a, b) => b.date.compareTo(a.date));
    await save();
    notifyListeners();
  }

  Future<void> deleteLog(String id) async {
    logs.removeWhere((l) => l.id == id);
    await save();
    notifyListeners();
  }

  Future<void> updateSettings({
    required double newDailyRate,
    required double newRequiredHours,
    required String newDtrName,
    required String newHospitalName,
    required String newPosition,
    required String newDepartment,
    required Color newPrimaryColor,
    required ThemeMode newThemeMode,
  }) async {
    dailyRate = newDailyRate;
    requiredHours = newRequiredHours;
    dtrName = newDtrName.trim().isEmpty ? 'N-Life User' : newDtrName.trim();
    hospitalName = newHospitalName.trim();
    position = newPosition.trim();
    department = newDepartment.trim();
    primaryColor = newPrimaryColor;
    themeMode = newThemeMode;
    await save();
    notifyListeners();
  }

  double paidHoursForDate(DateTime date) {
    final log = logForDate(date);
    return paidHoursForLog(date, log);
  }

  double paidHoursForLog(DateTime date, DtrLog? log) {
    if (log == null || log.actualHours <= 0) return 0.0;
    final duty = dutyForDate(date);
    final actual = log.actualHours;
    if (duty != null) {
      if (duty.isOff) return 0.0;
      if (duty.isTwelveHour) return 12.0;
      if (duty.templateKey == 'MANUAL') {
        if (duty.scheduledHours >= 11) return duty.scheduledHours;
        if (duty.scheduledHours > 0 && duty.scheduledHours < requiredHours) return duty.scheduledHours;
      }
      return requiredHours;
    }
    if (actual >= 11) return 12.0;
    return actual > requiredHours ? requiredHours : actual;
  }

  DtrTotals totalsFor(DateTime month, DtrPeriod period) {
    final dates = datesForPeriod(month, period);
    double actualHours = 0;
    double paidHours = 0;
    int actualDutyDays = 0;
    for (final date in dates) {
      final log = logForDate(date);
      final actual = log?.actualHours ?? 0.0;
      final paid = paidHoursForLog(date, log);
      actualHours += actual;
      paidHours += paid;
      if (paid > 0) actualDutyDays++;
    }
    final excessHours = dates.fold<double>(0.0, (sum, date) {
      final paid = paidHoursForDate(date);
      return sum + (paid > requiredHours ? paid - requiredHours : 0.0);
    });
    final equivalentPaidDays = requiredHours <= 0 ? 0.0 : paidHours / requiredHours;
    final additionalDayCredit = requiredHours <= 0 ? 0.0 : excessHours / requiredHours;
    return DtrTotals(
      actualHours: actualHours,
      paidHours: paidHours,
      actualDutyDays: actualDutyDays,
      excessHours: excessHours,
      additionalDayCredit: additionalDayCredit,
      equivalentPaidDays: equivalentPaidDays,
      estimatedSalary: equivalentPaidDays * dailyRate,
    );
  }

  String generateDtrSummaryText(DateTime month, DtrPeriod period) {
    final buffer = StringBuffer();
    final dates = datesForPeriod(month, period);
    final totals = totalsFor(month, period);
    buffer.writeln('N-Life DTR Summary');
    buffer.writeln('Name: $dtrName');
    if (hospitalName.trim().isNotEmpty) buffer.writeln('Hospital: $hospitalName');
    buffer.writeln('Period: ${periodTitle(month, period)}');
    buffer.writeln('');
    buffer.writeln('Date | Day | Duty | Time In | Time Out | Actual | Paid | Remarks');
    for (final date in dates) {
      final log = logForDate(date);
      final actual = log?.actualHours ?? 0.0;
      final paid = paidHoursForLog(date, log);
      buffer.writeln('${DateFormat('MMM d').format(date)} | ${DateFormat('EEE').format(date)} | ${dutyLabelForDate(date, log)} | ${formatDateTime(log?.timeIn)} | ${formatDateTime(log?.timeOut)} | ${hoursText(actual)} | ${hoursText(paid)} | ${remarksFor(date, log)}');
    }
    buffer.writeln('');
    buffer.writeln('Total Actual Hours: ${hoursText(totals.actualHours)}');
    buffer.writeln('Total Paid Hours: ${hoursText(totals.paidHours)}');
    buffer.writeln('Equivalent Paid Days: ${totals.equivalentPaidDays.toStringAsFixed(2)}');
    buffer.writeln('Estimated Salary: ${peso(totals.estimatedSalary)}');
    return buffer.toString();
  }

  String dutyLabelForDate(DateTime date, DtrLog? log) {
    final duty = dutyForDate(date);
    if (duty != null) {
      switch (duty.templateKey) {
        case '12H_AM':
          return '12H AM';
        case '12H_PM':
          return '12H PM';
        case 'GRAVEYARD':
          return 'Graveyard';
        case 'OFF':
          return 'OFF';
        case 'LEAVE':
          return 'Leave';
        default:
          return duty.label.trim().isEmpty ? templateByKey(duty.templateKey).label : duty.label;
      }
    }
    final actual = log?.actualHours ?? 0.0;
    if (actual >= 11) return '12H';
    if (actual > 0) return 'Duty';
    return 'OFF';
  }

  String remarksFor(DateTime date, DtrLog? log) {
    final duty = dutyForDate(date);
    if (duty?.templateKey == 'LEAVE') return 'Leave';
    if (duty?.templateKey == 'OFF') return 'OFF';
    if (log == null || log.actualHours <= 0) return duty == null ? 'OFF' : 'No DTR';
    final paid = paidHoursForLog(date, log);
    if (paid > requiredHours) return '+${hoursText(paid - requiredHours)} excess';
    return 'Regular';
  }
}

class DtrTotals {
  const DtrTotals({
    required this.actualHours,
    required this.paidHours,
    required this.actualDutyDays,
    required this.excessHours,
    required this.additionalDayCredit,
    required this.equivalentPaidDays,
    required this.estimatedSalary,
  });

  final double actualHours;
  final double paidHours;
  final int actualDutyDays;
  final double excessHours;
  final double additionalDayCredit;
  final double equivalentPaidDays;
  final double estimatedSalary;
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key, required this.state});

  final AppState state;

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 2100), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => MainShell(state: widget.state)));
    });
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [primary, kSecondary],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(26),
            child: Column(
              children: [
                const Spacer(),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(28),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.16), blurRadius: 30, offset: const Offset(0, 14))],
                  ),
                  child: Image.asset('assets/n_life_official_logo.png', width: 220),
                ),
                const SizedBox(height: 22),
                const Text('Your Duty Companion', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                const Text(kAppTagline, textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 13, letterSpacing: 1.5)),
                const SizedBox(height: 22),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: Colors.white.withOpacity(0.16)),
                  ),
                  child: Text('Developed by\n$kDeveloperName', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, height: 1.3)),
                ),
                const Spacer(),
                const Text('Hospital duty • DTR • Salary tracker', style: TextStyle(color: Colors.white60, fontSize: 12)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key, required this.state});

  final AppState state;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.state,
      builder: (context, _) {
        final pages = [
          HomePage(state: widget.state),
          CalendarPage(state: widget.state),
          DtrPage(state: widget.state),
          SalaryPage(state: widget.state),
          SettingsPage(state: widget.state),
        ];
        return Scaffold(
          drawer: AppDrawer(
            state: widget.state,
            onSelectPage: (index) {
              Navigator.of(context).pop();
              setState(() => selectedIndex = index);
            },
          ),
          appBar: AppBar(
            title: Row(
              children: [
                ClipRRect(borderRadius: BorderRadius.circular(9), child: Image.asset('assets/n_life_icon.png', width: 38, height: 38)),
                const SizedBox(width: 10),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('N-Life', style: TextStyle(fontWeight: FontWeight.w900)),
                    Text('Your Duty Companion', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w400)),
                  ],
                ),
              ],
            ),
          ),
          body: pages[selectedIndex],
          bottomNavigationBar: NavigationBar(
            selectedIndex: selectedIndex,
            onDestinationSelected: (i) => setState(() => selectedIndex = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
              NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Duty'),
              NavigationDestination(icon: Icon(Icons.assignment_outlined), selectedIcon: Icon(Icons.assignment), label: 'DTR'),
              NavigationDestination(icon: Icon(Icons.payments_outlined), selectedIcon: Icon(Icons.payments), label: 'Salary'),
              NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
            ],
          ),
        );
      },
    );
  }
}

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key, required this.state, required this.onSelectPage});

  final AppState state;
  final ValueChanged<int> onSelectPage;

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Drawer(
      child: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(gradient: LinearGradient(colors: [primary, kSecondary])),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(borderRadius: BorderRadius.circular(20), child: Image.asset('assets/n_life_icon.png', width: 74, height: 74)),
                  const SizedBox(height: 14),
                  const Text('N-Life', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  const Text(kAppTagline, style: TextStyle(color: Colors.white70, letterSpacing: 1.2)),
                ],
              ),
            ),
            ListTile(leading: const Icon(Icons.person_outline), title: const Text('Profile / DTR Info'), onTap: () => onSelectPage(4)),
            ListTile(leading: const Icon(Icons.calendar_month_outlined), title: const Text('Monthly Duty Planner'), onTap: () => onSelectPage(1)),
            ListTile(leading: const Icon(Icons.assignment_outlined), title: const Text('DTR Sheet'), onTap: () => onSelectPage(2)),
            ListTile(
              leading: const Icon(Icons.picture_as_pdf_outlined),
              title: const Text('Export DTR PDF'),
              onTap: () async {
                Navigator.of(context).pop();
                await showExportDtrDialog(context, state);
              },
            ),
            const Divider(),
            ListTile(leading: const Icon(Icons.settings_outlined), title: const Text('App Settings'), onTap: () => onSelectPage(4)),
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('About N-Life'),
              onTap: () {
                Navigator.of(context).pop();
                showAboutNLifeDialog(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.code),
              title: const Text('Developer Credit'),
              onTap: () {
                Navigator.of(context).pop();
                showDeveloperDialog(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    final tomorrow = today.add(const Duration(days: 1));
    final duty = state.dutyForDate(today);
    final tomorrowDuty = state.dutyForDate(tomorrow);
    final log = state.logForDate(today);
    final paidToday = state.paidHoursForLog(today, log);
    final totals = state.totalsFor(DateTime(today.year, today.month), today.day <= 15 ? DtrPeriod.firstHalf : DtrPeriod.secondHalf);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(title: greeting(), subtitle: DateFormat('EEEE, MMMM d, yyyy').format(today), icon: Icons.local_hospital),
        const SizedBox(height: 14),
        const SectionTitle(title: 'Today\'s Duty'),
        DutySummaryCard(duty: duty, emptyMessage: 'No duty set today.'),
        const SizedBox(height: 14),
        const SectionTitle(title: 'Tomorrow\'s Duty'),
        DutySummaryCard(duty: tomorrowDuty, emptyMessage: 'No duty set tomorrow.'),
        const SizedBox(height: 14),
        const SectionTitle(title: 'DTR Today'),
        NCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InfoRow(label: 'Time In', value: formatDateTime(log?.timeIn)),
              InfoRow(label: 'Time Out', value: formatDateTime(log?.timeOut)),
              InfoRow(label: 'Actual Hours', value: hoursText(log?.actualHours ?? 0.0)),
              InfoRow(label: 'Paid Credit', value: hoursText(paidToday)),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () async {
                        await state.timeInNow();
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Time In saved: ${DateFormat('h:mm a').format(DateTime.now())}')));
                        }
                      },
                      icon: const Icon(Icons.login),
                      label: const Text('TIME IN'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        await state.timeOutNow();
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Time Out saved: ${DateFormat('h:mm a').format(DateTime.now())}')));
                        }
                      },
                      icon: const Icon(Icons.logout),
                      label: const Text('TIME OUT'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const SectionTitle(title: 'Cut-off Salary Estimate'),
        NCard(
          child: Column(
            children: [
              InfoRow(label: 'Paid Hours', value: hoursText(totals.paidHours)),
              InfoRow(label: 'Equivalent Days', value: totals.equivalentPaidDays.toStringAsFixed(2)),
              InfoRow(label: 'Estimated Salary', value: peso(totals.estimatedSalary)),
            ],
          ),
        ),
      ],
    );
  }
}

class CalendarPage extends StatefulWidget {
  const CalendarPage({super.key, required this.state});

  final AppState state;

  @override
  State<CalendarPage> createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  late DateTime month;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    month = DateTime(now.year, now.month);
  }

  @override
  Widget build(BuildContext context) {
    final monthDuties = widget.state.dutiesForMonth(month);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(title: 'Duty Calendar', subtitle: 'Monthly schedule with duty labels.', icon: Icons.calendar_month),
        const SizedBox(height: 14),
        MonthSelector(
          month: month,
          onPrevious: () => setState(() => month = DateTime(month.year, month.month - 1)),
          onNext: () => setState(() => month = DateTime(month.year, month.month + 1)),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: () => showFastAddDutyDialog(context, widget.state, month),
                icon: const Icon(Icons.flash_on),
                label: const Text('Fast Add'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => showManualDutyDialog(context, widget.state, month),
                icon: const Icon(Icons.edit_calendar),
                label: const Text('Manual'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        MonthlyCalendarCard(state: widget.state, month: month),
        const SizedBox(height: 18),
        const SectionTitle(title: 'This Month Duties'),
        if (monthDuties.isEmpty) const EmptyCard(message: 'No duties added for this month yet.'),
        ...monthDuties.map((duty) => DutyTile(duty: duty, onDelete: () => widget.state.deleteDuty(duty.id))),
      ],
    );
  }
}

class MonthlyCalendarCard extends StatelessWidget {
  const MonthlyCalendarCard({super.key, required this.state, required this.month});

  final AppState state;
  final DateTime month;

  @override
  Widget build(BuildContext context) {
    final first = DateTime(month.year, month.month, 1);
    final last = DateTime(month.year, month.month + 1, 0);
    final leadingBlanks = first.weekday % 7;
    final totalCells = leadingBlanks + last.day;
    final rows = (totalCells / 7).ceil();
    final primary = Theme.of(context).colorScheme.primary;

    return NCard(
      child: Column(
        children: [
          Row(
            children: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
                .map((d) => Expanded(child: Center(child: Text(d, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)))))
                .toList(),
          ),
          const SizedBox(height: 8),
          ...List.generate(rows, (row) {
            return Row(
              children: List.generate(7, (col) {
                final cellIndex = row * 7 + col;
                final dayNumber = cellIndex - leadingBlanks + 1;
                if (dayNumber < 1 || dayNumber > last.day) return const Expanded(child: SizedBox(height: 72));
                final date = DateTime(month.year, month.month, dayNumber);
                final duty = state.dutyForDate(date);
                final label = duty == null ? '' : calendarLabelForDuty(duty);
                final dutyColor = duty == null ? null : dutyColorForKey(duty.templateKey);
                final isToday = isSameDate(date, DateTime.now());
                return Expanded(
                  child: InkWell(
                    onTap: () => showDutyDetails(context, state, date),
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      height: 72,
                      margin: const EdgeInsets.all(3),
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: isToday ? primary : (dutyColor?.withOpacity(0.45) ?? Colors.grey.withOpacity(0.18)), width: isToday ? 2 : 1),
                        color: duty == null ? null : dutyColor!.withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.22 : 0.10),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(dayNumber.toString(), style: TextStyle(fontWeight: FontWeight.w900, color: isToday ? primary : Theme.of(context).colorScheme.onSurface)),
                          const Spacer(),
                          if (label.isNotEmpty)
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
                              decoration: BoxDecoration(color: dutyColor, borderRadius: BorderRadius.circular(7)),
                              child: Text(label, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)),
                            )
                          else
                            Text('OFF', style: TextStyle(fontSize: 10, color: Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.70))),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            );
          }),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: kShiftTemplates.where((t) => t.key != 'MANUAL').map((template) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: dutyColorForKey(template.key).withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.28 : 0.12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: dutyColorForKey(template.key).withOpacity(0.45)),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Container(width: 8, height: 8, decoration: BoxDecoration(color: dutyColorForKey(template.key), shape: BoxShape.circle)),
                  const SizedBox(width: 5),
                  Text(template.label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.onSurface)),
                ]),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

class DtrPage extends StatefulWidget {
  const DtrPage({super.key, required this.state});

  final AppState state;

  @override
  State<DtrPage> createState() => _DtrPageState();
}

class _DtrPageState extends State<DtrPage> {
  late DateTime month;
  DtrPeriod period = DtrPeriod.firstHalf;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    month = DateTime(now.year, now.month);
    period = now.day <= 15 ? DtrPeriod.firstHalf : DtrPeriod.secondHalf;
  }

  @override
  Widget build(BuildContext context) {
    final dates = datesForPeriod(month, period);
    final totals = widget.state.totalsFor(month, period);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(title: 'DTR Sheet', subtitle: 'Visual DTR format for writing and checking.', icon: Icons.assignment),
        const SizedBox(height: 14),
        MonthSelector(
          month: month,
          onPrevious: () => setState(() => month = DateTime(month.year, month.month - 1)),
          onNext: () => setState(() => month = DateTime(month.year, month.month + 1)),
        ),
        const SizedBox(height: 10),
        SegmentedButton<DtrPeriod>(
          segments: const [
            ButtonSegment(value: DtrPeriod.firstHalf, label: Text('1-15')),
            ButtonSegment(value: DtrPeriod.secondHalf, label: Text('16-End')),
            ButtonSegment(value: DtrPeriod.wholeMonth, label: Text('Month')),
          ],
          selected: {period},
          onSelectionChanged: (set) => setState(() => period = set.first),
        ),
        const SizedBox(height: 12),
        Column(
          children: [
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => showManualLogDialog(context, widget.state),
                icon: const Icon(Icons.add),
                label: const Text('Add DTR'),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await Clipboard.setData(ClipboardData(text: widget.state.generateDtrSummaryText(month, period)));
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('DTR summary copied.')));
                    },
                    icon: const Icon(Icons.copy),
                    label: const Text('Copy Summary'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await Printing.layoutPdf(onLayout: (_) => buildDtrPdf(widget.state, month, period));
                    },
                    icon: const Icon(Icons.visibility_outlined),
                    label: const Text('View PDF'),
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 14),
        NCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Name: ${widget.state.dtrName}', style: const TextStyle(fontWeight: FontWeight.w900)),
              if (widget.state.hospitalName.trim().isNotEmpty) Text('Hospital: ${widget.state.hospitalName}'),
              Text('Period: ${periodTitle(month, period)}'),
              const Divider(height: 24),
              InfoRow(label: 'Total Paid Hours', value: hoursText(totals.paidHours)),
              InfoRow(label: 'Equivalent Paid Days', value: totals.equivalentPaidDays.toStringAsFixed(2)),
              InfoRow(label: 'Estimated Salary', value: peso(totals.estimatedSalary)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const SectionTitle(title: 'DTR Sheet Preview'),
        DtrSheetTable(state: widget.state, dates: dates),
        const SizedBox(height: 18),
        const SectionTitle(title: 'DTR Logs'),
        if (widget.state.logs.isEmpty) const EmptyCard(message: 'No DTR logs yet.'),
        ...widget.state.logs.map((log) => DtrTile(log: log, state: widget.state)),
      ],
    );
  }
}

class DtrSheetTable extends StatelessWidget {
  const DtrSheetTable({super.key, required this.state, required this.dates});

  final AppState state;
  final List<DateTime> dates;

  @override
  Widget build(BuildContext context) {
    return NCard(
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          headingRowHeight: 42,
          dataRowMinHeight: 48,
          dataRowMaxHeight: 56,
          columns: const [
            DataColumn(label: Text('Date')),
            DataColumn(label: Text('Day')),
            DataColumn(label: Text('Duty')),
            DataColumn(label: Text('In')),
            DataColumn(label: Text('Out')),
            DataColumn(label: Text('Actual')),
            DataColumn(label: Text('Paid')),
            DataColumn(label: Text('Remarks')),
          ],
          rows: dates.map((date) {
            final log = state.logForDate(date);
            return DataRow(cells: [
              DataCell(Text(DateFormat('MMM d').format(date))),
              DataCell(Text(DateFormat('EEE').format(date))),
              DataCell(Text(state.dutyLabelForDate(date, log))),
              DataCell(Text(formatDateTime(log?.timeIn))),
              DataCell(Text(formatDateTime(log?.timeOut))),
              DataCell(Text(hoursText(log?.actualHours ?? 0.0))),
              DataCell(Text(hoursText(state.paidHoursForLog(date, log)))),
              DataCell(Text(state.remarksFor(date, log))),
            ]);
          }).toList(),
        ),
      ),
    );
  }
}

class SalaryPage extends StatefulWidget {
  const SalaryPage({super.key, required this.state});

  final AppState state;

  @override
  State<SalaryPage> createState() => _SalaryPageState();
}

class _SalaryPageState extends State<SalaryPage> {
  late DateTime month;
  DtrPeriod period = DtrPeriod.firstHalf;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    month = DateTime(now.year, now.month);
    period = now.day <= 15 ? DtrPeriod.firstHalf : DtrPeriod.secondHalf;
  }

  @override
  Widget build(BuildContext context) {
    final totals = widget.state.totalsFor(month, period);
    final dates = datesForPeriod(month, period);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(title: 'Salary Summary', subtitle: periodTitle(month, period), icon: Icons.payments),
        const SizedBox(height: 14),
        MonthSelector(
          month: month,
          onPrevious: () => setState(() => month = DateTime(month.year, month.month - 1)),
          onNext: () => setState(() => month = DateTime(month.year, month.month + 1)),
        ),
        const SizedBox(height: 10),
        SegmentedButton<DtrPeriod>(
          segments: const [
            ButtonSegment(value: DtrPeriod.firstHalf, label: Text('1-15')),
            ButtonSegment(value: DtrPeriod.secondHalf, label: Text('16-End')),
            ButtonSegment(value: DtrPeriod.wholeMonth, label: Text('Month')),
          ],
          selected: {period},
          onSelectionChanged: (set) => setState(() => period = set.first),
        ),
        const SizedBox(height: 14),
        NCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Estimated Salary', style: TextStyle(fontSize: 14, color: Theme.of(context).colorScheme.onSurfaceVariant)),
              const SizedBox(height: 6),
              Text(peso(totals.estimatedSalary), style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF93C5FD) : Theme.of(context).colorScheme.primary)),
              const Divider(height: 28),
              InfoRow(label: 'Actual Duty Days', value: totals.actualDutyDays.toString()),
              InfoRow(label: 'Actual Hours', value: hoursText(totals.actualHours)),
              InfoRow(label: 'Paid Hours', value: hoursText(totals.paidHours)),
              InfoRow(label: 'Excess Hours from 12H', value: hoursText(totals.excessHours)),
              InfoRow(label: 'Additional Day Credit', value: totals.additionalDayCredit.toStringAsFixed(2)),
              InfoRow(label: 'Equivalent Paid Days', value: totals.equivalentPaidDays.toStringAsFixed(2)),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const SectionTitle(title: 'Breakdown'),
        ...dates.where((d) => widget.state.paidHoursForDate(d) > 0).map((date) {
          final log = widget.state.logForDate(date);
          final duty = widget.state.dutyForDate(date);
          final paid = widget.state.paidHoursForLog(date, log);
          return NCard(
            margin: const EdgeInsets.only(bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(DateFormat('MMM d, yyyy').format(date), style: const TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 4),
                    Text('${widget.state.dutyLabelForDate(date, log)} • Actual ${hoursText(log?.actualHours ?? 0.0)} • Paid ${hoursText(paid)}', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                  ]),
                ),
                Text(peso((paid / widget.state.requiredHours) * widget.state.dailyRate), style: TextStyle(fontWeight: FontWeight.w900, color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF93C5FD) : Theme.of(context).colorScheme.primary)),
              ],
            ),
          );
        }),
        if (dates.every((d) => widget.state.paidHoursForDate(d) <= 0)) const EmptyCard(message: 'No paid DTR entries for this period yet.'),
      ],
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key, required this.state});

  final AppState state;

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController dailyRateController;
  late final TextEditingController requiredHoursController;
  late final TextEditingController nameController;
  late final TextEditingController hospitalController;
  late final TextEditingController positionController;
  late final TextEditingController departmentController;
  late ThemeMode themeMode;
  late Color selectedColor;

  final colorOptions = const [
    ColorOption('Dark Blue', Color(0xFF0B1F3A)),
    ColorOption('Royal Blue', Color(0xFF1D4ED8)),
    ColorOption('Teal', Color(0xFF0F766E)),
    ColorOption('Green', Color(0xFF166534)),
    ColorOption('Purple', Color(0xFF581C87)),
    ColorOption('Black', Color(0xFF111827)),
  ];

  @override
  void initState() {
    super.initState();
    dailyRateController = TextEditingController(text: widget.state.dailyRate.toStringAsFixed(0));
    requiredHoursController = TextEditingController(text: widget.state.requiredHours.toStringAsFixed(0));
    nameController = TextEditingController(text: widget.state.dtrName);
    hospitalController = TextEditingController(text: widget.state.hospitalName);
    positionController = TextEditingController(text: widget.state.position);
    departmentController = TextEditingController(text: widget.state.department);
    themeMode = widget.state.themeMode;
    selectedColor = widget.state.primaryColor;
  }

  @override
  void dispose() {
    dailyRateController.dispose();
    requiredHoursController.dispose();
    nameController.dispose();
    hospitalController.dispose();
    positionController.dispose();
    departmentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(title: 'Settings', subtitle: 'Profile, salary rules, and app theme.', icon: Icons.settings),
        const SizedBox(height: 14),
        const SectionTitle(title: 'DTR Profile'),
        NCard(
          child: Column(children: [
            TextField(controller: nameController, decoration: const InputDecoration(labelText: 'DTR Name')),
            const SizedBox(height: 12),
            TextField(controller: hospitalController, decoration: const InputDecoration(labelText: 'Hospital Name')),
            const SizedBox(height: 12),
            TextField(controller: positionController, decoration: const InputDecoration(labelText: 'Position / Title')),
            const SizedBox(height: 12),
            TextField(controller: departmentController, decoration: const InputDecoration(labelText: 'Department / Ward')),
          ]),
        ),
        const SizedBox(height: 14),
        const SectionTitle(title: 'Salary Rules'),
        NCard(
          child: Column(children: [
            TextField(
              controller: dailyRateController,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
              decoration: const InputDecoration(labelText: 'Daily Rate', prefixText: '₱ '),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: requiredHoursController,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
              decoration: const InputDecoration(labelText: 'Required Hours per Duty'),
            ),
            const SizedBox(height: 10),
            Text('Rule: Normal AM/PM/Graveyard duty is paid as 8 hours. 12H duty is paid as 12 hours, with 4 excess hours credited toward additional days.', style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ]),
        ),
        const SizedBox(height: 14),
        const SectionTitle(title: 'App Theme'),
        NCard(
          child: Column(children: [
            DropdownButtonFormField<Color>(
              value: colorOptions.any((o) => o.color.value == selectedColor.value) ? selectedColor : kDefaultPrimary,
              decoration: const InputDecoration(labelText: 'Color Theme'),
              items: colorOptions.map((option) => DropdownMenuItem(value: option.color, child: Text(option.name))).toList(),
              onChanged: (value) => setState(() => selectedColor = value ?? kDefaultPrimary),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<ThemeMode>(
              value: themeMode,
              decoration: const InputDecoration(labelText: 'Appearance'),
              items: const [
                DropdownMenuItem(value: ThemeMode.system, child: Text('System Default')),
                DropdownMenuItem(value: ThemeMode.light, child: Text('Light Mode')),
                DropdownMenuItem(value: ThemeMode.dark, child: Text('Dark Mode')),
              ],
              onChanged: (value) => setState(() => themeMode = value ?? ThemeMode.system),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () async {
                  final dailyRate = double.tryParse(dailyRateController.text) ?? widget.state.dailyRate;
                  final requiredHours = double.tryParse(requiredHoursController.text) ?? widget.state.requiredHours;
                  await widget.state.updateSettings(
                    newDailyRate: dailyRate,
                    newRequiredHours: requiredHours,
                    newDtrName: nameController.text,
                    newHospitalName: hospitalController.text,
                    newPosition: positionController.text,
                    newDepartment: departmentController.text,
                    newPrimaryColor: selectedColor,
                    newThemeMode: themeMode,
                  );
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved.')));
                },
                icon: const Icon(Icons.save),
                label: const Text('Save Settings'),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 14),
        const SectionTitle(title: 'About N-Life'),
        NCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Image.asset('assets/n_life_official_logo.png', width: 180)),
            const SizedBox(height: 14),
            const Text('N-Life', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            const Text('N-Life is a personal hospital duty companion created to help nurses and healthcare workers schedule duties, track DTR logs, compute salary estimates, and prepare clean DTR summaries.'),
            const Divider(height: 24),
            Text('Developed by\n$kDeveloperName', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('Follow:\nInstagram: @Itslester.l\nFacebook: Lester Andrei Lomboy'),
            const SizedBox(height: 8),
            const Text('Contact:\nlomboylester.nursing@gmail.com'),
            const SizedBox(height: 8),
            const Text('Version: v5 prototype'),
          ]),
        ),
      ],
    );
  }
}

class ColorOption {
  const ColorOption(this.name, this.color);
  final String name;
  final Color color;
}

class HeaderCard extends StatelessWidget {
  const HeaderCard({super.key, required this.title, required this.subtitle, required this.icon});

  final String title;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(gradient: LinearGradient(colors: [primary, kSecondary]), borderRadius: BorderRadius.circular(24)),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(subtitle, style: const TextStyle(color: Colors.white70)),
        ])),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white.withOpacity(0.13), shape: BoxShape.circle), child: Icon(icon, color: Colors.white, size: 30)),
      ]),
    );
  }
}

class NCard extends StatelessWidget {
  const NCard({super.key, required this.child, this.margin});
  final Widget child;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return Card(margin: margin, child: Padding(padding: const EdgeInsets.all(16), child: child));
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({super.key, required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(title, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Theme.of(context).colorScheme.onSurface)),
    );
  }
}

class InfoRow extends StatelessWidget {
  const InfoRow({super.key, required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Expanded(child: Text(label, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant))),
        const SizedBox(width: 12),
        Flexible(child: Text(value, textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w900, color: Theme.of(context).colorScheme.onSurface))),
      ]),
    );
  }
}

class EmptyCard extends StatelessWidget {
  const EmptyCard({super.key, required this.message});
  final String message;

  @override
  Widget build(BuildContext context) => NCard(child: Text(message, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)));
}

class DutySummaryCard extends StatelessWidget {
  const DutySummaryCard({super.key, required this.duty, this.emptyMessage = 'No duty set.'});
  final DutyItem? duty;
  final String emptyMessage;

  @override
  Widget build(BuildContext context) {
    if (duty == null) return EmptyCard(message: emptyMessage);
    final color = dutyColorForKey(duty!.templateKey);
    return NCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Expanded(child: Text(duty!.label, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: color))),
        ]),
        const SizedBox(height: 8),
        InfoRow(label: 'Time', value: duty!.timeRange),
        if (duty!.ward.trim().isNotEmpty) InfoRow(label: 'Area / Ward', value: duty!.ward),
        if (duty!.notes.trim().isNotEmpty) InfoRow(label: 'Notes', value: duty!.notes),
      ]),
    );
  }
}

class DutyTile extends StatelessWidget {
  const DutyTile({super.key, required this.duty, required this.onDelete});
  final DutyItem duty;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return NCard(
      margin: const EdgeInsets.only(bottom: 10),
      child: Row(children: [
        Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(color: dutyColorForKey(duty.templateKey).withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.24 : 0.12), borderRadius: BorderRadius.circular(16)),
          child: Center(child: Text(DateFormat('d').format(duty.date), style: TextStyle(color: dutyColorForKey(duty.templateKey), fontSize: 20, fontWeight: FontWeight.w900))),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${DateFormat('MMM d, yyyy').format(duty.date)} • ${duty.label}', style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text('${duty.timeRange}${duty.ward.trim().isEmpty ? '' : ' • ${duty.ward}'}', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ])),
        IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_outline)),
      ]),
    );
  }
}

class DtrTile extends StatelessWidget {
  const DtrTile({super.key, required this.log, required this.state});
  final DtrLog log;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final paid = state.paidHoursForLog(log.date, log);
    return NCard(
      margin: const EdgeInsets.only(bottom: 10),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(DateFormat('MMM d, yyyy').format(log.date), style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text('IN ${formatDateTime(log.timeIn)} • OUT ${formatDateTime(log.timeOut)}', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
          const SizedBox(height: 4),
          Text('Actual ${hoursText(log.actualHours)} • Paid ${hoursText(paid)}', style: const TextStyle(fontWeight: FontWeight.w800)),
        ])),
        IconButton(onPressed: () => state.deleteLog(log.id), icon: const Icon(Icons.delete_outline)),
      ]),
    );
  }
}

class MonthSelector extends StatelessWidget {
  const MonthSelector({super.key, required this.month, required this.onPrevious, required this.onNext});
  final DateTime month;
  final VoidCallback onPrevious;
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) {
    return NCard(
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        IconButton(onPressed: onPrevious, icon: const Icon(Icons.chevron_left)),
        Text(DateFormat('MMMM yyyy').format(month), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        IconButton(onPressed: onNext, icon: const Icon(Icons.chevron_right)),
      ]),
    );
  }
}


List<DropdownMenuItem<String>> shiftDropdownItems() {
  return kShiftTemplates.map((template) {
    return DropdownMenuItem<String>(
      value: template.key,
      child: Text(template.label, overflow: TextOverflow.ellipsis, maxLines: 1),
    );
  }).toList();
}

String shiftDescription(String key) {
  final template = templateByKey(key);
  return template.description ?? 'Custom duty';
}

Future<void> showFastAddDutyDialog(BuildContext context, AppState state, DateTime month) async {
  String selectedKey = 'AM';
  final selectedDays = <int>{};
  final wardController = TextEditingController();
  final notesController = TextEditingController();
  final manualLabelController = TextEditingController(text: 'Manual');
  int? manualStart = 7 * 60;
  int? manualEnd = 15 * 60;
  bool reminderOn = false;
  final lastDay = DateTime(month.year, month.month + 1, 0).day;

  final dutiesToAdd = await showDialog<List<DutyItem>>(
    context: context,
    builder: (dialogContext) {
      return StatefulBuilder(builder: (context, setState) {
        final isManual = selectedKey == 'MANUAL';
        return AlertDialog(
          insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 24),
          title: const Text('Fast Add Monthly Duty'),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                DropdownButtonFormField<String>(
                  value: selectedKey,
                  decoration: const InputDecoration(labelText: 'Duty Type'),
                  isExpanded: true,
                  items: shiftDropdownItems(),
                  selectedItemBuilder: (context) => kShiftTemplates
                      .map((template) => Align(
                            alignment: Alignment.centerLeft,
                            child: Text(template.label, overflow: TextOverflow.ellipsis, maxLines: 1),
                          ))
                      .toList(),
                  onChanged: (value) => setState(() => selectedKey = value ?? 'AM'),
                ),
                const SizedBox(height: 6),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    shiftDescription(selectedKey),
                    style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
                  ),
                ),
                const SizedBox(height: 12),
                if (isManual) ...[
                  TextField(controller: manualLabelController, decoration: const InputDecoration(labelText: 'Manual Label')),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () async {
                          final picked = await pickMinutes(context, manualStart ?? 7 * 60);
                          if (picked != null) setState(() => manualStart = picked);
                        },
                        child: Text('Start: ${formatMinutes(manualStart ?? 0)}', overflow: TextOverflow.ellipsis),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () async {
                          final picked = await pickMinutes(context, manualEnd ?? 15 * 60);
                          if (picked != null) setState(() => manualEnd = picked);
                        },
                        child: Text('End: ${formatMinutes(manualEnd ?? 0)}', overflow: TextOverflow.ellipsis),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 10),
                ],
                TextField(controller: wardController, decoration: const InputDecoration(labelText: 'Ward / Area (optional)')),
                const SizedBox(height: 10),
                TextField(controller: notesController, decoration: const InputDecoration(labelText: 'Notes (optional)')),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: reminderOn,
                  onChanged: (value) => setState(() => reminderOn = value),
                  title: const Text('Reminder ON'),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Select dates in ${DateFormat('MMMM').format(month)}', style: const TextStyle(fontWeight: FontWeight.w900)),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: List.generate(lastDay, (index) {
                    final day = index + 1;
                    final selected = selectedDays.contains(day);
                    return FilterChip(
                      label: Text(day.toString()),
                      selected: selected,
                      onSelected: (value) => setState(() => value ? selectedDays.add(day) : selectedDays.remove(day)),
                    );
                  }),
                ),
              ]),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(dialogContext).pop(null), child: const Text('Cancel')),
            FilledButton(
              onPressed: selectedDays.isEmpty
                  ? null
                  : () {
                      final template = templateByKey(selectedKey);
                      final days = selectedDays.toList()..sort();
                      final duties = days.map((day) {
                        final date = DateTime(month.year, month.month, day);
                        return DutyItem(
                          id: '${DateFormat('yyyyMMdd').format(date)}-$selectedKey',
                          date: dateOnly(date),
                          templateKey: selectedKey,
                          label: isManual ? manualLabelController.text.trim().ifEmpty('Manual') : template.label,
                          startMinutes: isManual ? manualStart : template.startMinutes,
                          endMinutes: isManual ? manualEnd : template.endMinutes,
                          ward: wardController.text.trim(),
                          notes: notesController.text.trim(),
                          reminderOn: reminderOn,
                        );
                      }).toList();
                      Navigator.of(dialogContext).pop(duties);
                    },
              child: const Text('Apply'),
            ),
          ],
        );
      });
    },
  );

  wardController.dispose();
  notesController.dispose();
  manualLabelController.dispose();

  if (dutiesToAdd == null || dutiesToAdd.isEmpty) return;

  // Safety delay: let the dialog route fully dispose before the main app rebuilds.
  // This prevents Flutter inherited-widget disposal assertions on some Android builds
  // when applying several dates at once.
  await Future<void>.delayed(const Duration(milliseconds: 250));

  try {
    await state.addOrReplaceDuties(dutiesToAdd);
  } catch (_) {
    // Keep the app stable even if storage fails. The user can retry.
  }
}

Future<void> showManualDutyDialog(BuildContext context, AppState state, DateTime month) async {
  DateTime selectedDate = DateTime(month.year, month.month, DateTime.now().month == month.month ? DateTime.now().day : 1);
  String selectedKey = 'AM';
  final wardController = TextEditingController();
  final notesController = TextEditingController();
  final manualLabelController = TextEditingController(text: 'Manual');
  int? manualStart = 7 * 60;
  int? manualEnd = 15 * 60;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(builder: (context, setState) {
      final isManual = selectedKey == 'MANUAL';
      return AlertDialog(
        title: const Text('Add Duty'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Date'),
              subtitle: Text(DateFormat('MMM d, yyyy').format(selectedDate)),
              trailing: const Icon(Icons.calendar_month),
              onTap: () async {
                final picked = await showDatePicker(context: context, initialDate: selectedDate, firstDate: DateTime(2020), lastDate: DateTime(2100));
                if (picked != null) setState(() => selectedDate = picked);
              },
            ),
            DropdownButtonFormField<String>(
              value: selectedKey,
              decoration: const InputDecoration(labelText: 'Duty Type'),
              isExpanded: true,
              items: shiftDropdownItems(),
              selectedItemBuilder: (context) => kShiftTemplates.map((template) => Align(alignment: Alignment.centerLeft, child: Text(template.label, overflow: TextOverflow.ellipsis))).toList(),
              onChanged: (value) => setState(() => selectedKey = value ?? 'AM'),
            ),
            const SizedBox(height: 6),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(shiftDescription(selectedKey), style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ),
            const SizedBox(height: 12),
            if (isManual) ...[
              TextField(controller: manualLabelController, decoration: const InputDecoration(labelText: 'Manual Label')),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: OutlinedButton(onPressed: () async { final picked = await pickMinutes(context, manualStart ?? 7 * 60); if (picked != null) setState(() => manualStart = picked); }, child: Text('Start: ${formatMinutes(manualStart ?? 0)}'))),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton(onPressed: () async { final picked = await pickMinutes(context, manualEnd ?? 15 * 60); if (picked != null) setState(() => manualEnd = picked); }, child: Text('End: ${formatMinutes(manualEnd ?? 0)}'))),
              ]),
              const SizedBox(height: 10),
            ],
            TextField(controller: wardController, decoration: const InputDecoration(labelText: 'Ward / Area')),
            const SizedBox(height: 10),
            TextField(controller: notesController, decoration: const InputDecoration(labelText: 'Notes')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final template = templateByKey(selectedKey);
              await state.addOrReplaceDuties([
                DutyItem(
                  id: DateTime.now().microsecondsSinceEpoch.toString(),
                  date: dateOnly(selectedDate),
                  templateKey: selectedKey,
                  label: isManual ? manualLabelController.text.trim().ifEmpty('Manual') : template.label,
                  startMinutes: isManual ? manualStart : template.startMinutes,
                  endMinutes: isManual ? manualEnd : template.endMinutes,
                  ward: wardController.text,
                  notes: notesController.text,
                ),
              ]);
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            child: const Text('Save'),
          ),
        ],
      );
    }),
  );
  wardController.dispose();
  notesController.dispose();
  manualLabelController.dispose();
}

Future<void> showManualLogDialog(BuildContext context, AppState state) async {
  DateTime selectedDate = DateTime.now();
  int timeIn = 7 * 60;
  int timeOut = 15 * 60;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(builder: (context, setState) {
      return AlertDialog(
        title: const Text('Add Manual DTR'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Date'),
            subtitle: Text(DateFormat('MMM d, yyyy').format(selectedDate)),
            trailing: const Icon(Icons.calendar_month),
            onTap: () async {
              final picked = await showDatePicker(context: context, initialDate: selectedDate, firstDate: DateTime(2020), lastDate: DateTime(2100));
              if (picked != null) setState(() => selectedDate = picked);
            },
          ),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: () async { final picked = await pickMinutes(context, timeIn); if (picked != null) setState(() => timeIn = picked); }, child: Text('In: ${formatMinutes(timeIn)}'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton(onPressed: () async { final picked = await pickMinutes(context, timeOut); if (picked != null) setState(() => timeOut = picked); }, child: Text('Out: ${formatMinutes(timeOut)}'))),
          ]),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final date = dateOnly(selectedDate);
              var outDate = date;
              if (timeOut <= timeIn) outDate = outDate.add(const Duration(days: 1));
              final log = DtrLog(
                id: DateTime.now().microsecondsSinceEpoch.toString(),
                date: date,
                timeIn: DateTime(date.year, date.month, date.day, timeIn ~/ 60, timeIn % 60),
                timeOut: DateTime(outDate.year, outDate.month, outDate.day, timeOut ~/ 60, timeOut % 60),
              );
              await state.addManualLog(log);
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            child: const Text('Save'),
          ),
        ],
      );
    }),
  );
}

Future<int?> pickMinutes(BuildContext context, int initialMinutes) async {
  final picked = await showTimePicker(
    context: context,
    initialTime: TimeOfDay(hour: (initialMinutes ~/ 60) % 24, minute: initialMinutes % 60),
  );
  if (picked == null) return null;
  return picked.hour * 60 + picked.minute;
}

void showDutyDetails(BuildContext context, AppState state, DateTime date) {
  final duty = state.dutyForDate(date);
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(DateFormat('MMM d, yyyy').format(date)),
      content: duty == null
          ? const Text('No duty set. This day will show as OFF in DTR summary.')
          : Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(duty.label, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
              const SizedBox(height: 8),
              Text('Time: ${duty.timeRange}'),
              if (duty.ward.trim().isNotEmpty) Text('Ward: ${duty.ward}'),
              if (duty.notes.trim().isNotEmpty) Text('Notes: ${duty.notes}'),
            ]),
      actions: [
        if (duty != null) TextButton(onPressed: () async { await state.deleteDuty(duty.id); if (context.mounted) Navigator.pop(context); }, child: const Text('Delete')),
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
      ],
    ),
  );
}

Future<void> showExportDtrDialog(BuildContext context, AppState state) async {
  final now = DateTime.now();
  DateTime month = DateTime(now.year, now.month);
  DtrPeriod period = now.day <= 15 ? DtrPeriod.firstHalf : DtrPeriod.secondHalf;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(builder: (context, setState) {
      return AlertDialog(
        title: const Text('Export DTR PDF'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          MonthSelector(month: month, onPrevious: () => setState(() => month = DateTime(month.year, month.month - 1)), onNext: () => setState(() => month = DateTime(month.year, month.month + 1))),
          const SizedBox(height: 12),
          DropdownButtonFormField<DtrPeriod>(
            value: period,
            decoration: const InputDecoration(labelText: 'Period'),
            items: DtrPeriod.values.map((p) => DropdownMenuItem(value: p, child: Text(p.label))).toList(),
            onChanged: (value) => setState(() => period = value ?? DtrPeriod.firstHalf),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton.icon(
            onPressed: () async {
              final pdfBytes = await buildDtrPdf(state, month, period);
              await Printing.sharePdf(bytes: pdfBytes, filename: 'N-Life-DTR-${DateFormat('yyyy-MM').format(month)}-${period.name}.pdf');
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            icon: const Icon(Icons.picture_as_pdf),
            label: const Text('Export'),
          ),
        ],
      );
    }),
  );
}

Future<Uint8List> buildDtrPdf(AppState state, DateTime month, DtrPeriod period) async {
  final pdf = pw.Document();
  final dates = datesForPeriod(month, period);
  final totals = state.totalsFor(month, period);
  final data = dates.map((date) {
    final log = state.logForDate(date);
    return [
      DateFormat('MMM d').format(date),
      DateFormat('EEE').format(date),
      state.dutyLabelForDate(date, log),
      formatDateTime(log?.timeIn),
      formatDateTime(log?.timeOut),
      hoursText(log?.actualHours ?? 0.0),
      hoursText(state.paidHoursForLog(date, log)),
      state.remarksFor(date, log),
    ];
  }).toList();

  pdf.addPage(
    pw.MultiPage(
      build: (context) => [
        pw.Text('N-Life DTR Summary', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        pw.Text('Name: ${state.dtrName}'),
        if (state.hospitalName.trim().isNotEmpty) pw.Text('Hospital: ${state.hospitalName}'),
        if (state.position.trim().isNotEmpty) pw.Text('Position: ${state.position}'),
        if (state.department.trim().isNotEmpty) pw.Text('Department/Ward: ${state.department}'),
        pw.Text('Period: ${periodTitle(month, period)}'),
        pw.SizedBox(height: 16),
        pw.Table.fromTextArray(
          headers: ['Date', 'Day', 'Duty', 'In', 'Out', 'Actual', 'Paid', 'Remarks'],
          data: data,
          headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
          cellStyle: pw.TextStyle(fontSize: 9),
        ),
        pw.SizedBox(height: 16),
        pw.Text('Total Actual Hours: ${hoursText(totals.actualHours)}'),
        pw.Text('Total Paid Hours: ${hoursText(totals.paidHours)}'),
        pw.Text('Equivalent Paid Days: ${totals.equivalentPaidDays.toStringAsFixed(2)}'),
        pw.Text('Estimated Salary: ${pdfMoney(totals.estimatedSalary)}'),
        pw.SizedBox(height: 20),
        pw.Text('Generated by N-Life - Developed by $kDeveloperName', style: pw.TextStyle(fontSize: 9)),
      ],
    ),
  );
  return pdf.save();
}

void showAboutNLifeDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('About N-Life'),
      content: const SingleChildScrollView(
        child: Text('N-Life is a personal hospital duty companion created for duty scheduling, DTR tracking, salary estimates, and printable DTR summaries. It is designed for nurses and healthcare workers who want a simple, organized, and professional way to manage duty life.'),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
    ),
  );
}

void showDeveloperDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Developer Credit'),
      content: const Text('Developed by\nLester Andrei Lomboy, RN\n\nFollow:\nInstagram: @Itslester.l\nFacebook: Lester Andrei Lomboy\n\nContact:\nlomboylester.nursing@gmail.com'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
    ),
  );
}

DateTime dateOnly(DateTime date) => DateTime(date.year, date.month, date.day);

bool isSameDate(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

String formatMinutes(int minutes) {
  final hour = (minutes ~/ 60) % 24;
  final minute = minutes % 60;
  final date = DateTime(2020, 1, 1, hour, minute);
  return DateFormat('h:mm a').format(date);
}

String formatDateTime(DateTime? dateTime) {
  if (dateTime == null) return '--';
  return DateFormat('h:mm a').format(dateTime);
}

String hoursText(double hours) {
  if (hours <= 0) return '--';
  final whole = hours.floor();
  final minutes = ((hours - whole) * 60).round();
  if (minutes == 0) return '$whole hrs';
  return '$whole hrs $minutes mins';
}


String pdfMoney(double value) {
  final formatter = NumberFormat.currency(locale: 'en_PH', symbol: 'PHP ', decimalDigits: 2);
  return formatter.format(value);
}

String peso(double value) {
  final formatter = NumberFormat.currency(locale: 'en_PH', symbol: '₱', decimalDigits: 2);
  return formatter.format(value);
}

String greeting() {
  final hour = DateTime.now().hour;
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

List<DateTime> datesForPeriod(DateTime month, DtrPeriod period) {
  final last = DateTime(month.year, month.month + 1, 0).day;
  final startDay = period == DtrPeriod.secondHalf ? 16 : 1;
  final endDay = period == DtrPeriod.firstHalf ? 15 : last;
  return List.generate(endDay - startDay + 1, (i) => DateTime(month.year, month.month, startDay + i));
}

String periodTitle(DateTime month, DtrPeriod period) {
  final dates = datesForPeriod(month, period);
  return '${DateFormat('MMM d, yyyy').format(dates.first)} - ${DateFormat('MMM d, yyyy').format(dates.last)}';
}

extension StringFallback on String {
  String ifEmpty(String fallback) => trim().isEmpty ? fallback : trim();
}
