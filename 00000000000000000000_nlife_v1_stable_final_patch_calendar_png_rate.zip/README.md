# N-Life v1.0 Stable Final Patch

Includes:
- Default daily rate set to PHP 1,165.46 for new installs.
- Daily/Hourly rate mode retained.
- Duty reminders are ON by default on new Fast Add and Manual duties.
- Graphic Duty Calendar print layout.
- Calendar range option: 1-15, 16-End, Whole Month.
- Save Calendar as PNG through Android share/save sheet.
- View/Print Calendar retained.
- Official N-Life branding retained.

Important:
- Real Android scheduled push notifications and true Android home-screen widget integration require native Android/plugin setup. This patch keeps reminder toggles ON by default, but background notifications/widgets should be treated as the next native feature update.
