# N-Life v1.3 Update Patch

Fixes:
- Native Android notification permission + test notification bridge
- Native home-screen widget integration support
- Fast Add Monthly Duty calendar-view selector
- More stable Backup / Restore parsing

Important: replace the GitHub workflow with the included v1.3 workflow so Android native notifications and widgets are applied during APK build.
