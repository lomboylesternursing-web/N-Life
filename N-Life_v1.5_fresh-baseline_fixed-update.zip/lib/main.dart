import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = AppState();
  await state.load();
  runApp(NLifeApp(state: state));
}

const Color kDefaultPrimary = Color(0xFF0B1F3A);
const Color kSecondary = Color(0xFF123B6D);
const Color kAccent = Color(0xFF2F80ED);
const Color kLightBackground = Color(0xFFF5F7FA);
const Color kDarkBackground = Color(0xFF07111F);
const String kAppTagline = 'Schedule. Track. Manage. Thrive.';
const String kDeveloperName = 'Lester Andrei Lomboy, RN';
const String kAppVersion = 'v1.5.0';
const MethodChannel kWidgetChannel = MethodChannel('nlife/widget');


enum DtrPeriod {
  firstHalf,
  secondHalf,
  wholeMonth,
}

extension DtrPeriodLabel on DtrPeriod {
  String get label {
    switch (this) {
      case DtrPeriod.firstHalf:
        return '1-15';
      case DtrPeriod.secondHalf:
        return '16-End';
      case DtrPeriod.wholeMonth:
        return 'Whole Month';
    }
  }
}

class NLifeApp extends StatelessWidget {
  const NLifeApp({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: state,
      builder: (context, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'N-Life',
          themeMode: state.themeMode,
          theme: buildTheme(state.primaryColor, Brightness.light),
          darkTheme: buildTheme(state.primaryColor, Brightness.dark),
          home: SplashScreen(state: state),
        );
      },
    );
  }
}

ThemeData buildTheme(Color primary, Brightness brightness) {
  final isDark = brightness == Brightness.dark;
  final background = isDark ? kDarkBackground : kLightBackground;
  final surface = isDark ? const Color(0xFF101827) : Colors.white;
  final onSurface = isDark ? const Color(0xFFE8EEF7) : const Color(0xFF1E293B);
  final onSurfaceVariant = isDark ? const Color(0xFFB8C4D6) : const Color(0xFF64748B);
  final schemePrimary = isDark ? const Color(0xFF60A5FA) : primary;
  return ThemeData(
    useMaterial3: true,
    brightness: brightness,
    colorScheme: ColorScheme.fromSeed(
      seedColor: primary,
      brightness: brightness,
      primary: schemePrimary,
      secondary: kAccent,
      surface: surface,
      onSurface: onSurface,
      onSurfaceVariant: onSurfaceVariant,
    ),
    scaffoldBackgroundColor: background,
    appBarTheme: AppBarTheme(
      backgroundColor: primary,
      foregroundColor: Colors.white,
      centerTitle: false,
      elevation: 0,
    ),
    drawerTheme: DrawerThemeData(backgroundColor: surface),
    textTheme: ThemeData(brightness: brightness).textTheme.apply(
      bodyColor: onSurface,
      displayColor: onSurface,
    ),
    iconTheme: IconThemeData(color: onSurfaceVariant),
    listTileTheme: ListTileThemeData(
      textColor: onSurface,
      iconColor: onSurfaceVariant,
      subtitleTextStyle: TextStyle(color: onSurfaceVariant, fontSize: 13),
    ),
    dataTableTheme: DataTableThemeData(
      headingTextStyle: TextStyle(color: onSurface, fontWeight: FontWeight.w900),
      dataTextStyle: TextStyle(color: onSurface),
    ),
    dropdownMenuTheme: DropdownMenuThemeData(textStyle: TextStyle(color: onSurface)),
    dialogTheme: DialogThemeData(
      backgroundColor: surface,
      titleTextStyle: TextStyle(color: onSurface, fontSize: 20, fontWeight: FontWeight.w900),
      contentTextStyle: TextStyle(color: onSurface, fontSize: 14),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: isDark ? const Color(0xFF172033) : const Color(0xFFEAF0F8),
      selectedColor: primary.withOpacity(isDark ? 0.45 : 0.18),
      labelStyle: TextStyle(color: onSurface),
      secondaryLabelStyle: TextStyle(color: onSurface),
      checkmarkColor: isDark ? Colors.white : primary,
      side: BorderSide(color: isDark ? Colors.white24 : Colors.black12),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((states) => states.contains(WidgetState.selected) ? Colors.white : onSurfaceVariant),
      trackColor: WidgetStateProperty.resolveWith((states) => states.contains(WidgetState.selected) ? primary.withOpacity(0.65) : onSurfaceVariant.withOpacity(0.30)),
    ),
    cardTheme: CardThemeData(
      color: surface,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: primary,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: isDark ? Colors.white : primary,
        side: BorderSide(color: isDark ? Colors.white70 : primary.withOpacity(0.70)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: isDark ? const Color(0xFF93C5FD) : primary),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: isDark ? const Color(0xFF172033) : Colors.white,
      labelStyle: TextStyle(color: onSurfaceVariant),
      floatingLabelStyle: TextStyle(color: isDark ? const Color(0xFF9CCBFF) : primary),
      hintStyle: TextStyle(color: onSurfaceVariant),
      prefixStyle: TextStyle(color: onSurface),
      suffixStyle: TextStyle(color: onSurface),
      helperStyle: TextStyle(color: onSurfaceVariant),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: isDark ? Colors.white24 : Colors.grey.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: isDark ? Colors.white24 : Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: primary, width: 1.6),
      ),
    ),
  );
}

class ShiftTemplate {
  const ShiftTemplate({
    required this.key,
    required this.label,
    this.startMinutes,
    this.endMinutes,
    this.description,
  });

  final String key;
  final String label;
  final int? startMinutes;
  final int? endMinutes;
  final String? description;

  bool get isOff => key == 'OFF' || key == 'LEAVE';
  bool get isTwelveHour => key == '12H_AM' || key == '12H_PM';
}

const List<ShiftTemplate> kShiftTemplates = [
  ShiftTemplate(key: 'AM', label: 'AM', startMinutes: 7 * 60, endMinutes: 15 * 60, description: '7:00 AM - 3:00 PM'),
  ShiftTemplate(key: 'PM', label: 'PM', startMinutes: 15 * 60, endMinutes: 23 * 60, description: '3:00 PM - 11:00 PM'),
  ShiftTemplate(key: 'GRAVEYARD', label: 'Graveyard', startMinutes: 23 * 60, endMinutes: 7 * 60, description: '11:00 PM - 7:00 AM'),
  ShiftTemplate(key: '12H_AM', label: '12H AM', startMinutes: 7 * 60, endMinutes: 19 * 60, description: '7:00 AM - 7:00 PM'),
  ShiftTemplate(key: '12H_PM', label: '12H PM', startMinutes: 19 * 60, endMinutes: 7 * 60, description: '7:00 PM - 7:00 AM'),
  ShiftTemplate(key: 'OFF', label: 'OFF', description: 'No duty'),
  ShiftTemplate(key: 'LEAVE', label: 'Leave', description: 'Leave'),
  ShiftTemplate(key: 'MANUAL', label: 'Manual', description: 'Custom duty'),
];

ShiftTemplate templateByKey(String key) {
  return kShiftTemplates.firstWhere(
    (template) => template.key == key,
    orElse: () => kShiftTemplates.first,
  );
}

Color dutyColorForKey(String key) {
  // High-contrast duty colors for launch v1.0.
  // These are intentionally very different so AM, Graveyard, and 12H AM are not confusing.
  switch (key) {
    case 'AM':
      return const Color(0xFF0EA5E9); // Sky blue
    case 'PM':
      return const Color(0xFFEF4444); // Red
    case 'GRAVEYARD':
      return const Color(0xFF6D28D9); // Deep purple / night shift
    case '12H_AM':
      return const Color(0xFFF97316); // Orange
    case '12H_PM':
      return const Color(0xFF14B8A6); // Teal
    case 'OFF':
      return const Color(0xFF64748B); // Slate gray
    case 'LEAVE':
      return const Color(0xFF22C55E); // Green
    case 'MANUAL':
      return const Color(0xFFA855F7); // Purple
    default:
      return kAccent;
  }
}

String calendarLabelForDuty(DutyItem duty) {
  switch (duty.templateKey) {
    case 'GRAVEYARD':
      return 'GY';
    case '12H_AM':
      return '12H AM';
    case '12H_PM':
      return '12H PM';
    case 'LEAVE':
      return 'Leave';
    default:
      return duty.label.trim().isEmpty ? templateByKey(duty.templateKey).label : duty.label;
  }
}


String cleanBackupInput(String raw) {
  var cleaned = raw.trim();
  if (cleaned.startsWith('```')) {
    cleaned = cleaned
        .split('\n')
        .where((line) => !line.trim().startsWith('```'))
        .join('\n')
        .trim();
  }
  final first = cleaned.indexOf('{');
  final last = cleaned.lastIndexOf('}');
  if (first >= 0 && last > first) cleaned = cleaned.substring(first, last + 1);
  return cleaned;
}

int? intFromJsonValue(dynamic value) {
  if (value == null) return null;
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse(value.toString());
}

double? doubleFromJsonValue(dynamic value) {
  if (value == null) return null;
  if (value is num) return value.toDouble();
  final text = value.toString().trim().replaceAll(',', '');
  return double.tryParse(text);
}

String? stringFromJsonValue(dynamic value) {
  if (value == null) return null;
  return value.toString();
}

bool boolFromJsonValue(dynamic value, {bool fallback = true}) {
  if (value is bool) return value;
  if (value is num) return value != 0;
  if (value is String) {
    final v = value.toLowerCase().trim();
    if (v == 'true' || v == 'yes' || v == '1') return true;
    if (v == 'false' || v == 'no' || v == '0') return false;
  }
  return fallback;
}

DateTime dateFromJsonValue(dynamic value) {
  final parsed = DateTime.tryParse(value?.toString() ?? '');
  return parsed == null ? dateOnly(DateTime.now()) : dateOnly(parsed);
}

class DutyItem {
  DutyItem({
    required this.id,
    required this.date,
    required this.templateKey,
    required this.label,
    this.startMinutes,
    this.endMinutes,
    this.ward = '',
    this.notes = '',
    this.reminderOn = true,
  });

  final String id;
  final DateTime date;
  final String templateKey;
  final String label;
  final int? startMinutes;
  final int? endMinutes;
  final String ward;
  final String notes;
  final bool reminderOn;

  bool get isOff => templateKey == 'OFF' || templateKey == 'LEAVE';
  bool get isTwelveHour => templateKey == '12H_AM' || templateKey == '12H_PM';

  double get scheduledHours {
    if (startMinutes == null || endMinutes == null) return 0.0;
    var end = endMinutes!;
    if (end <= startMinutes!) end += 24 * 60;
    return (end - startMinutes!) / 60.0;
  }

  String get timeRange {
    if (isOff) return label;
    if (startMinutes == null || endMinutes == null) return 'Manual';
    return '${formatMinutes(startMinutes!)} - ${formatMinutes(endMinutes!)}';
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': DateFormat('yyyy-MM-dd').format(date),
        'templateKey': templateKey,
        'label': label,
        'startMinutes': startMinutes,
        'endMinutes': endMinutes,
        'ward': ward,
        'notes': notes,
        'reminderOn': reminderOn,
      };

  factory DutyItem.fromJson(Map<String, dynamic> json) {
    final templateKey = (json['templateKey'] ?? json['label'] ?? 'AM').toString();
    final parsedDate = dateFromJsonValue(json['date']);
    return DutyItem(
      id: (json['id'] ?? '${DateFormat('yyyyMMdd').format(parsedDate)}-$templateKey').toString(),
      date: parsedDate,
      templateKey: templateKey,
      label: (json['label'] ?? templateByKey(templateKey).label).toString(),
      startMinutes: intFromJsonValue(json['startMinutes']),
      endMinutes: intFromJsonValue(json['endMinutes']),
      ward: (json['ward'] ?? '').toString(),
      notes: (json['notes'] ?? '').toString(),
      reminderOn: boolFromJsonValue(json['reminderOn'], fallback: true),
    );
  }
}

class DtrLog {
  DtrLog({
    required this.id,
    required this.date,
    this.timeIn,
    this.timeOut,
  });

  final String id;
  final DateTime date;
  DateTime? timeIn;
  DateTime? timeOut;

  double get actualHours {
    if (timeIn == null || timeOut == null) return 0.0;
    var out = timeOut!;
    if (out.isBefore(timeIn!)) out = out.add(const Duration(days: 1));
    final diff = out.difference(timeIn!);
    if (diff.isNegative) return 0.0;
    return diff.inMinutes / 60.0;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': DateFormat('yyyy-MM-dd').format(date),
        'timeIn': timeIn?.toIso8601String(),
        'timeOut': timeOut?.toIso8601String(),
      };

  factory DtrLog.fromJson(Map<String, dynamic> json) {
    final parsedDate = dateFromJsonValue(json['date']);
    DateTime? parseNullable(dynamic value) {
      if (value == null) return null;
      return DateTime.tryParse(value.toString());
    }
    return DtrLog(
      id: (json['id'] ?? DateFormat('yyyyMMdd').format(parsedDate)).toString(),
      date: parsedDate,
      timeIn: parseNullable(json['timeIn']),
      timeOut: parseNullable(json['timeOut']),
    );
  }
}

class AppState extends ChangeNotifier {
  List<DutyItem> duties = [];
  List<DtrLog> logs = [];
  Map<String, int> spmsPatients = {};

  double dailyRate = 1165.46;
  double requiredHours = 8;
  bool useHourlyRate = false;
  double manualHourlyRate = 145.63;

  String dtrName = '';
  String hospitalName = '';
  String position = 'NURSE I';
  String department = '';

  Color primaryColor = kDefaultPrimary;
  ThemeMode themeMode = ThemeMode.light;

  double get computedHourlyRate => requiredHours <= 0 ? 0.0 : dailyRate / requiredHours;
  double get payHourlyRate => useHourlyRate ? manualHourlyRate : computedHourlyRate;
  double get effectiveDailyRate => payHourlyRate * requiredHours;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    dailyRate = prefs.getDouble('dailyRate') ?? 1165.46;
    requiredHours = prefs.getDouble('requiredHours') ?? 8;
    useHourlyRate = prefs.getBool('useHourlyRate') ?? false;
    manualHourlyRate = prefs.getDouble('manualHourlyRate') ?? (requiredHours <= 0 ? 0.0 : dailyRate / requiredHours);
    dtrName = prefs.getString('dtrName') ?? '';
    hospitalName = prefs.getString('hospitalName') ?? '';
    position = prefs.getString('position') ?? 'NURSE I';
    department = prefs.getString('department') ?? '';
    primaryColor = Color(prefs.getInt('primaryColor') ?? kDefaultPrimary.value);
    themeMode = ThemeMode.values[prefs.getInt('themeMode') ?? ThemeMode.light.index];

    final dutyRaw = prefs.getStringList('duties') ?? [];
    duties = dutyRaw.map((e) => DutyItem.fromJson(jsonDecode(e) as Map<String, dynamic>)).toList();
    duties.sort((a, b) => a.date.compareTo(b.date));

    final logRaw = prefs.getStringList('logs') ?? [];
    logs = logRaw.map((e) => DtrLog.fromJson(jsonDecode(e) as Map<String, dynamic>)).toList();
    logs.sort((a, b) => b.date.compareTo(a.date));

    final spmsRaw = prefs.getString('spmsPatients') ?? '{}';
    try {
      final decoded = jsonDecode(spmsRaw);
      if (decoded is Map) {
        spmsPatients = decoded.map((key, value) => MapEntry(key.toString(), intFromJsonValue(value) ?? 0));
      }
    } catch (_) {
      spmsPatients = {};
    }
    await syncWidgetSnapshot(prefs);
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('dailyRate', dailyRate);
    await prefs.setDouble('requiredHours', requiredHours);
    await prefs.setBool('useHourlyRate', useHourlyRate);
    await prefs.setDouble('manualHourlyRate', manualHourlyRate);
    await prefs.setString('dtrName', dtrName);
    await prefs.setString('hospitalName', hospitalName);
    await prefs.setString('position', position);
    await prefs.setString('department', department);
    await prefs.setInt('primaryColor', primaryColor.value);
    await prefs.setInt('themeMode', themeMode.index);
    await prefs.setStringList('duties', duties.map((e) => jsonEncode(e.toJson())).toList());
    await prefs.setStringList('logs', logs.map((e) => jsonEncode(e.toJson())).toList());
    await prefs.setString('spmsPatients', jsonEncode(spmsPatients));
    await syncWidgetSnapshot(prefs);
    await syncNativeNotifications();
  }

  Future<void> syncWidgetSnapshot([SharedPreferences? existingPrefs]) async {
    final prefs = existingPrefs ?? await SharedPreferences.getInstance();
    final today = dateOnly(DateTime.now());
    final tomorrow = today.add(const Duration(days: 1));
    await prefs.setString('widget_today_title', 'Today');
    await prefs.setString('widget_today_date', DateFormat('EEE, MMM d').format(today));
    await prefs.setString('widget_today_value', widgetDutyText(today));
    await prefs.setString('widget_tomorrow_title', 'Tomorrow');
    await prefs.setString('widget_tomorrow_date', DateFormat('EEE, MMM d').format(tomorrow));
    await prefs.setString('widget_tomorrow_value', widgetDutyText(tomorrow));
    await prefs.setString('widget_updated', DateFormat('h:mm a').format(DateTime.now()));
    try {
      await kWidgetChannel.invokeMethod('updateWidget');
    } catch (_) {
      // Native widget channel is available only on Android builds with the v1.1 widget patch.
    }
  }

  Future<void> requestNotificationPermission() async {
    try {
      await kWidgetChannel.invokeMethod('requestNotificationPermission');
    } catch (_) {
      // Android-only notification permission bridge.
    }
  }

  Future<void> syncNativeNotifications() async {
    final now = DateTime.now();
    final items = <Map<String, dynamic>>[];
    for (final duty in duties) {
      if (!duty.reminderOn || duty.isOff) continue;
      // Keep reminders reasonably near so Android does not keep too many alarms.
      if (duty.date.isBefore(dateOnly(now).subtract(const Duration(days: 1))) || duty.date.isAfter(dateOnly(now).add(const Duration(days: 370)))) continue;
      for (final hour in const [0, 5]) {
        final trigger = DateTime(duty.date.year, duty.date.month, duty.date.day, hour, 0);
        if (trigger.isBefore(now)) continue;
        final idBase = int.tryParse(DateFormat('yyyyMMdd').format(duty.date)) ?? duty.date.millisecondsSinceEpoch.remainder(2000000000);
        final id = (idBase * 10 + (hour == 0 ? 0 : 5)).remainder(2000000000);
        final label = dutyLabelForDate(duty.date, null);
        final wardText = duty.ward.trim().isEmpty ? '' : ' • ${duty.ward.trim()}';
        items.add({
          'id': id,
          'triggerMillis': trigger.millisecondsSinceEpoch,
          'title': hour == 0 ? 'N-Life Duty Today' : 'N-Life 5 AM Duty Reminder',
          'body': '$label • ${duty.timeRange}$wardText',
        });
      }
    }
    try {
      await kWidgetChannel.invokeMethod('scheduleDutyNotifications', {'items': items});
    } catch (_) {
      // Native notification scheduling is available only in the Android build.
    }
  }

  Future<void> showTestNotification() async {
    try {
      await kWidgetChannel.invokeMethod('showTestNotification');
    } catch (_) {
      // Android-only notification test bridge.
    }
  }

  Future<void> pinHomeScreenWidget() async {
    try {
      await syncWidgetSnapshot();
      await kWidgetChannel.invokeMethod('pinWidget');
    } catch (_) {
      // Some launchers do not support automatic widget pinning.
    }
  }

  String widgetDutyText(DateTime date) {
    final duty = dutyForDate(date);
    if (duty == null) return 'OFF / No scheduled duty';
    final label = dutyLabelForDate(date, null);
    final time = duty.timeRange == '--' ? '' : duty.timeRange;
    final wardText = duty.ward.trim();
    final parts = <String>[label];
    if (time.isNotEmpty) parts.add(time);
    if (wardText.isNotEmpty) parts.add(wardText);
    return parts.join(' • ');
  }

  String backupDataJson() {
    final data = {
      'app': 'N-Life',
      'version': kAppVersion,
      'exportedAt': DateTime.now().toIso8601String(),
      'dailyRate': dailyRate,
      'requiredHours': requiredHours,
      'useHourlyRate': useHourlyRate,
      'manualHourlyRate': manualHourlyRate,
      'dtrName': dtrName,
      'hospitalName': hospitalName,
      'position': position,
      'department': department,
      'primaryColor': primaryColor.value,
      'themeMode': themeMode.index,
      'duties': duties.map((e) => e.toJson()).toList(),
      'logs': logs.map((e) => e.toJson()).toList(),
      'spmsPatients': spmsPatients,
    };
    return const JsonEncoder.withIndent('  ').convert(data);
  }

  Future<void> importBackupData(String raw) async {
    final cleaned = cleanBackupInput(raw);
    if (cleaned.trim().isEmpty) {
      throw const FormatException('Empty backup text.');
    }

    dynamic decoded;
    try {
      decoded = jsonDecode(cleaned);
    } catch (_) {
      // Some phones copy backup text with smart quotes or hidden characters.
      final safer = cleaned
          .replaceAll('“', '"')
          .replaceAll('”', '"')
          .replaceAll('‘', "'")
          .replaceAll('’', "'")
          .replaceAll('\uFEFF', '');
      decoded = jsonDecode(safer);
    }

    if (decoded is! Map) throw const FormatException('Backup must be a JSON object.');
    final data = Map<String, dynamic>.from(decoded as Map);

    dailyRate = doubleFromJsonValue(data['dailyRate']) ?? dailyRate;
    requiredHours = doubleFromJsonValue(data['requiredHours']) ?? requiredHours;
    useHourlyRate = boolFromJsonValue(data['useHourlyRate'], fallback: useHourlyRate);
    manualHourlyRate = doubleFromJsonValue(data['manualHourlyRate']) ?? manualHourlyRate;
    dtrName = stringFromJsonValue(data['dtrName']) ?? dtrName;
    hospitalName = stringFromJsonValue(data['hospitalName']) ?? hospitalName;
    position = stringFromJsonValue(data['position']) ?? position;
    department = stringFromJsonValue(data['department']) ?? department;
    final colorValue = intFromJsonValue(data['primaryColor']);
    if (colorValue != null) primaryColor = Color(colorValue);
    final themeIndex = intFromJsonValue(data['themeMode']);
    if (themeIndex != null && themeIndex >= 0 && themeIndex < ThemeMode.values.length) themeMode = ThemeMode.values[themeIndex];

    final dutyList = data['duties'];
    if (dutyList is List) {
      final restoredDuties = <DutyItem>[];
      for (final item in dutyList) {
        try {
          if (item is Map) restoredDuties.add(DutyItem.fromJson(Map<String, dynamic>.from(item)));
          if (item is String) restoredDuties.add(DutyItem.fromJson(Map<String, dynamic>.from(jsonDecode(item) as Map)));
        } catch (_) {
          // Skip only the damaged item instead of failing the whole restore.
        }
      }
      duties = restoredDuties..sort((a, b) => a.date.compareTo(b.date));
    }

    final logList = data['logs'];
    if (logList is List) {
      final restoredLogs = <DtrLog>[];
      for (final item in logList) {
        try {
          if (item is Map) restoredLogs.add(DtrLog.fromJson(Map<String, dynamic>.from(item)));
          if (item is String) restoredLogs.add(DtrLog.fromJson(Map<String, dynamic>.from(jsonDecode(item) as Map)));
        } catch (_) {
          // Skip only the damaged item instead of failing the whole restore.
        }
      }
      logs = restoredLogs..sort((a, b) => b.date.compareTo(a.date));
    }

    final spmsData = data['spmsPatients'];
    if (spmsData is Map) {
      spmsPatients = spmsData.map((key, value) => MapEntry(key.toString(), intFromJsonValue(value) ?? 0));
      spmsPatients.removeWhere((key, value) => value <= 0);
    }

    await save();
    notifyListeners();
  }

  DutyItem? dutyForDate(DateTime date) {
    for (final duty in duties) {
      if (isSameDate(duty.date, date)) return duty;
    }
    return null;
  }

  DtrLog? logForDate(DateTime date) {
    for (final log in logs) {
      if (isSameDate(log.date, date)) return log;
    }
    return null;
  }

  List<DutyItem> dutiesForMonth(DateTime month) {
    return duties.where((d) => d.date.year == month.year && d.date.month == month.month).toList()
      ..sort((a, b) => a.date.compareTo(b.date));
  }

  DtrLog? openLog() {
    final openLogs = logs.where((log) => log.timeIn != null && log.timeOut == null).toList()
      ..sort((a, b) => b.timeIn!.compareTo(a.timeIn!));
    return openLogs.isEmpty ? null : openLogs.first;
  }

  Future<void> timeInNow() async {
    final now = DateTime.now();
    var log = logForDate(now);
    if (log == null) {
      log = DtrLog(id: now.microsecondsSinceEpoch.toString(), date: dateOnly(now), timeIn: now);
      logs.add(log);
    } else {
      log.timeIn = now;
    }
    logs.sort((a, b) => b.date.compareTo(a.date));
    await save();
    notifyListeners();
  }

  Future<void> timeOutNow() async {
    final now = DateTime.now();
    var log = openLog() ?? logForDate(now);
    if (log == null) {
      log = DtrLog(id: now.microsecondsSinceEpoch.toString(), date: dateOnly(now), timeOut: now);
      logs.add(log);
    } else {
      log.timeOut = now;
    }
    logs.sort((a, b) => b.date.compareTo(a.date));
    await save();
    notifyListeners();
  }

  Future<void> addOrReplaceDuties(List<DutyItem> newDuties) async {
    final dates = newDuties.map((d) => DateFormat('yyyy-MM-dd').format(d.date)).toSet();
    duties.removeWhere((old) => dates.contains(DateFormat('yyyy-MM-dd').format(old.date)));
    duties.addAll(newDuties);
    duties.sort((a, b) => a.date.compareTo(b.date));
    await save();
    notifyListeners();
  }

  Future<void> deleteDuty(String id) async {
    duties.removeWhere((d) => d.id == id);
    await save();
    notifyListeners();
  }

  Future<void> addManualLog(DtrLog log) async {
    logs.removeWhere((e) => isSameDate(e.date, log.date));
    logs.add(log);
    logs.sort((a, b) => b.date.compareTo(a.date));
    await save();
    notifyListeners();
  }

  Future<void> updateLog(DtrLog updatedLog) async {
    logs.removeWhere((e) => e.id == updatedLog.id || isSameDate(e.date, updatedLog.date));
    logs.add(updatedLog);
    logs.sort((a, b) => b.date.compareTo(a.date));
    await save();
    notifyListeners();
  }

  Future<void> deleteLog(String id) async {
    logs.removeWhere((l) => l.id == id);
    await save();
    notifyListeners();
  }

  Future<void> updateSettings({
    required double newDailyRate,
    required double newRequiredHours,
    required bool newUseHourlyRate,
    required double newManualHourlyRate,
    required String newDtrName,
    required String newHospitalName,
    required String newPosition,
    required String newDepartment,
    required Color newPrimaryColor,
    required ThemeMode newThemeMode,
  }) async {
    dailyRate = newDailyRate;
    requiredHours = newRequiredHours;
    useHourlyRate = newUseHourlyRate;
    manualHourlyRate = newManualHourlyRate;
    dtrName = newDtrName.trim();
    hospitalName = newHospitalName.trim();
    position = newPosition.trim();
    department = newDepartment.trim();
    primaryColor = newPrimaryColor;
    themeMode = newThemeMode;
    await save();
    notifyListeners();
  }

  int spmsPatientCountForDate(DateTime date) {
    return spmsPatients[DateFormat('yyyy-MM-dd').format(date)] ?? 0;
  }

  Future<void> setSpmsPatientCount(DateTime date, int count) async {
    final key = DateFormat('yyyy-MM-dd').format(date);
    if (count <= 0) {
      spmsPatients.remove(key);
    } else {
      spmsPatients[key] = count;
    }
    await save();
    notifyListeners();
  }

  double paidHoursForDate(DateTime date) {
    final log = logForDate(date);
    return paidHoursForLog(date, log);
  }

  double paidHoursForLog(DateTime date, DtrLog? log) {
    if (log == null || log.actualHours <= 0) return 0.0;
    final duty = dutyForDate(date);
    final actual = log.actualHours;
    if (duty != null) {
      if (duty.isOff) return 0.0;
      if (duty.isTwelveHour) return 12.0;
      if (duty.templateKey == 'MANUAL') {
        if (duty.scheduledHours >= 11) return duty.scheduledHours;
        if (duty.scheduledHours > 0 && duty.scheduledHours < requiredHours) return duty.scheduledHours;
      }
      return requiredHours;
    }
    if (actual >= 11) return 12.0;
    return actual > requiredHours ? requiredHours : actual;
  }

  DtrTotals totalsFor(DateTime month, DtrPeriod period) {
    final dates = datesForPeriod(month, period);
    double actualHours = 0;
    double paidHours = 0;
    int actualDutyDays = 0;
    for (final date in dates) {
      final log = logForDate(date);
      final actual = log?.actualHours ?? 0.0;
      final paid = paidHoursForLog(date, log);
      actualHours += actual;
      paidHours += paid;
      if (paid > 0) actualDutyDays++;
    }
    final excessHours = dates.fold<double>(0.0, (sum, date) {
      final paid = paidHoursForDate(date);
      return sum + (paid > requiredHours ? paid - requiredHours : 0.0);
    });
    final equivalentPaidDays = requiredHours <= 0 ? 0.0 : paidHours / requiredHours;
    final additionalDayCredit = requiredHours <= 0 ? 0.0 : excessHours / requiredHours;
    return DtrTotals(
      actualHours: actualHours,
      paidHours: paidHours,
      actualDutyDays: actualDutyDays,
      excessHours: excessHours,
      additionalDayCredit: additionalDayCredit,
      equivalentPaidDays: equivalentPaidDays,
      estimatedSalary: paidHours * payHourlyRate,
    );
  }

  String generateDtrSummaryText(DateTime month, DtrPeriod period) {
    final buffer = StringBuffer();
    final dates = datesForPeriod(month, period);
    final totals = totalsFor(month, period);
    buffer.writeln('N-Life DTR Summary');
    buffer.writeln('Name: $dtrName');
    if (hospitalName.trim().isNotEmpty) buffer.writeln('Hospital: $hospitalName');
    buffer.writeln('Period: ${periodTitle(month, period)}');
    buffer.writeln('');
    buffer.writeln('Date | Day | Duty | Time In | Time Out | Actual | Paid | Remarks');
    for (final date in dates) {
      final log = logForDate(date);
      final actual = log?.actualHours ?? 0.0;
      final paid = paidHoursForLog(date, log);
      buffer.writeln('${DateFormat('MMM d').format(date)} | ${DateFormat('EEE').format(date)} | ${dutyLabelForDate(date, log)} | ${formatDateTime(log?.timeIn)} | ${formatDateTime(log?.timeOut)} | ${hoursText(actual)} | ${hoursText(paid)} | ${remarksFor(date, log)}');
    }
    buffer.writeln('');
    buffer.writeln('Total Actual Hours: ${hoursText(totals.actualHours)}');
    buffer.writeln('Total Paid Hours: ${hoursText(totals.paidHours)}');
    buffer.writeln('Equivalent Paid Days: ${totals.equivalentPaidDays.toStringAsFixed(2)}');
    buffer.writeln('Estimated Salary: ${peso(totals.estimatedSalary)}');
    return buffer.toString();
  }

  String dutyLabelForDate(DateTime date, DtrLog? log) {
    final duty = dutyForDate(date);
    if (duty != null) {
      switch (duty.templateKey) {
        case '12H_AM':
          return '12H AM';
        case '12H_PM':
          return '12H PM';
        case 'GRAVEYARD':
          return 'Graveyard';
        case 'OFF':
          return 'OFF';
        case 'LEAVE':
          return 'Leave';
        default:
          return duty.label.trim().isEmpty ? templateByKey(duty.templateKey).label : duty.label;
      }
    }
    final actual = log?.actualHours ?? 0.0;
    if (actual >= 11) return '12H';
    if (actual > 0) return 'Duty';
    return 'OFF';
  }

  String remarksFor(DateTime date, DtrLog? log) {
    final duty = dutyForDate(date);
    if (duty?.templateKey == 'LEAVE') return 'Leave';
    if (duty?.templateKey == 'OFF') return 'OFF';
    if (log == null || log.actualHours <= 0) return duty == null ? 'OFF' : 'No DTR';
    final paid = paidHoursForLog(date, log);
    if (paid > requiredHours) return '+${hoursText(paid - requiredHours)} excess';
    return 'Regular';
  }
}

class DtrTotals {
  const DtrTotals({
    required this.actualHours,
    required this.paidHours,
    required this.actualDutyDays,
    required this.excessHours,
    required this.additionalDayCredit,
    required this.equivalentPaidDays,
    required this.estimatedSalary,
  });

  final double actualHours;
  final double paidHours;
  final int actualDutyDays;
  final double excessHours;
  final double additionalDayCredit;
  final double equivalentPaidDays;
  final double estimatedSalary;
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key, required this.state});

  final AppState state;

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 2100), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => MainShell(state: widget.state)));
    });
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [primary, kSecondary],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(26),
            child: Column(
              children: [
                const Spacer(),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(28),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.16), blurRadius: 30, offset: const Offset(0, 14))],
                  ),
                  child: Image.asset('assets/n_life_official_logo.png', width: 220),
                ),
                const SizedBox(height: 22),
                const Text('Your Duty Companion', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                const Text(kAppTagline, textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 13, letterSpacing: 1.5)),
                const SizedBox(height: 22),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: Colors.white.withOpacity(0.16)),
                  ),
                  child: Text('Developed by\n$kDeveloperName', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, height: 1.3)),
                ),
                const Spacer(),
                const Text('Hospital duty • DTR • Salary tracker', style: TextStyle(color: Colors.white60, fontSize: 12)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key, required this.state});

  final AppState state;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await widget.state.requestNotificationPermission();
      await widget.state.syncWidgetSnapshot();
      await widget.state.syncNativeNotifications();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.state,
      builder: (context, _) {
        final pages = [
          HomePage(state: widget.state),
          CalendarPage(state: widget.state),
          DtrPage(state: widget.state),
          SpmsPage(state: widget.state),
          SalaryPage(state: widget.state),
          SettingsPage(state: widget.state),
        ];
        return Scaffold(
          drawer: AppDrawer(
            state: widget.state,
            onSelectPage: (index) {
              Navigator.of(context).pop();
              setState(() => selectedIndex = index);
            },
          ),
          appBar: AppBar(
            title: Row(
              children: [
                ClipRRect(borderRadius: BorderRadius.circular(9), child: Image.asset('assets/n_life_icon.png', width: 38, height: 38)),
                const SizedBox(width: 10),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('N-Life', style: TextStyle(fontWeight: FontWeight.w900)),
                    Text('Your Duty Companion', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w400)),
                  ],
                ),
              ],
            ),
          ),
          body: pages[selectedIndex],
          bottomNavigationBar: NavigationBar(
            selectedIndex: selectedIndex,
            onDestinationSelected: (i) => setState(() => selectedIndex = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
              NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Duty'),
              NavigationDestination(icon: Icon(Icons.assignment_outlined), selectedIcon: Icon(Icons.assignment), label: 'DTR'),
              NavigationDestination(icon: Icon(Icons.fact_check_outlined), selectedIcon: Icon(Icons.fact_check), label: 'SPMS'),
              NavigationDestination(icon: Icon(Icons.payments_outlined), selectedIcon: Icon(Icons.payments), label: 'Salary'),
              NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
            ],
          ),
        );
      },
    );
  }
}

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key, required this.state, required this.onSelectPage});

  final AppState state;
  final ValueChanged<int> onSelectPage;

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Drawer(
      child: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(gradient: LinearGradient(colors: [primary, kSecondary])),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(borderRadius: BorderRadius.circular(20), child: Image.asset('assets/n_life_icon.png', width: 74, height: 74)),
                  const SizedBox(height: 14),
                  const Text('N-Life', style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  const Text(kAppTagline, style: TextStyle(color: Colors.white70, letterSpacing: 1.2)),
                ],
              ),
            ),
            ListTile(leading: const Icon(Icons.person_outline), title: const Text('Profile / DTR Info'), onTap: () => onSelectPage(5)),
            ListTile(leading: const Icon(Icons.widgets_outlined), title: const Text('Home Screen Widget'), subtitle: const Text('Today and Tomorrow duty'), onTap: () => onSelectPage(5)),
            ListTile(leading: const Icon(Icons.calendar_month_outlined), title: const Text('Monthly Duty Planner'), onTap: () => onSelectPage(1)),
            ListTile(leading: const Icon(Icons.assignment_outlined), title: const Text('DTR Sheet'), onTap: () => onSelectPage(2)),
            ListTile(leading: const Icon(Icons.fact_check_outlined), title: const Text('SPMS Monitoring Form'), onTap: () => onSelectPage(3)),
            ListTile(
              leading: const Icon(Icons.picture_as_pdf_outlined),
              title: const Text('Export DTR PDF'),
              onTap: () async {
                Navigator.of(context).pop();
                await showExportDtrDialog(context, state);
              },
            ),
            const Divider(),
            ListTile(leading: const Icon(Icons.settings_outlined), title: const Text('App Settings'), onTap: () => onSelectPage(5)),
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('About N-Life'),
              onTap: () {
                Navigator.of(context).pop();
                showAboutNLifeDialog(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.code),
              title: const Text('Developer Credit'),
              onTap: () {
                Navigator.of(context).pop();
                showDeveloperDialog(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    final tomorrow = today.add(const Duration(days: 1));
    final duty = state.dutyForDate(today);
    final tomorrowDuty = state.dutyForDate(tomorrow);
    final log = state.logForDate(today);
    final paidToday = state.paidHoursForLog(today, log);
    final totals = state.totalsFor(DateTime(today.year, today.month), today.day <= 15 ? DtrPeriod.firstHalf : DtrPeriod.secondHalf);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(title: greeting(), subtitle: DateFormat('EEEE, MMMM d, yyyy').format(today), icon: Icons.local_hospital),
        const SizedBox(height: 14),
        const SectionTitle(title: 'Today\'s Duty'),
        DutySummaryCard(duty: duty, emptyMessage: 'No duty set today.'),
        const SizedBox(height: 14),
        const SectionTitle(title: 'Tomorrow\'s Duty'),
        DutySummaryCard(duty: tomorrowDuty, emptyMessage: 'No duty set tomorrow.'),
        const SizedBox(height: 14),
        const SectionTitle(title: 'DTR Today'),
        NCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InfoRow(label: 'Time In', value: formatDateTime(log?.timeIn)),
              InfoRow(label: 'Time Out', value: formatDateTime(log?.timeOut)),
              InfoRow(label: 'Actual Hours', value: hoursText(log?.actualHours ?? 0.0)),
              InfoRow(label: 'Paid Credit', value: hoursText(paidToday)),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () async {
                        await state.timeInNow();
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Time In saved: ${DateFormat('h:mm a').format(DateTime.now())}')));
                        }
                      },
                      icon: const Icon(Icons.login),
                      label: const Text('TIME IN'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        await state.timeOutNow();
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Time Out saved: ${DateFormat('h:mm a').format(DateTime.now())}')));
                        }
                      },
                      icon: const Icon(Icons.logout),
                      label: const Text('TIME OUT'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const SectionTitle(title: 'Cut-off Salary Estimate'),
        NCard(
          child: Column(
            children: [
              InfoRow(label: 'Paid Hours', value: hoursText(totals.paidHours)),
              InfoRow(label: 'Equivalent Days', value: totals.equivalentPaidDays.toStringAsFixed(2)),
              InfoRow(label: 'Estimated Salary', value: peso(totals.estimatedSalary)),
            ],
          ),
        ),
      ],
    );
  }
}

class CalendarPage extends StatefulWidget {
  const CalendarPage({super.key, required this.state});

  final AppState state;

  @override
  State<CalendarPage> createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  late DateTime month;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    month = DateTime(now.year, now.month);
  }

  @override
  Widget build(BuildContext context) {
    final monthDuties = widget.state.dutiesForMonth(month);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(title: 'Duty Calendar', subtitle: 'Monthly schedule with duty labels.', icon: Icons.calendar_month),
        const SizedBox(height: 14),
        MonthSelector(
          month: month,
          onPrevious: () => setState(() => month = DateTime(month.year, month.month - 1)),
          onNext: () => setState(() => month = DateTime(month.year, month.month + 1)),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: () => showFastAddDutyDialog(context, widget.state, month),
                icon: const Icon(Icons.flash_on),
                label: const Text('Fast Add'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => showManualDutyDialog(context, widget.state, month),
                icon: const Icon(Icons.edit_calendar),
                label: const Text('Manual'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        LayoutBuilder(
          builder: (context, constraints) {
            final buttonWidth = (constraints.maxWidth - 10) / 2;
            return Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                SizedBox(
                  width: buttonWidth,
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => DutyCalendarFullScreenPreview(state: widget.state, month: month),
                        ),
                      );
                    },
                    icon: const Icon(Icons.zoom_out_map_outlined, size: 18),
                    label: const Text('View Calendar', overflow: TextOverflow.ellipsis),
                  ),
                ),
                SizedBox(
                  width: buttonWidth,
                  child: OutlinedButton.icon(
                    onPressed: () => showCalendarExportDialog(context, widget.state, month, CalendarExportAction.printPdf),
                    icon: const Icon(Icons.print_outlined, size: 18),
                    label: const Text('Print Calendar', overflow: TextOverflow.ellipsis),
                  ),
                ),
                SizedBox(
                  width: buttonWidth,
                  child: OutlinedButton.icon(
                    onPressed: () => showCalendarExportDialog(context, widget.state, month, CalendarExportAction.savePng),
                    icon: const Icon(Icons.image_outlined, size: 18),
                    label: const Text('Save PNG', overflow: TextOverflow.ellipsis),
                  ),
                ),
              ],
            );
          },
        ),
        const SizedBox(height: 14),
        MonthlyCalendarCard(state: widget.state, month: month),
        const SizedBox(height: 18),
        const SectionTitle(title: 'This Month Duties'),
        if (monthDuties.isEmpty) const EmptyCard(message: 'No duties added for this month yet.'),
        ...monthDuties.map((duty) => DutyTile(duty: duty, onDelete: () => widget.state.deleteDuty(duty.id))),
      ],
    );
  }
}

class MonthlyCalendarCard extends StatelessWidget {
  const MonthlyCalendarCard({super.key, required this.state, required this.month});

  final AppState state;
  final DateTime month;

  @override
  Widget build(BuildContext context) {
    final first = DateTime(month.year, month.month, 1);
    final last = DateTime(month.year, month.month + 1, 0);
    final leadingBlanks = first.weekday % 7;
    final totalCells = leadingBlanks + last.day;
    final rows = (totalCells / 7).ceil();
    final primary = Theme.of(context).colorScheme.primary;

    return NCard(
      child: Column(
        children: [
          Row(
            children: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
                .map((d) => Expanded(child: Center(child: Text(d, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)))))
                .toList(),
          ),
          const SizedBox(height: 8),
          ...List.generate(rows, (row) {
            return Row(
              children: List.generate(7, (col) {
                final cellIndex = row * 7 + col;
                final dayNumber = cellIndex - leadingBlanks + 1;
                if (dayNumber < 1 || dayNumber > last.day) return const Expanded(child: SizedBox(height: 72));
                final date = DateTime(month.year, month.month, dayNumber);
                final duty = state.dutyForDate(date);
                final label = duty == null ? '' : calendarLabelForDuty(duty);
                final dutyColor = duty == null ? null : dutyColorForKey(duty.templateKey);
                final isToday = isSameDate(date, DateTime.now());
                return Expanded(
                  child: InkWell(
                    onTap: () => showDutyDetails(context, state, date),
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      height: 72,
                      margin: const EdgeInsets.all(3),
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: isToday ? primary : (dutyColor?.withOpacity(0.45) ?? Colors.grey.withOpacity(0.18)), width: isToday ? 2 : 1),
                        color: duty == null ? null : dutyColor!.withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.22 : 0.10),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(dayNumber.toString(), style: TextStyle(fontWeight: FontWeight.w900, color: isToday ? primary : Theme.of(context).colorScheme.onSurface)),
                          const Spacer(),
                          if (label.isNotEmpty)
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
                              decoration: BoxDecoration(color: dutyColor, borderRadius: BorderRadius.circular(7)),
                              child: Text(label, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)),
                            )
                          else
                            Text('OFF', style: TextStyle(fontSize: 10, color: Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.70))),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            );
          }),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: kShiftTemplates.where((t) => t.key != 'MANUAL').map((template) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: dutyColorForKey(template.key).withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.28 : 0.12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: dutyColorForKey(template.key).withOpacity(0.45)),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Container(width: 8, height: 8, decoration: BoxDecoration(color: dutyColorForKey(template.key), shape: BoxShape.circle)),
                  const SizedBox(width: 5),
                  Text(template.label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.onSurface)),
                ]),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}


class DutyCalendarFullScreenPreview extends StatelessWidget {
  const DutyCalendarFullScreenPreview({
    super.key,
    required this.state,
    required this.month,
  });

  final AppState state;
  final DateTime month;

  @override
  Widget build(BuildContext context) {
    final dates = datesForMonth(month);
    final duties = state.dutiesForMonth(month);
    final onSurface = Theme.of(context).colorScheme.onSurface;
    final muted = Theme.of(context).colorScheme.onSurfaceVariant;
    final canvasHeight = 520 + (dates.length * 50.0);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Duty Calendar Preview'),
        actions: [
          IconButton(
            tooltip: 'Print Calendar',
            icon: const Icon(Icons.print_outlined),
            onPressed: () async {
              await Printing.layoutPdf(
                name: 'N-Life-Duty-Calendar-${DateFormat('yyyy-MM').format(month)}.pdf',
                onLayout: (_) => buildDutyCalendarPdf(state, month, DtrPeriod.wholeMonth),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: Theme.of(context).cardTheme.color,
            child: Text(
              'Pinch to zoom • drag to move • preview only',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: muted, fontWeight: FontWeight.w700),
            ),
          ),
          Expanded(
            child: InteractiveViewer(
              minScale: 0.55,
              maxScale: 3.0,
              boundaryMargin: const EdgeInsets.all(180),
              constrained: false,
              child: SizedBox(
                width: 1120,
                height: canvasHeight < 980 ? 980 : canvasHeight,
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('N-Life Duty Calendar', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: onSurface)),
                          const SizedBox(height: 8),
                          Text('Name: ${state.dtrName}', style: TextStyle(fontSize: 15, color: onSurface, fontWeight: FontWeight.w800)),
                          if (state.hospitalName.trim().isNotEmpty) Text('Hospital: ${state.hospitalName}', style: TextStyle(fontSize: 14, color: onSurface)),
                          Text('Month: ${DateFormat('MMMM yyyy').format(month)}', style: TextStyle(fontSize: 14, color: onSurface)),
                          const SizedBox(height: 14),
                          _DutyCalendarPreviewGrid(state: state, month: month),
                          const SizedBox(height: 20),
                          Text('Duty List', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: onSurface)),
                          const SizedBox(height: 8),
                          DataTable(
                            headingRowHeight: 42,
                            dataRowMinHeight: 44,
                            dataRowMaxHeight: 52,
                            columns: const [
                              DataColumn(label: Text('Date')),
                              DataColumn(label: Text('Day')),
                              DataColumn(label: Text('Duty')),
                              DataColumn(label: Text('Time')),
                              DataColumn(label: Text('Ward')),
                              DataColumn(label: Text('Notes')),
                            ],
                            rows: dates.map((date) {
                              final duty = state.dutyForDate(date);
                              return DataRow(cells: [
                                DataCell(Text(DateFormat('MMM d').format(date))),
                                DataCell(Text(DateFormat('EEE').format(date))),
                                DataCell(Text(duty == null ? 'OFF' : calendarLabelForDuty(duty))),
                                DataCell(Text(duty?.timeRange ?? '--')),
                                DataCell(Text(duty?.ward.ifEmpty('--') ?? '--')),
                                DataCell(Text(duty?.notes.ifEmpty('--') ?? '--')),
                              ]);
                            }).toList(),
                          ),
                          const SizedBox(height: 12),
                          Text('Total scheduled duties: ${duties.where((duty) => !duty.isOff).length}', style: TextStyle(fontSize: 14, color: onSurface, fontWeight: FontWeight.w800)),
                          Text('OFF / Leave days are displayed in the calendar for easier monthly checking.', style: TextStyle(fontSize: 12, color: muted)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _DutyCalendarPreviewGrid extends StatelessWidget {
  const _DutyCalendarPreviewGrid({required this.state, required this.month});

  final AppState state;
  final DateTime month;

  @override
  Widget build(BuildContext context) {
    final first = DateTime(month.year, month.month, 1);
    final last = DateTime(month.year, month.month + 1, 0);
    final leadingBlanks = first.weekday % 7;
    final totalCells = leadingBlanks + last.day;
    final rows = (totalCells / 7).ceil();
    final onSurface = Theme.of(context).colorScheme.onSurface;

    return Column(
      children: [
        Row(
          children: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
              .map((day) => Expanded(child: Center(child: Text(day, style: TextStyle(fontWeight: FontWeight.w900, color: onSurface)))))
              .toList(),
        ),
        const SizedBox(height: 8),
        ...List.generate(rows, (row) {
          return Row(
            children: List.generate(7, (col) {
              final cellIndex = row * 7 + col;
              final dayNumber = cellIndex - leadingBlanks + 1;
              if (dayNumber < 1 || dayNumber > last.day) return const Expanded(child: SizedBox(height: 82));
              final date = DateTime(month.year, month.month, dayNumber);
              final duty = state.dutyForDate(date);
              final label = duty == null ? 'OFF' : calendarLabelForDuty(duty);
              final color = duty == null ? dutyColorForKey('OFF') : dutyColorForKey(duty.templateKey);
              return Expanded(
                child: Container(
                  height: 82,
                  margin: const EdgeInsets.all(4),
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: color.withOpacity(0.55)),
                    color: color.withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.22 : 0.10),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(dayNumber.toString(), style: TextStyle(fontWeight: FontWeight.w900, color: onSurface)),
                      const Spacer(),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
                        child: Text(label, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w900)),
                      ),
                    ],
                  ),
                ),
              );
            }),
          );
        }),
      ],
    );
  }
}


class DtrPage extends StatefulWidget {
  const DtrPage({super.key, required this.state});

  final AppState state;

  @override
  State<DtrPage> createState() => _DtrPageState();
}

class _DtrPageState extends State<DtrPage> {
  late DateTime month;
  DtrPeriod period = DtrPeriod.firstHalf;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    month = DateTime(now.year, now.month);
    period = now.day <= 15 ? DtrPeriod.firstHalf : DtrPeriod.secondHalf;
  }

  @override
  Widget build(BuildContext context) {
    final dates = datesForPeriod(month, period);
    final totals = widget.state.totalsFor(month, period);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(title: 'DTR Sheet', subtitle: 'Visual DTR format for writing and checking.', icon: Icons.assignment),
        const SizedBox(height: 14),
        MonthSelector(
          month: month,
          onPrevious: () => setState(() => month = DateTime(month.year, month.month - 1)),
          onNext: () => setState(() => month = DateTime(month.year, month.month + 1)),
        ),
        const SizedBox(height: 10),
        SegmentedButton<DtrPeriod>(
          segments: const [
            ButtonSegment(value: DtrPeriod.firstHalf, label: Text('1-15')),
            ButtonSegment(value: DtrPeriod.secondHalf, label: Text('16-End')),
            ButtonSegment(value: DtrPeriod.wholeMonth, label: Text('Month')),
          ],
          selected: {period},
          onSelectionChanged: (set) => setState(() => period = set.first),
        ),
        const SizedBox(height: 12),
        Column(
          children: [
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => showManualLogDialog(context, widget.state),
                icon: const Icon(Icons.add),
                label: const Text('Add DTR'),
              ),
            ),
            const SizedBox(height: 10),
            LayoutBuilder(
              builder: (context, constraints) {
                final buttonWidth = (constraints.maxWidth - 20) / 3;
                return Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    SizedBox(
                      width: buttonWidth,
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          await Clipboard.setData(ClipboardData(text: widget.state.generateDtrSummaryText(month, period)));
                          if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('DTR summary copied.')));
                        },
                        icon: const Icon(Icons.copy, size: 18),
                        label: const Text('Copy', overflow: TextOverflow.ellipsis),
                      ),
                    ),
                    SizedBox(
                      width: buttonWidth,
                      child: OutlinedButton.icon(
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => DtrFullScreenPreview(
                                state: widget.state,
                                month: month,
                                period: period,
                              ),
                            ),
                          );
                        },
                        icon: const Icon(Icons.zoom_out_map_outlined, size: 18),
                        label: const Text('View DTR', overflow: TextOverflow.ellipsis),
                      ),
                    ),
                    SizedBox(
                      width: buttonWidth,
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          await Printing.layoutPdf(
                            name: 'N-Life-DTR-${DateFormat('yyyy-MM').format(month)}-${period.name}.pdf',
                            onLayout: (_) => buildDtrPdf(widget.state, month, period),
                          );
                        },
                        icon: const Icon(Icons.print_outlined, size: 18),
                        label: const Text('Print DTR', overflow: TextOverflow.ellipsis),
                      ),
                    ),
                  ],
                );
              },
            ),
          ],
        ),
        const SizedBox(height: 14),
        const SectionTitle(title: 'Civil Service Form No. 48'),
        NCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'CS Form No. 48 print guide based on the selected cut-off. The printed page has two long copies side-by-side to save paper.',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
              ),
              const SizedBox(height: 12),
              LayoutBuilder(
                builder: (context, constraints) {
                  final buttonWidth = (constraints.maxWidth - 20) / 3;
                  return Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      SizedBox(
                        width: buttonWidth,
                        child: OutlinedButton.icon(
                          onPressed: () async {
                            await Clipboard.setData(ClipboardData(text: generateCsForm48Guide(widget.state, month, period)));
                            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('CS Form 48 guide copied.')));
                          },
                          icon: const Icon(Icons.copy_all_outlined, size: 18),
                          label: const Text('Copy Guide', overflow: TextOverflow.ellipsis),
                        ),
                      ),
                      SizedBox(
                        width: buttonWidth,
                        child: OutlinedButton.icon(
                          onPressed: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => CsForm48FullScreenPreview(state: widget.state, month: month, period: period),
                              ),
                            );
                          },
                          icon: const Icon(Icons.article_outlined, size: 18),
                          label: const Text('View Form 48', overflow: TextOverflow.ellipsis),
                        ),
                      ),
                      SizedBox(
                        width: buttonWidth,
                        child: OutlinedButton.icon(
                          onPressed: () async {
                            await Printing.layoutPdf(
                              name: 'N-Life-CS-Form-48-${DateFormat('yyyy-MM').format(month)}.pdf',
                              onLayout: (_) => buildCsForm48Pdf(widget.state, month, period),
                            );
                          },
                          icon: const Icon(Icons.print_outlined, size: 18),
                          label: const Text('Print Form 48', overflow: TextOverflow.ellipsis),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        NCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Name: ${widget.state.dtrName}', style: const TextStyle(fontWeight: FontWeight.w900)),
              if (widget.state.hospitalName.trim().isNotEmpty) Text('Hospital: ${widget.state.hospitalName}'),
              Text('Period: ${periodTitle(month, period)}'),
              const Divider(height: 24),
              InfoRow(label: 'Total Paid Hours', value: hoursText(totals.paidHours)),
              InfoRow(label: 'Equivalent Paid Days', value: totals.equivalentPaidDays.toStringAsFixed(2)),
              InfoRow(label: 'Rate Mode', value: widget.state.useHourlyRate ? 'Hourly Rate' : 'Daily Rate'),
              InfoRow(label: 'Hourly Rate Used', value: peso(widget.state.payHourlyRate)),
              InfoRow(label: 'Estimated Salary', value: peso(totals.estimatedSalary)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const SectionTitle(title: 'DTR Sheet Preview'),
        DtrSheetTable(state: widget.state, dates: dates),
        const SizedBox(height: 18),
        const SectionTitle(title: 'DTR Logs'),
        if (widget.state.logs.isEmpty) const EmptyCard(message: 'No DTR logs yet.'),
        ...widget.state.logs.map((log) => DtrTile(log: log, state: widget.state)),
      ],
    );
  }
}


class CsForm48Row {
  const CsForm48Row({
    required this.day,
    required this.amArrival,
    required this.amDeparture,
    required this.pmArrival,
    required this.pmDeparture,
    required this.undertimeHours,
    required this.undertimeMinutes,
    required this.note,
  });

  final int day;
  final String amArrival;
  final String amDeparture;
  final String pmArrival;
  final String pmDeparture;
  final String undertimeHours;
  final String undertimeMinutes;
  final String note;
}

class CsForm48FullScreenPreview extends StatelessWidget {
  const CsForm48FullScreenPreview({super.key, required this.state, required this.month, required this.period});

  final AppState state;
  final DateTime month;
  final DtrPeriod period;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CS Form 48 Preview'),
        actions: [
          IconButton(
            tooltip: 'Print CS Form 48',
            icon: const Icon(Icons.print_outlined),
            onPressed: () async {
              await Printing.layoutPdf(
                name: 'N-Life-CS-Form-48-${DateFormat('yyyy-MM').format(month)}-${period.name}.pdf',
                onLayout: (_) => buildCsForm48Pdf(state, month, period),
              );
            },
          ),
        ],
      ),
      body: PdfPreview(
        build: (_) => buildCsForm48Pdf(state, month, period),
        canChangeOrientation: false,
        canChangePageFormat: false,
        allowPrinting: false,
        allowSharing: false,
      ),
    );
  }
}

class DtrSheetTable extends StatelessWidget {
  const DtrSheetTable({super.key, required this.state, required this.dates});

  final AppState state;
  final List<DateTime> dates;

  @override
  Widget build(BuildContext context) {
    return NCard(
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          headingRowHeight: 42,
          dataRowMinHeight: 48,
          dataRowMaxHeight: 56,
          columns: const [
            DataColumn(label: Text('Date')),
            DataColumn(label: Text('Day')),
            DataColumn(label: Text('Duty')),
            DataColumn(label: Text('In')),
            DataColumn(label: Text('Out')),
            DataColumn(label: Text('Actual')),
            DataColumn(label: Text('Paid')),
            DataColumn(label: Text('Remarks')),
          ],
          rows: dates.map((date) {
            final log = state.logForDate(date);
            return DataRow(cells: [
              DataCell(Text(DateFormat('MMM d').format(date))),
              DataCell(Text(DateFormat('EEE').format(date))),
              DataCell(Text(state.dutyLabelForDate(date, log))),
              DataCell(Text(formatDateTime(log?.timeIn))),
              DataCell(Text(formatDateTime(log?.timeOut))),
              DataCell(Text(hoursText(log?.actualHours ?? 0.0))),
              DataCell(Text(hoursText(state.paidHoursForLog(date, log)))),
              DataCell(Text(state.remarksFor(date, log))),
            ]);
          }).toList(),
        ),
      ),
    );
  }
}


class DtrFullScreenPreview extends StatelessWidget {
  const DtrFullScreenPreview({
    super.key,
    required this.state,
    required this.month,
    required this.period,
  });

  final AppState state;
  final DateTime month;
  final DtrPeriod period;

  @override
  Widget build(BuildContext context) {
    final dates = datesForPeriod(month, period);
    final totals = state.totalsFor(month, period);
    // Extra height prevents the fullscreen DTR preview from showing a bottom overflow
    // on smaller phones / landscape rotation when totals are displayed under the table.
    final canvasHeight = 430 + (dates.length * 64.0);
    final onSurface = Theme.of(context).colorScheme.onSurface;
    final muted = Theme.of(context).colorScheme.onSurfaceVariant;

    return Scaffold(
      appBar: AppBar(
        title: const Text('DTR Full Preview'),
        actions: [
          IconButton(
            tooltip: 'Print DTR',
            icon: const Icon(Icons.print_outlined),
            onPressed: () async {
              await Printing.layoutPdf(
                name: 'N-Life-DTR-${DateFormat('yyyy-MM').format(month)}-${period.name}.pdf',
                onLayout: (_) => buildDtrPdf(state, month, period),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: Theme.of(context).cardTheme.color,
            child: Text(
              'Pinch to zoom • drag to move • preview only',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: muted, fontWeight: FontWeight.w700),
            ),
          ),
          Expanded(
            child: InteractiveViewer(
              minScale: 0.55,
              maxScale: 3.0,
              boundaryMargin: const EdgeInsets.all(180),
              constrained: false,
              child: SizedBox(
                width: 1120,
                height: canvasHeight < 780 ? 780 : canvasHeight,
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('N-Life DTR Summary', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: onSurface)),
                          const SizedBox(height: 8),
                          Text('Name: ${state.dtrName}', style: TextStyle(fontSize: 15, color: onSurface, fontWeight: FontWeight.w800)),
                          if (state.hospitalName.trim().isNotEmpty) Text('Hospital: ${state.hospitalName}', style: TextStyle(fontSize: 14, color: onSurface)),
                          if (state.position.trim().isNotEmpty) Text('Position: ${state.position}', style: TextStyle(fontSize: 14, color: onSurface)),
                          if (state.department.trim().isNotEmpty) Text('Department/Ward: ${state.department}', style: TextStyle(fontSize: 14, color: onSurface)),
                          Text('Period: ${periodTitle(month, period)}', style: TextStyle(fontSize: 14, color: onSurface)),
                          const SizedBox(height: 14),
                          DataTable(
                            headingRowHeight: 44,
                            dataRowMinHeight: 48,
                            dataRowMaxHeight: 54,
                            columns: const [
                              DataColumn(label: Text('Date')),
                              DataColumn(label: Text('Day')),
                              DataColumn(label: Text('Duty')),
                              DataColumn(label: Text('Time In')),
                              DataColumn(label: Text('Time Out')),
                              DataColumn(label: Text('Actual')),
                              DataColumn(label: Text('Paid')),
                              DataColumn(label: Text('Remarks')),
                            ],
                            rows: dates.map((date) {
                              final log = state.logForDate(date);
                              return DataRow(cells: [
                                DataCell(Text(DateFormat('MMM d').format(date))),
                                DataCell(Text(DateFormat('EEE').format(date))),
                                DataCell(Text(state.dutyLabelForDate(date, log))),
                                DataCell(Text(formatDateTime(log?.timeIn))),
                                DataCell(Text(formatDateTime(log?.timeOut))),
                                DataCell(Text(hoursText(log?.actualHours ?? 0.0))),
                                DataCell(Text(hoursText(state.paidHoursForLog(date, log)))),
                                DataCell(Text(state.remarksFor(date, log))),
                              ]);
                            }).toList(),
                          ),
                          const Divider(height: 28),
                          Wrap(
                            spacing: 28,
                            runSpacing: 10,
                            children: [
                              _PreviewTotal(label: 'Total Actual Hours', value: hoursText(totals.actualHours)),
                              _PreviewTotal(label: 'Total Paid Hours', value: hoursText(totals.paidHours)),
                              _PreviewTotal(label: 'Equivalent Paid Days', value: totals.equivalentPaidDays.toStringAsFixed(2)),
                              _PreviewTotal(label: 'Rate Mode', value: state.useHourlyRate ? 'Hourly Rate' : 'Daily Rate'),
                              _PreviewTotal(label: 'Hourly Rate Used', value: peso(state.payHourlyRate)),
                              _PreviewTotal(label: 'Estimated Salary', value: peso(totals.estimatedSalary)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PreviewTotal extends StatelessWidget {
  const _PreviewTotal({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label, style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant, fontWeight: FontWeight.w700)),
        const SizedBox(height: 2),
        Text(value, style: TextStyle(fontSize: 15, color: Theme.of(context).colorScheme.onSurface, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class SpmsPage extends StatefulWidget {
  const SpmsPage({super.key, required this.state});

  final AppState state;

  @override
  State<SpmsPage> createState() => _SpmsPageState();
}

class _SpmsPageState extends State<SpmsPage> {
  late DateTime month;
  DtrPeriod period = DtrPeriod.firstHalf;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    month = DateTime(now.year, now.month);
    period = now.day <= 15 ? DtrPeriod.firstHalf : DtrPeriod.secondHalf;
  }

  @override
  Widget build(BuildContext context) {
    final dates = datesForPeriod(month, period);
    final activeDates = dates.where((date) {
      final duty = widget.state.dutyForDate(date);
      return duty != null && !duty.isOff;
    }).toList();
    final totalPatients = activeDates.fold<int>(0, (sum, date) => sum + widget.state.spmsPatientCountForDate(date));

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(
          title: 'SPMS Monitoring Form',
          subtitle: 'Individual accomplishment based on duty calendar.',
          icon: Icons.fact_check,
        ),
        const SizedBox(height: 14),
        MonthSelector(
          month: month,
          onPrevious: () => setState(() => month = DateTime(month.year, month.month - 1)),
          onNext: () => setState(() => month = DateTime(month.year, month.month + 1)),
        ),
        const SizedBox(height: 10),
        SegmentedButton<DtrPeriod>(
          segments: const [
            ButtonSegment(value: DtrPeriod.firstHalf, label: Text('1-15')),
            ButtonSegment(value: DtrPeriod.secondHalf, label: Text('16-End')),
            ButtonSegment(value: DtrPeriod.wholeMonth, label: Text('Month')),
          ],
          selected: {period},
          onSelectionChanged: (set) => setState(() => period = set.first),
        ),
        const SizedBox(height: 12),
        NCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('SPMS Summary', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Theme.of(context).colorScheme.onSurface)),
              const SizedBox(height: 8),
              Text('Active duty days: ${activeDates.length}'),
              Text('Total patient quantity: $totalPatients'),
              const SizedBox(height: 8),
              Text(
                'Patient quantity is editable per duty date. OFF and Leave days follow your Duty Calendar automatically.',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        LayoutBuilder(
          builder: (context, constraints) {
            final buttonWidth = (constraints.maxWidth - 10) / 2;
            return Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                SizedBox(
                  width: buttonWidth,
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => SpmsFullScreenPreview(state: widget.state, month: month, period: period),
                      ));
                    },
                    icon: const Icon(Icons.visibility_outlined),
                    label: const Text('View SPMS'),
                  ),
                ),
                SizedBox(
                  width: buttonWidth,
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await Printing.layoutPdf(
                        name: 'N-Life-SPMS-${DateFormat('yyyy-MM').format(month)}-${periodFileSlug(period)}.pdf',
                        onLayout: (_) => buildSpmsPdf(widget.state, month, period),
                      );
                    },
                    icon: const Icon(Icons.print_outlined),
                    label: const Text('Print SPMS'),
                  ),
                ),
              ],
            );
          },
        ),
        const SizedBox(height: 16),
        const SectionTitle(title: 'Patient Quantity by Duty Date'),
        if (dates.isEmpty) const EmptyCard(message: 'No dates found for this period.'),
        ...dates.map((date) {
          final duty = widget.state.dutyForDate(date);
          final isOff = duty == null || duty.isOff;
          final patientCount = widget.state.spmsPatientCountForDate(date);
          final label = duty == null ? 'OFF' : calendarLabelForDuty(duty);
          final color = duty == null ? dutyColorForKey('OFF') : dutyColorForKey(duty.templateKey);
          return NCard(
            margin: const EdgeInsets.only(bottom: 10),
            child: Row(
              children: [
                Container(
                  width: 64,
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: color.withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.24 : 0.12),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: color.withOpacity(0.45)),
                  ),
                  child: Column(
                    children: [
                      Text(DateFormat('d').format(date), style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Theme.of(context).colorScheme.onSurface)),
                      Text(DateFormat('EEE').format(date), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${DateFormat('MMMM d').format(date)} • $label', style: const TextStyle(fontWeight: FontWeight.w900)),
                      const SizedBox(height: 4),
                      Text(isOff ? 'OFF / No SPMS activity entry' : 'Quantity: ${patientCount > 0 ? '$patientCount PATIENTS' : 'Not set yet'}', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                      if (!isOff && duty.ward.trim().isNotEmpty) Text('Ward: ${duty.ward}', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12)),
                    ],
                  ),
                ),
                if (!isOff)
                  IconButton(
                    tooltip: 'Edit patient quantity',
                    onPressed: () => showSpmsPatientDialog(context, widget.state, date),
                    icon: const Icon(Icons.edit_outlined),
                  ),
              ],
            ),
          );
        }),
      ],
    );
  }
}

class SpmsFullScreenPreview extends StatelessWidget {
  const SpmsFullScreenPreview({super.key, required this.state, required this.month, required this.period});

  final AppState state;
  final DateTime month;
  final DtrPeriod period;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SPMS Preview'),
        actions: [
          IconButton(
            tooltip: 'Print SPMS',
            icon: const Icon(Icons.print_outlined),
            onPressed: () async {
              await Printing.layoutPdf(
                name: 'N-Life-SPMS-${DateFormat('yyyy-MM').format(month)}-${periodFileSlug(period)}.pdf',
                onLayout: (_) => buildSpmsPdf(state, month, period),
              );
            },
          ),
        ],
      ),
      body: PdfPreview(
        build: (_) => buildSpmsPdf(state, month, period),
        canChangeOrientation: false,
        canChangePageFormat: false,
        allowPrinting: false,
        allowSharing: false,
      ),
    );
  }
}

Future<void> showSpmsPatientDialog(BuildContext context, AppState state, DateTime date) async {
  final controller = TextEditingController(text: state.spmsPatientCountForDate(date) > 0 ? state.spmsPatientCountForDate(date).toString() : '');
  await showDialog(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: Text('Patient Quantity - ${DateFormat('MMM d').format(date)}'),
      content: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Number of patients', hintText: 'Example: 12'),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
        TextButton(
          onPressed: () async {
            await state.setSpmsPatientCount(date, 0);
            if (dialogContext.mounted) Navigator.pop(dialogContext);
          },
          child: const Text('Clear'),
        ),
        FilledButton(
          onPressed: () async {
            final count = int.tryParse(controller.text.trim()) ?? 0;
            await state.setSpmsPatientCount(date, count);
            if (dialogContext.mounted) Navigator.pop(dialogContext);
          },
          child: const Text('Save'),
        ),
      ],
    ),
  );
}


class SalaryPage extends StatefulWidget {
  const SalaryPage({super.key, required this.state});

  final AppState state;

  @override
  State<SalaryPage> createState() => _SalaryPageState();
}

class _SalaryPageState extends State<SalaryPage> {
  late DateTime month;
  DtrPeriod period = DtrPeriod.firstHalf;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    month = DateTime(now.year, now.month);
    period = now.day <= 15 ? DtrPeriod.firstHalf : DtrPeriod.secondHalf;
  }

  @override
  Widget build(BuildContext context) {
    final totals = widget.state.totalsFor(month, period);
    final dates = datesForPeriod(month, period);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(title: 'Salary Summary', subtitle: periodTitle(month, period), icon: Icons.payments),
        const SizedBox(height: 14),
        MonthSelector(
          month: month,
          onPrevious: () => setState(() => month = DateTime(month.year, month.month - 1)),
          onNext: () => setState(() => month = DateTime(month.year, month.month + 1)),
        ),
        const SizedBox(height: 10),
        SegmentedButton<DtrPeriod>(
          segments: const [
            ButtonSegment(value: DtrPeriod.firstHalf, label: Text('1-15')),
            ButtonSegment(value: DtrPeriod.secondHalf, label: Text('16-End')),
            ButtonSegment(value: DtrPeriod.wholeMonth, label: Text('Month')),
          ],
          selected: {period},
          onSelectionChanged: (set) => setState(() => period = set.first),
        ),
        const SizedBox(height: 14),
        NCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Estimated Salary', style: TextStyle(fontSize: 14, color: Theme.of(context).colorScheme.onSurfaceVariant)),
              const SizedBox(height: 6),
              Text(peso(totals.estimatedSalary), style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF93C5FD) : Theme.of(context).colorScheme.primary)),
              const Divider(height: 28),
              InfoRow(label: 'Actual Duty Days', value: totals.actualDutyDays.toString()),
              InfoRow(label: 'Actual Hours', value: hoursText(totals.actualHours)),
              InfoRow(label: 'Paid Hours', value: hoursText(totals.paidHours)),
              InfoRow(label: 'Excess Hours from 12H', value: hoursText(totals.excessHours)),
              InfoRow(label: 'Additional Day Credit', value: totals.additionalDayCredit.toStringAsFixed(2)),
              InfoRow(label: 'Equivalent Paid Days', value: totals.equivalentPaidDays.toStringAsFixed(2)),
              InfoRow(label: 'Rate Mode', value: widget.state.useHourlyRate ? 'Hourly Rate' : 'Daily Rate'),
              InfoRow(label: 'Hourly Rate Used', value: peso(widget.state.payHourlyRate)),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const SectionTitle(title: 'Breakdown'),
        ...dates.where((d) => widget.state.paidHoursForDate(d) > 0).map((date) {
          final log = widget.state.logForDate(date);
          final duty = widget.state.dutyForDate(date);
          final paid = widget.state.paidHoursForLog(date, log);
          return NCard(
            margin: const EdgeInsets.only(bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(DateFormat('MMM d, yyyy').format(date), style: const TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 4),
                    Text('${widget.state.dutyLabelForDate(date, log)} • Actual ${hoursText(log?.actualHours ?? 0.0)} • Paid ${hoursText(paid)}', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                  ]),
                ),
                Text(peso(paid * widget.state.payHourlyRate), style: TextStyle(fontWeight: FontWeight.w900, color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF93C5FD) : Theme.of(context).colorScheme.primary)),
              ],
            ),
          );
        }),
        if (dates.every((d) => widget.state.paidHoursForDate(d) <= 0)) const EmptyCard(message: 'No paid DTR entries for this period yet.'),
      ],
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key, required this.state});

  final AppState state;

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController dailyRateController;
  late final TextEditingController hourlyRateController;
  late final TextEditingController requiredHoursController;
  late bool useHourlyRate;
  late final TextEditingController nameController;
  late final TextEditingController hospitalController;
  late final TextEditingController positionController;
  late final TextEditingController departmentController;
  late ThemeMode themeMode;
  late Color selectedColor;

  final colorOptions = const [
    ColorOption('Dark Blue', Color(0xFF0B1F3A)),
    ColorOption('Royal Blue', Color(0xFF1D4ED8)),
    ColorOption('Teal', Color(0xFF0F766E)),
    ColorOption('Green', Color(0xFF166534)),
    ColorOption('Purple', Color(0xFF581C87)),
    ColorOption('Black', Color(0xFF111827)),
  ];

  @override
  void initState() {
    super.initState();
    dailyRateController = TextEditingController(text: widget.state.dailyRate.toStringAsFixed(2));
    hourlyRateController = TextEditingController(text: widget.state.payHourlyRate.toStringAsFixed(2));
    requiredHoursController = TextEditingController(text: widget.state.requiredHours.toStringAsFixed(0));
    useHourlyRate = widget.state.useHourlyRate;
    nameController = TextEditingController(text: widget.state.dtrName);
    hospitalController = TextEditingController(text: widget.state.hospitalName);
    positionController = TextEditingController(text: widget.state.position);
    departmentController = TextEditingController(text: widget.state.department);
    themeMode = widget.state.themeMode;
    selectedColor = widget.state.primaryColor;
  }

  @override
  void dispose() {
    dailyRateController.dispose();
    hourlyRateController.dispose();
    requiredHoursController.dispose();
    nameController.dispose();
    hospitalController.dispose();
    positionController.dispose();
    departmentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(title: 'Settings', subtitle: 'Profile, salary rules, and app theme.', icon: Icons.settings),
        const SizedBox(height: 14),
        const SectionTitle(title: 'DTR Profile'),
        NCard(
          child: Column(children: [
            TextField(controller: nameController, decoration: const InputDecoration(labelText: 'DTR Name')),
            const SizedBox(height: 12),
            TextField(controller: hospitalController, decoration: const InputDecoration(labelText: 'Hospital Name')),
            const SizedBox(height: 12),
            TextField(controller: positionController, decoration: const InputDecoration(labelText: 'Position / Title')),
            const SizedBox(height: 12),
            TextField(controller: departmentController, decoration: const InputDecoration(labelText: 'Department / Ward')),
          ]),
        ),
        const SizedBox(height: 14),
        const SectionTitle(title: 'Salary Rules'),
        NCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Daily Rate')),
                ButtonSegment(value: true, label: Text('Hourly Rate')),
              ],
              selected: {useHourlyRate},
              onSelectionChanged: (set) => setState(() => useHourlyRate = set.first),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: dailyRateController,
              enabled: !useHourlyRate,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
              decoration: InputDecoration(
                labelText: 'Daily Rate',
                prefixText: 'PHP ',
                helperText: useHourlyRate ? 'Disabled while Hourly Rate is selected.' : 'Used to compute hourly rate automatically.',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: hourlyRateController,
              enabled: useHourlyRate,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
              decoration: InputDecoration(
                labelText: 'Hourly Rate',
                prefixText: 'PHP ',
                helperText: useHourlyRate ? 'Used directly for salary computation.' : 'Disabled while Daily Rate is selected.',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: requiredHoursController,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
              decoration: const InputDecoration(labelText: 'Required Hours per Duty'),
            ),
            const SizedBox(height: 10),
            Text(
              useHourlyRate
                  ? 'Hourly mode: Paid hours × hourly rate. Daily rate field is disabled.'
                  : 'Daily mode: Daily rate ÷ required hours = hourly rate. Hourly rate field is disabled.',
              style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
            const SizedBox(height: 6),
            Text('Rule: Normal AM/PM/Graveyard duty is paid as 8 hours. 12H duty is paid as 12 hours, with 4 excess hours credited toward additional days.', style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ]),
        ),
        const SizedBox(height: 14),
        const SectionTitle(title: 'App Theme'),
        NCard(
          child: Column(children: [
            DropdownButtonFormField<Color>(
              value: colorOptions.any((o) => o.color.value == selectedColor.value) ? selectedColor : kDefaultPrimary,
              decoration: const InputDecoration(labelText: 'Color Theme'),
              items: colorOptions.map((option) => DropdownMenuItem(value: option.color, child: Text(option.name))).toList(),
              onChanged: (value) => setState(() => selectedColor = value ?? kDefaultPrimary),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<ThemeMode>(
              value: themeMode,
              decoration: const InputDecoration(labelText: 'Appearance'),
              items: const [
                DropdownMenuItem(value: ThemeMode.system, child: Text('System Default')),
                DropdownMenuItem(value: ThemeMode.light, child: Text('Light Mode')),
                DropdownMenuItem(value: ThemeMode.dark, child: Text('Dark Mode')),
              ],
              onChanged: (value) => setState(() => themeMode = value ?? ThemeMode.system),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () async {
                  final dailyRate = double.tryParse(dailyRateController.text) ?? widget.state.dailyRate;
                  final requiredHours = double.tryParse(requiredHoursController.text) ?? widget.state.requiredHours;
                  final hourlyRate = double.tryParse(hourlyRateController.text) ?? widget.state.payHourlyRate;
                  await widget.state.updateSettings(
                    newDailyRate: dailyRate,
                    newRequiredHours: requiredHours,
                    newUseHourlyRate: useHourlyRate,
                    newManualHourlyRate: hourlyRate,
                    newDtrName: nameController.text,
                    newHospitalName: hospitalController.text,
                    newPosition: positionController.text,
                    newDepartment: departmentController.text,
                    newPrimaryColor: selectedColor,
                    newThemeMode: themeMode,
                  );
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved.')));
                },
                icon: const Icon(Icons.save),
                label: const Text('Save Settings'),
              ),
            ),
          ]),
        ),

        const SizedBox(height: 14),
        const SectionTitle(title: 'Home Screen Widget'),
        NCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('N-Life v1.5 includes an Android home-screen widget and native duty reminders for Today’s Duty and Tomorrow’s Duty.', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text('After installing this update, long-press your phone home screen, choose Widgets, then add N-Life.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  await widget.state.syncWidgetSnapshot();
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Widget refreshed.')));
                },
                icon: const Icon(Icons.refresh),
                label: const Text('Refresh Widget'),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () async {
                  await widget.state.pinHomeScreenWidget();
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('If supported by your launcher, the N-Life widget pin request was sent. You can also long-press the home screen > Widgets > N-Life.')));
                },
                icon: const Icon(Icons.add_to_home_screen),
                label: const Text('Add / Pin Duty Widget'),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  await widget.state.requestNotificationPermission();
                  await widget.state.syncNativeNotifications();
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Notification permission requested and duty reminders refreshed.')));
                },
                icon: const Icon(Icons.notifications_active_outlined),
                label: const Text('Enable Duty Notifications'),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  await widget.state.requestNotificationPermission();
                  await widget.state.showTestNotification();
                  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Test notification sent if notifications are allowed.')));
                },
                icon: const Icon(Icons.notification_add_outlined),
                label: const Text('Send Test Notification'),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 14),
        const SectionTitle(title: 'Backup / Restore'),
        NCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Use this before major updates. Copy your backup text and save it in Notes, Messenger, or Drive.'),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: widget.state.backupDataJson()));
                    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Backup copied to clipboard.')));
                  },
                  icon: const Icon(Icons.copy),
                  label: const Text('Copy Backup'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => showRestoreDialog(context, widget.state),
                  icon: const Icon(Icons.restore),
                  label: const Text('Restore'),
                ),
              ),
            ]),
          ]),
        ),
        const SizedBox(height: 14),
        const SectionTitle(title: 'About N-Life'),
        NCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Image.asset('assets/n_life_official_logo.png', width: 180)),
            const SizedBox(height: 14),
            const Text('N-Life', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            const Text('N-Life is a personal hospital duty companion created to help nurses and healthcare workers schedule duties, track DTR logs, compute salary estimates, and prepare clean DTR summaries.'),
            const Divider(height: 24),
            Text('Developed by\n$kDeveloperName', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('Follow:\nInstagram: @Itslester.l\nFacebook: Lester Andrei Lomboy'),
            const SizedBox(height: 8),
            const Text('Contact:\nlomboylester.nursing@gmail.com'),
            const SizedBox(height: 8),
            const Text('Version: N-Life v1.5 Stable Baseline'),
          ]),
        ),
      ],
    );
  }
}


Future<void> showRestoreDialog(BuildContext context, AppState state) async {
  final controller = TextEditingController();
  await showDialog<void>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('Restore N-Life Backup'),
      content: SizedBox(
        width: double.maxFinite,
        child: TextField(
          controller: controller,
          minLines: 6,
          maxLines: 10,
          decoration: const InputDecoration(
            labelText: 'Paste backup text here',
            alignLabelWithHint: true,
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
        FilledButton.icon(
          onPressed: () async {
            try {
              await state.importBackupData(controller.text);
              if (dialogContext.mounted) Navigator.pop(dialogContext);
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Backup restored.')));
            } catch (e) {
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Restore failed. Please copy the full N-Life backup text.')),
                );
              }
            }
          },
          icon: const Icon(Icons.restore),
          label: const Text('Restore'),
        ),
      ],
    ),
  );
  controller.dispose();
}

class ColorOption {
  const ColorOption(this.name, this.color);
  final String name;
  final Color color;
}

class HeaderCard extends StatelessWidget {
  const HeaderCard({super.key, required this.title, required this.subtitle, required this.icon});

  final String title;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(gradient: LinearGradient(colors: [primary, kSecondary]), borderRadius: BorderRadius.circular(24)),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(subtitle, style: const TextStyle(color: Colors.white70)),
        ])),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white.withOpacity(0.13), shape: BoxShape.circle), child: Icon(icon, color: Colors.white, size: 30)),
      ]),
    );
  }
}

class NCard extends StatelessWidget {
  const NCard({super.key, required this.child, this.margin});
  final Widget child;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return Card(margin: margin, child: Padding(padding: const EdgeInsets.all(16), child: child));
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({super.key, required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(title, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, color: Theme.of(context).colorScheme.onSurface)),
    );
  }
}

class InfoRow extends StatelessWidget {
  const InfoRow({super.key, required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Expanded(child: Text(label, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant))),
        const SizedBox(width: 12),
        Flexible(child: Text(value, textAlign: TextAlign.right, style: TextStyle(fontWeight: FontWeight.w900, color: Theme.of(context).colorScheme.onSurface))),
      ]),
    );
  }
}

class EmptyCard extends StatelessWidget {
  const EmptyCard({super.key, required this.message});
  final String message;

  @override
  Widget build(BuildContext context) => NCard(child: Text(message, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)));
}

class DutySummaryCard extends StatelessWidget {
  const DutySummaryCard({super.key, required this.duty, this.emptyMessage = 'No duty set.'});
  final DutyItem? duty;
  final String emptyMessage;

  @override
  Widget build(BuildContext context) {
    if (duty == null) return EmptyCard(message: emptyMessage);
    final color = dutyColorForKey(duty!.templateKey);
    return NCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Expanded(child: Text(duty!.label, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: color))),
        ]),
        const SizedBox(height: 8),
        InfoRow(label: 'Time', value: duty!.timeRange),
        if (duty!.ward.trim().isNotEmpty) InfoRow(label: 'Area / Ward', value: duty!.ward),
        if (duty!.notes.trim().isNotEmpty) InfoRow(label: 'Notes', value: duty!.notes),
      ]),
    );
  }
}

class DutyTile extends StatelessWidget {
  const DutyTile({super.key, required this.duty, required this.onDelete});
  final DutyItem duty;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return NCard(
      margin: const EdgeInsets.only(bottom: 10),
      child: Row(children: [
        Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(color: dutyColorForKey(duty.templateKey).withOpacity(Theme.of(context).brightness == Brightness.dark ? 0.24 : 0.12), borderRadius: BorderRadius.circular(16)),
          child: Center(child: Text(DateFormat('d').format(duty.date), style: TextStyle(color: dutyColorForKey(duty.templateKey), fontSize: 20, fontWeight: FontWeight.w900))),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${DateFormat('MMM d, yyyy').format(duty.date)} • ${duty.label}', style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text('${duty.timeRange}${duty.ward.trim().isEmpty ? '' : ' • ${duty.ward}'}', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ])),
        IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_outline)),
      ]),
    );
  }
}

class DtrTile extends StatelessWidget {
  const DtrTile({super.key, required this.log, required this.state});
  final DtrLog log;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    final paid = state.paidHoursForLog(log.date, log);
    return NCard(
      margin: const EdgeInsets.only(bottom: 10),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(DateFormat('MMM d, yyyy').format(log.date), style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text('IN ${formatDateTime(log.timeIn)} • OUT ${formatDateTime(log.timeOut)}', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
          const SizedBox(height: 4),
          Text('Actual ${hoursText(log.actualHours)} • Paid ${hoursText(paid)}', style: const TextStyle(fontWeight: FontWeight.w800)),
        ])),
        Row(mainAxisSize: MainAxisSize.min, children: [
          IconButton(
            tooltip: 'Edit Time In / Out',
            onPressed: () => showEditLogDialog(context, state, log),
            icon: const Icon(Icons.edit_outlined),
          ),
          IconButton(onPressed: () => state.deleteLog(log.id), icon: const Icon(Icons.delete_outline)),
        ]),
      ]),
    );
  }
}

class MonthSelector extends StatelessWidget {
  const MonthSelector({super.key, required this.month, required this.onPrevious, required this.onNext});
  final DateTime month;
  final VoidCallback onPrevious;
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) {
    return NCard(
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        IconButton(onPressed: onPrevious, icon: const Icon(Icons.chevron_left)),
        Text(DateFormat('MMMM yyyy').format(month), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        IconButton(onPressed: onNext, icon: const Icon(Icons.chevron_right)),
      ]),
    );
  }
}


List<DropdownMenuItem<String>> shiftDropdownItems() {
  return kShiftTemplates.map((template) {
    return DropdownMenuItem<String>(
      value: template.key,
      child: Text(template.label, overflow: TextOverflow.ellipsis, maxLines: 1),
    );
  }).toList();
}

String shiftDescription(String key) {
  final template = templateByKey(key);
  return template.description ?? 'Custom duty';
}

Future<void> showFastAddDutyDialog(BuildContext context, AppState state, DateTime month) async {
  String selectedKey = 'AM';
  final selectedDays = <int>{};
  final wardController = TextEditingController();
  final notesController = TextEditingController();
  final manualLabelController = TextEditingController(text: 'Manual');
  int? manualStart = 7 * 60;
  int? manualEnd = 15 * 60;
  bool reminderOn = true;
  final lastDay = DateTime(month.year, month.month + 1, 0).day;

  final dutiesToAdd = await showDialog<List<DutyItem>>(
    context: context,
    builder: (dialogContext) {
      return StatefulBuilder(builder: (context, setState) {
        final isManual = selectedKey == 'MANUAL';
        final firstWeekday = DateTime(month.year, month.month, 1).weekday % 7;
        final totalCells = firstWeekday + lastDay;
        final calendarRows = (totalCells / 7).ceil();
        final selectedShiftColor = dutyColorForKey(selectedKey);
        return AlertDialog(
          insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 24),
          title: const Text('Fast Add Monthly Duty - Calendar View'),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                DropdownButtonFormField<String>(
                  value: selectedKey,
                  decoration: const InputDecoration(labelText: 'Duty Type'),
                  isExpanded: true,
                  items: shiftDropdownItems(),
                  selectedItemBuilder: (context) => kShiftTemplates
                      .map((template) => Align(
                            alignment: Alignment.centerLeft,
                            child: Text(template.label, overflow: TextOverflow.ellipsis, maxLines: 1),
                          ))
                      .toList(),
                  onChanged: (value) => setState(() => selectedKey = value ?? 'AM'),
                ),
                const SizedBox(height: 6),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    shiftDescription(selectedKey),
                    style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
                  ),
                ),
                const SizedBox(height: 12),
                if (isManual) ...[
                  TextField(controller: manualLabelController, decoration: const InputDecoration(labelText: 'Manual Label')),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () async {
                          final picked = await pickMinutes(context, manualStart ?? 7 * 60);
                          if (picked != null) setState(() => manualStart = picked);
                        },
                        child: Text('Start: ${formatMinutes(manualStart ?? 0)}', overflow: TextOverflow.ellipsis),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () async {
                          final picked = await pickMinutes(context, manualEnd ?? 15 * 60);
                          if (picked != null) setState(() => manualEnd = picked);
                        },
                        child: Text('End: ${formatMinutes(manualEnd ?? 0)}', overflow: TextOverflow.ellipsis),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 10),
                ],
                TextField(
                  controller: wardController,
                  decoration: const InputDecoration(labelText: 'Ward / Area (optional)'),
                  textInputAction: TextInputAction.next,
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: notesController,
                  decoration: const InputDecoration(labelText: 'Notes (optional)'),
                  minLines: 1,
                  maxLines: 2,
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) => FocusScope.of(context).unfocus(),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: reminderOn,
                  onChanged: (value) => setState(() => reminderOn = value),
                  title: const Text('Reminder ON'),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Select dates in ${DateFormat('MMMM').format(month)}', style: const TextStyle(fontWeight: FontWeight.w900)),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Theme.of(context).dividerColor.withOpacity(0.45)),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
                            .map((day) => Expanded(
                                  child: Center(
                                    child: Text(day, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                                  ),
                                ))
                            .toList(),
                      ),
                      const SizedBox(height: 8),
                      ...List.generate(calendarRows, (row) {
                        return Row(
                          children: List.generate(7, (col) {
                            final cellIndex = row * 7 + col;
                            final day = cellIndex - firstWeekday + 1;
                            if (day < 1 || day > lastDay) {
                              return const Expanded(child: SizedBox(height: 58));
                            }
                            final date = DateTime(month.year, month.month, day);
                            final selected = selectedDays.contains(day);
                            return Expanded(
                              child: Padding(
                                padding: const EdgeInsets.all(3),
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(14),
                                  onTap: () => setState(() => selected ? selectedDays.remove(day) : selectedDays.add(day)),
                                  child: Container(
                                    height: 58,
                                    decoration: BoxDecoration(
                                      color: selected ? selectedShiftColor : Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(0.55),
                                      borderRadius: BorderRadius.circular(14),
                                      border: Border.all(color: selected ? selectedShiftColor : Theme.of(context).dividerColor.withOpacity(0.40)),
                                    ),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text('$day', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: selected ? Colors.white : Theme.of(context).colorScheme.onSurface)),
                                        Text(DateFormat('EEE').format(date), style: TextStyle(fontSize: 9, color: selected ? Colors.white70 : Theme.of(context).colorScheme.onSurfaceVariant)),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }),
                        );
                      }),
                    ],
                  ),
                ),
              ]),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(dialogContext).pop(null), child: const Text('Cancel')),
            FilledButton(
              onPressed: selectedDays.isEmpty
                  ? null
                  : () async {
                      // The notes field keeps the Android keyboard/focus tree active.
                      // Unfocus first and allow one short frame before closing the dialog
                      // to prevent Flutter inherited-widget disposal assertions.
                      FocusManager.instance.primaryFocus?.unfocus();

                      final template = templateByKey(selectedKey);
                      final days = selectedDays.toList()..sort();
                      final wardText = wardController.text.trim();
                      final notesText = notesController.text.trim();
                      final manualText = manualLabelController.text.trim().ifEmpty('Manual');

                      final duties = days.map((day) {
                        final date = DateTime(month.year, month.month, day);
                        return DutyItem(
                          id: '${DateFormat('yyyyMMdd').format(date)}-$selectedKey',
                          date: dateOnly(date),
                          templateKey: selectedKey,
                          label: isManual ? manualText : template.label,
                          startMinutes: isManual ? manualStart : template.startMinutes,
                          endMinutes: isManual ? manualEnd : template.endMinutes,
                          ward: wardText,
                          notes: notesText,
                          reminderOn: reminderOn,
                        );
                      }).toList();

                      await Future<void>.delayed(const Duration(milliseconds: 180));
                      if (dialogContext.mounted) {
                        Navigator.of(dialogContext).pop(duties);
                      }
                    },
              child: const Text('Apply'),
            ),
          ],
        );
      });
    },
  );

  if (dutiesToAdd == null || dutiesToAdd.isEmpty) {
    wardController.dispose();
    notesController.dispose();
    manualLabelController.dispose();
    return;
  }

  // Safety delay: let the dialog route, keyboard, and focused text fields fully
  // settle before updating app state. This prevents Flutter inherited-widget
  // disposal assertions on some Android builds, especially when notes are filled.
  await Future<void>.delayed(const Duration(milliseconds: 500));

  try {
    await state.addOrReplaceDuties(dutiesToAdd);
  } catch (_) {
    // Keep the app stable even if storage fails. The user can retry.
  } finally {
    wardController.dispose();
    notesController.dispose();
    manualLabelController.dispose();
  }
}

Future<void> showManualDutyDialog(BuildContext context, AppState state, DateTime month) async {
  DateTime selectedDate = DateTime(month.year, month.month, DateTime.now().month == month.month ? DateTime.now().day : 1);
  String selectedKey = 'AM';
  final wardController = TextEditingController();
  final notesController = TextEditingController();
  final manualLabelController = TextEditingController(text: 'Manual');
  int? manualStart = 7 * 60;
  int? manualEnd = 15 * 60;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(builder: (context, setState) {
      final isManual = selectedKey == 'MANUAL';
      return AlertDialog(
        title: const Text('Add Duty'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Date'),
              subtitle: Text(DateFormat('MMM d, yyyy').format(selectedDate)),
              trailing: const Icon(Icons.calendar_month),
              onTap: () async {
                final picked = await showDatePicker(context: context, initialDate: selectedDate, firstDate: DateTime(2020), lastDate: DateTime(2100));
                if (picked != null) setState(() => selectedDate = picked);
              },
            ),
            DropdownButtonFormField<String>(
              value: selectedKey,
              decoration: const InputDecoration(labelText: 'Duty Type'),
              isExpanded: true,
              items: shiftDropdownItems(),
              selectedItemBuilder: (context) => kShiftTemplates.map((template) => Align(alignment: Alignment.centerLeft, child: Text(template.label, overflow: TextOverflow.ellipsis))).toList(),
              onChanged: (value) => setState(() => selectedKey = value ?? 'AM'),
            ),
            const SizedBox(height: 6),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(shiftDescription(selectedKey), style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
            ),
            const SizedBox(height: 12),
            if (isManual) ...[
              TextField(controller: manualLabelController, decoration: const InputDecoration(labelText: 'Manual Label')),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: OutlinedButton(onPressed: () async { final picked = await pickMinutes(context, manualStart ?? 7 * 60); if (picked != null) setState(() => manualStart = picked); }, child: Text('Start: ${formatMinutes(manualStart ?? 0)}'))),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton(onPressed: () async { final picked = await pickMinutes(context, manualEnd ?? 15 * 60); if (picked != null) setState(() => manualEnd = picked); }, child: Text('End: ${formatMinutes(manualEnd ?? 0)}'))),
              ]),
              const SizedBox(height: 10),
            ],
            TextField(controller: wardController, decoration: const InputDecoration(labelText: 'Ward / Area')),
            const SizedBox(height: 10),
            TextField(controller: notesController, decoration: const InputDecoration(labelText: 'Notes')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final template = templateByKey(selectedKey);
              await state.addOrReplaceDuties([
                DutyItem(
                  id: DateTime.now().microsecondsSinceEpoch.toString(),
                  date: dateOnly(selectedDate),
                  templateKey: selectedKey,
                  label: isManual ? manualLabelController.text.trim().ifEmpty('Manual') : template.label,
                  startMinutes: isManual ? manualStart : template.startMinutes,
                  endMinutes: isManual ? manualEnd : template.endMinutes,
                  ward: wardController.text,
                  notes: notesController.text,
                  reminderOn: true,
                ),
              ]);
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            child: const Text('Save'),
          ),
        ],
      );
    }),
  );
  wardController.dispose();
  notesController.dispose();
  manualLabelController.dispose();
}

Future<void> showManualLogDialog(BuildContext context, AppState state) async {
  DateTime selectedDate = DateTime.now();
  int timeIn = 7 * 60;
  int timeOut = 15 * 60;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(builder: (context, setState) {
      return AlertDialog(
        title: const Text('Add Manual DTR'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Date'),
            subtitle: Text(DateFormat('MMM d, yyyy').format(selectedDate)),
            trailing: const Icon(Icons.calendar_month),
            onTap: () async {
              final picked = await showDatePicker(context: context, initialDate: selectedDate, firstDate: DateTime(2020), lastDate: DateTime(2100));
              if (picked != null) setState(() => selectedDate = picked);
            },
          ),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: () async { final picked = await pickMinutes(context, timeIn); if (picked != null) setState(() => timeIn = picked); }, child: Text('In: ${formatMinutes(timeIn)}'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton(onPressed: () async { final picked = await pickMinutes(context, timeOut); if (picked != null) setState(() => timeOut = picked); }, child: Text('Out: ${formatMinutes(timeOut)}'))),
          ]),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final date = dateOnly(selectedDate);
              var outDate = date;
              if (timeOut <= timeIn) outDate = outDate.add(const Duration(days: 1));
              final log = DtrLog(
                id: DateTime.now().microsecondsSinceEpoch.toString(),
                date: date,
                timeIn: DateTime(date.year, date.month, date.day, timeIn ~/ 60, timeIn % 60),
                timeOut: DateTime(outDate.year, outDate.month, outDate.day, timeOut ~/ 60, timeOut % 60),
              );
              await state.addManualLog(log);
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            child: const Text('Save'),
          ),
        ],
      );
    }),
  );
}


Future<void> showEditLogDialog(BuildContext context, AppState state, DtrLog originalLog) async {
  DateTime selectedDate = dateOnly(originalLog.date);
  int timeIn = originalLog.timeIn == null ? 7 * 60 : originalLog.timeIn!.hour * 60 + originalLog.timeIn!.minute;
  int timeOut = originalLog.timeOut == null ? 15 * 60 : originalLog.timeOut!.hour * 60 + originalLog.timeOut!.minute;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(builder: (context, setState) {
      return AlertDialog(
        title: const Text('Edit DTR Time'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Date'),
            subtitle: Text(DateFormat('MMM d, yyyy').format(selectedDate)),
            trailing: const Icon(Icons.calendar_month),
            onTap: () async {
              final picked = await showDatePicker(context: context, initialDate: selectedDate, firstDate: DateTime(2020), lastDate: DateTime(2100));
              if (picked != null) setState(() => selectedDate = dateOnly(picked));
            },
          ),
          const SizedBox(height: 8),
          Text('Edit Time In and Time Out separately.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () async {
                  final picked = await pickMinutes(context, timeIn);
                  if (picked != null) setState(() => timeIn = picked);
                },
                icon: const Icon(Icons.login, size: 18),
                label: Text('In: ${formatMinutes(timeIn)}'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () async {
                  final picked = await pickMinutes(context, timeOut);
                  if (picked != null) setState(() => timeOut = picked);
                },
                icon: const Icon(Icons.logout, size: 18),
                label: Text('Out: ${formatMinutes(timeOut)}'),
              ),
            ),
          ]),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton.icon(
            onPressed: () async {
              final date = dateOnly(selectedDate);
              var outDate = date;
              if (timeOut <= timeIn) outDate = outDate.add(const Duration(days: 1));
              final updated = DtrLog(
                id: originalLog.id,
                date: date,
                timeIn: DateTime(date.year, date.month, date.day, timeIn ~/ 60, timeIn % 60),
                timeOut: DateTime(outDate.year, outDate.month, outDate.day, timeOut ~/ 60, timeOut % 60),
              );
              await state.updateLog(updated);
              if (dialogContext.mounted) Navigator.pop(dialogContext);
              if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('DTR time updated.')));
            },
            icon: const Icon(Icons.save_outlined),
            label: const Text('Save'),
          ),
        ],
      );
    }),
  );
}

Future<int?> pickMinutes(BuildContext context, int initialMinutes) async {
  final picked = await showTimePicker(
    context: context,
    initialTime: TimeOfDay(hour: (initialMinutes ~/ 60) % 24, minute: initialMinutes % 60),
  );
  if (picked == null) return null;
  return picked.hour * 60 + picked.minute;
}

void showDutyDetails(BuildContext context, AppState state, DateTime date) {
  final duty = state.dutyForDate(date);
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(DateFormat('MMM d, yyyy').format(date)),
      content: duty == null
          ? const Text('No duty set. This day will show as OFF in DTR summary.')
          : Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(duty.label, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
              const SizedBox(height: 8),
              Text('Time: ${duty.timeRange}'),
              if (duty.ward.trim().isNotEmpty) Text('Ward: ${duty.ward}'),
              if (duty.notes.trim().isNotEmpty) Text('Notes: ${duty.notes}'),
            ]),
      actions: [
        if (duty != null) TextButton(onPressed: () async { await state.deleteDuty(duty.id); if (context.mounted) Navigator.pop(context); }, child: const Text('Delete')),
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
      ],
    ),
  );
}


enum CalendarExportAction { printPdf, savePng }

Future<void> showCalendarExportDialog(BuildContext context, AppState state, DateTime initialMonth, CalendarExportAction action) async {
  DateTime month = initialMonth;
  DtrPeriod period = DtrPeriod.wholeMonth;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(builder: (context, setState) {
      return AlertDialog(
        title: Text(action == CalendarExportAction.printPdf ? 'Print Duty Calendar' : 'Save Calendar as PNG'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          MonthSelector(
            month: month,
            onPrevious: () => setState(() => month = DateTime(month.year, month.month - 1)),
            onNext: () => setState(() => month = DateTime(month.year, month.month + 1)),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<DtrPeriod>(
            value: period,
            decoration: const InputDecoration(labelText: 'Calendar Range'),
            items: DtrPeriod.values.map((p) => DropdownMenuItem(value: p, child: Text(p.label))).toList(),
            onChanged: (value) => setState(() => period = value ?? DtrPeriod.wholeMonth),
          ),
          const SizedBox(height: 10),
          Text(
            action == CalendarExportAction.printPdf
                ? 'Prints a graphic calendar layout for the selected range.'
                : 'Creates a PNG image you can save or share from your phone.',
            style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton.icon(
            onPressed: () async {
              if (action == CalendarExportAction.printPdf) {
                await Printing.layoutPdf(
                  name: 'N-Life-Duty-Calendar-${DateFormat('yyyy-MM').format(month)}-${periodFileSlug(period)}.pdf',
                  onLayout: (_) => buildDutyCalendarPdf(state, month, period),
                );
              } else {
                await shareDutyCalendarPng(state, month, period);
              }
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            icon: Icon(action == CalendarExportAction.printPdf ? Icons.print_outlined : Icons.image_outlined),
            label: Text(action == CalendarExportAction.printPdf ? 'Print' : 'Save PNG'),
          ),
        ],
      );
    }),
  );
}

String periodFileSlug(DtrPeriod period) {
  switch (period) {
    case DtrPeriod.firstHalf:
      return '1-15';
    case DtrPeriod.secondHalf:
      return '16-end';
    case DtrPeriod.wholeMonth:
      return 'whole-month';
  }
}

PdfColor pdfColorForKey(String key) {
  final color = dutyColorForKey(key);
  return PdfColor(color.red / 255, color.green / 255, color.blue / 255);
}

Future<Uint8List> buildDutyCalendarPdf(AppState state, DateTime month, DtrPeriod period) async {
  final pdf = pw.Document();
  final first = DateTime(month.year, month.month, 1);
  final last = DateTime(month.year, month.month + 1, 0);
  final leadingBlanks = first.weekday % 7;
  final totalCells = leadingBlanks + last.day;
  final rows = (totalCells / 7).ceil();
  final selectedDays = datesForPeriod(month, period).map((date) => date.day).toSet();
  final duties = state.dutiesForMonth(month).where((duty) => selectedDays.contains(duty.date.day)).toList();

  pw.Widget calendarCell(int row, int col) {
    final cellIndex = row * 7 + col;
    final dayNumber = cellIndex - leadingBlanks + 1;
    if (dayNumber < 1 || dayNumber > last.day) {
      return pw.Expanded(child: pw.SizedBox(height: 72));
    }
    final date = DateTime(month.year, month.month, dayNumber);
    final isSelected = selectedDays.contains(dayNumber);
    final duty = state.dutyForDate(date);
    final label = duty == null ? 'OFF' : calendarLabelForDuty(duty);
    final time = duty?.timeRange ?? '--';
    final color = isSelected ? (duty == null ? pdfColorForKey('OFF') : pdfColorForKey(duty.templateKey)) : PdfColors.grey400;
    final bgColor = isSelected ? PdfColors.white : PdfColors.grey200;

    return pw.Expanded(
      child: pw.Container(
        height: 72,
        margin: const pw.EdgeInsets.all(2.4),
        padding: const pw.EdgeInsets.all(4),
        decoration: pw.BoxDecoration(
          color: bgColor,
          borderRadius: pw.BorderRadius.circular(8),
          border: pw.Border.all(color: color, width: 1),
        ),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text('$dayNumber ${DateFormat('EEE').format(date)}', style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, color: isSelected ? PdfColors.black : PdfColors.grey600)),
            pw.Spacer(),
            if (isSelected)
              pw.Container(
                width: double.infinity,
                padding: const pw.EdgeInsets.symmetric(vertical: 3, horizontal: 2),
                decoration: pw.BoxDecoration(color: color, borderRadius: pw.BorderRadius.circular(5)),
                child: pw.Text(label, textAlign: pw.TextAlign.center, style: pw.TextStyle(fontSize: label.length > 5 ? 6.2 : 7.4, color: PdfColors.white, fontWeight: pw.FontWeight.bold)),
              ),
            if (isSelected) pw.SizedBox(height: 2),
            if (isSelected) pw.Text(time, maxLines: 1, style: const pw.TextStyle(fontSize: 5.6, color: PdfColors.grey800)),
          ],
        ),
      ),
    );
  }

  pw.Widget legendItem(String key, String label) {
    final color = pdfColorForKey(key);
    return pw.Container(
      margin: const pw.EdgeInsets.only(right: 10, bottom: 5),
      child: pw.Row(mainAxisSize: pw.MainAxisSize.min, children: [
        pw.Container(width: 10, height: 10, decoration: pw.BoxDecoration(color: color, borderRadius: pw.BorderRadius.circular(3))),
        pw.SizedBox(width: 4),
        pw.Text(label, style: const pw.TextStyle(fontSize: 8)),
      ]),
    );
  }

  pdf.addPage(
    pw.Page(
      pageFormat: PdfPageFormat.a4.landscape,
      margin: const pw.EdgeInsets.all(22),
      build: (context) => pw.Container(
        decoration: pw.BoxDecoration(borderRadius: pw.BorderRadius.circular(14), border: pw.Border.all(color: PdfColors.blueGrey200)),
        padding: const pw.EdgeInsets.all(16),
        child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
          pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.symmetric(vertical: 10, horizontal: 14),
            decoration: pw.BoxDecoration(color: PdfColor(kDefaultPrimary.red / 255, kDefaultPrimary.green / 255, kDefaultPrimary.blue / 255), borderRadius: pw.BorderRadius.circular(10)),
            child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
              pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
                pw.Text('N-Life Duty Calendar', style: pw.TextStyle(fontSize: 18, color: PdfColors.white, fontWeight: pw.FontWeight.bold)),
                pw.Text('${DateFormat('MMMM yyyy').format(month)} • ${period.label}', style: const pw.TextStyle(fontSize: 9, color: PdfColors.white)),
              ]),
              pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
                pw.Text(state.dtrName, style: pw.TextStyle(fontSize: 10, color: PdfColors.white, fontWeight: pw.FontWeight.bold)),
                if (state.hospitalName.trim().isNotEmpty) pw.Text(state.hospitalName, style: const pw.TextStyle(fontSize: 8, color: PdfColors.white)),
              ]),
            ]),
          ),
          pw.SizedBox(height: 9),
          pw.Row(
            children: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
                .map((day) => pw.Expanded(child: pw.Container(padding: const pw.EdgeInsets.all(4), alignment: pw.Alignment.center, child: pw.Text(day, style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)))))
                .toList(),
          ),
          ...List.generate(rows, (row) => pw.Row(children: List.generate(7, (col) => calendarCell(row, col)))),
          pw.SizedBox(height: 8),
          pw.Wrap(children: [
            legendItem('AM', 'AM'),
            legendItem('PM', 'PM'),
            legendItem('GRAVEYARD', 'Graveyard'),
            legendItem('12H_AM', '12H AM'),
            legendItem('12H_PM', '12H PM'),
            legendItem('OFF', 'OFF'),
            legendItem('LEAVE', 'Leave'),
            legendItem('MANUAL', 'Manual'),
          ]),
          pw.Spacer(),
          pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
            pw.Text('Total scheduled duties: ${duties.where((duty) => !duty.isOff).length}', style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)),
            pw.Text('Generated by N-Life • Developed by $kDeveloperName', style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
          ]),
        ]),
      ),
    ),
  );
  return pdf.save();
}

Future<void> shareDutyCalendarPng(AppState state, DateTime month, DtrPeriod period) async {
  final bytes = await buildDutyCalendarPng(state, month, period);
  final directory = await getTemporaryDirectory();
  final file = File('${directory.path}/N-Life-Duty-Calendar-${DateFormat('yyyy-MM').format(month)}-${periodFileSlug(period)}.png');
  await file.writeAsBytes(bytes, flush: true);
  await Share.shareXFiles([XFile(file.path)], text: 'N-Life Duty Calendar - ${DateFormat('MMMM yyyy').format(month)} ${period.label}');
}

Future<Uint8List> buildDutyCalendarPng(AppState state, DateTime month, DtrPeriod period) async {
  const double width = 1600;
  const double height = 1100;
  final recorder = ui.PictureRecorder();
  final canvas = Canvas(recorder);
  final paint = Paint()..color = Colors.white;
  canvas.drawRect(const Rect.fromLTWH(0, 0, width, height), paint);

  final headerPaint = Paint()..color = kDefaultPrimary;
  canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(50, 40, 1500, 120), const Radius.circular(26)), headerPaint);
  drawCanvasText(canvas, 'N-Life Duty Calendar', const Offset(82, 66), 38, Colors.white, FontWeight.w900, maxWidth: 800);
  drawCanvasText(canvas, '${DateFormat('MMMM yyyy').format(month)} • ${period.label}', const Offset(84, 112), 22, Colors.white.withOpacity(0.92), FontWeight.w600, maxWidth: 750);
  drawCanvasText(canvas, state.dtrName, const Offset(990, 70), 24, Colors.white, FontWeight.w800, maxWidth: 510, alignRight: true);
  if (state.hospitalName.trim().isNotEmpty) {
    drawCanvasText(canvas, state.hospitalName, const Offset(990, 108), 20, Colors.white.withOpacity(0.92), FontWeight.w500, maxWidth: 510, alignRight: true);
  }

  final first = DateTime(month.year, month.month, 1);
  final last = DateTime(month.year, month.month + 1, 0);
  final leadingBlanks = first.weekday % 7;
  final selectedDays = datesForPeriod(month, period).map((date) => date.day).toSet();
  const double left = 50;
  const double top = 210;
  const double cellW = 1500 / 7;
  const double cellH = 125;

  for (var i = 0; i < 7; i++) {
    drawCanvasText(canvas, ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][i], Offset(left + i * cellW, 178), 22, const Color(0xFF1E293B), FontWeight.w900, maxWidth: cellW, center: true);
  }

  final totalCells = leadingBlanks + last.day;
  final rows = (totalCells / 7).ceil();
  for (var row = 0; row < rows; row++) {
    for (var col = 0; col < 7; col++) {
      final cellIndex = row * 7 + col;
      final dayNumber = cellIndex - leadingBlanks + 1;
      final x = left + col * cellW;
      final y = top + row * cellH;
      if (dayNumber < 1 || dayNumber > last.day) continue;
      final date = DateTime(month.year, month.month, dayNumber);
      final isSelected = selectedDays.contains(dayNumber);
      final duty = state.dutyForDate(date);
      final key = duty?.templateKey ?? 'OFF';
      final label = duty == null ? 'OFF' : calendarLabelForDuty(duty);
      final color = isSelected ? dutyColorForKey(key) : const Color(0xFFCBD5E1);
      final bg = isSelected ? color.withOpacity(0.10) : const Color(0xFFF1F5F9);
      final border = Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 3;
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x + 6, y + 6, cellW - 12, cellH - 12), const Radius.circular(18)), Paint()..color = bg);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x + 6, y + 6, cellW - 12, cellH - 12), const Radius.circular(18)), border);
      drawCanvasText(canvas, '$dayNumber ${DateFormat('EEE').format(date)}', Offset(x + 22, y + 18), 19, isSelected ? const Color(0xFF1E293B) : const Color(0xFF94A3B8), FontWeight.w900, maxWidth: cellW - 44);
      if (isSelected) {
        canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x + 20, y + 62, cellW - 40, 34), const Radius.circular(14)), Paint()..color = color);
        drawCanvasText(canvas, label, Offset(x + 20, y + 68), label.length > 6 ? 15 : 17, Colors.white, FontWeight.w900, maxWidth: cellW - 40, center: true);
        drawCanvasText(canvas, duty?.timeRange ?? '--', Offset(x + 22, y + 102), 14, const Color(0xFF475569), FontWeight.w600, maxWidth: cellW - 44, center: true);
      }
    }
  }

  final legendY = 950.0;
  double legendX = 65;
  for (final item in const [
    ['AM', 'AM'], ['PM', 'PM'], ['GRAVEYARD', 'Graveyard'], ['12H_AM', '12H AM'], ['12H_PM', '12H PM'], ['OFF', 'OFF'], ['LEAVE', 'Leave'], ['MANUAL', 'Manual'],
  ]) {
    final color = dutyColorForKey(item[0]!);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(legendX, legendY, 28, 28), const Radius.circular(8)), Paint()..color = color);
    drawCanvasText(canvas, item[1]!, Offset(legendX + 38, legendY + 1), 19, const Color(0xFF334155), FontWeight.w700, maxWidth: 150);
    legendX += item[1]!.length > 7 ? 185 : 125;
  }
  final periodDates = datesForPeriod(month, period);
  final scheduledHours = periodDates.fold<double>(0, (sum, date) {
    final duty = state.dutyForDate(date);
    return sum + (duty == null || duty.isOff ? 0.0 : duty.scheduledHours);
  });
  final dutyCounts = <String, int>{};
  for (final date in periodDates) {
    final duty = state.dutyForDate(date);
    final key = duty?.templateKey ?? 'OFF';
    dutyCounts[key] = (dutyCounts[key] ?? 0) + 1;
  }
  final countText = ['AM', 'PM', 'GRAVEYARD', '12H_AM', '12H_PM', 'OFF', 'LEAVE']
      .where((key) => (dutyCounts[key] ?? 0) > 0)
      .map((key) => '${templateByKey(key).label}: ${dutyCounts[key]}')
      .join(' • ');
  drawCanvasText(canvas, 'Schedule Summary: Total scheduled hours ${hoursText(scheduledHours)}', const Offset(55, 990), 20, const Color(0xFF1E293B), FontWeight.w900, maxWidth: 1050);
  drawCanvasText(canvas, countText, const Offset(55, 1018), 17, const Color(0xFF475569), FontWeight.w700, maxWidth: 1300);
  drawCanvasText(canvas, 'Generated by N-Life • Developed by $kDeveloperName', const Offset(55, 1060), 18, const Color(0xFF64748B), FontWeight.w500, maxWidth: 1000);

  final picture = recorder.endRecording();
  final image = await picture.toImage(width.toInt(), height.toInt());
  final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
  return byteData!.buffer.asUint8List();
}

void drawCanvasText(Canvas canvas, String text, Offset offset, double fontSize, Color color, FontWeight weight, {double maxWidth = 400, bool center = false, bool alignRight = false}) {
  final painter = TextPainter(
    text: TextSpan(text: text, style: TextStyle(fontSize: fontSize, color: color, fontWeight: weight)),
    textDirection: ui.TextDirection.ltr,
    maxLines: 2,
    ellipsis: '…',
  )..layout(maxWidth: maxWidth);
  double dx = offset.dx;
  if (center) dx = offset.dx + (maxWidth - painter.width) / 2;
  if (alignRight) dx = offset.dx + (maxWidth - painter.width);
  painter.paint(canvas, Offset(dx, offset.dy));
}

Future<void> showExportDtrDialog(BuildContext context, AppState state) async {
  final now = DateTime.now();
  DateTime month = DateTime(now.year, now.month);
  DtrPeriod period = now.day <= 15 ? DtrPeriod.firstHalf : DtrPeriod.secondHalf;

  await showDialog(
    context: context,
    builder: (dialogContext) => StatefulBuilder(builder: (context, setState) {
      return AlertDialog(
        title: const Text('Export DTR PDF'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          MonthSelector(month: month, onPrevious: () => setState(() => month = DateTime(month.year, month.month - 1)), onNext: () => setState(() => month = DateTime(month.year, month.month + 1))),
          const SizedBox(height: 12),
          DropdownButtonFormField<DtrPeriod>(
            value: period,
            decoration: const InputDecoration(labelText: 'Period'),
            items: DtrPeriod.values.map((p) => DropdownMenuItem(value: p, child: Text(p.label))).toList(),
            onChanged: (value) => setState(() => period = value ?? DtrPeriod.firstHalf),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton.icon(
            onPressed: () async {
              final pdfBytes = await buildDtrPdf(state, month, period);
              await Printing.sharePdf(bytes: pdfBytes, filename: 'N-Life-DTR-${DateFormat('yyyy-MM').format(month)}-${period.name}.pdf');
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            icon: const Icon(Icons.picture_as_pdf),
            label: const Text('Export'),
          ),
        ],
      );
    }),
  );
}

Future<Uint8List> buildDtrPdf(AppState state, DateTime month, DtrPeriod period) async {
  final pdf = pw.Document();
  final dates = datesForPeriod(month, period);
  final totals = state.totalsFor(month, period);
  final data = dates.map((date) {
    final log = state.logForDate(date);
    return [
      DateFormat('MMM d').format(date),
      DateFormat('EEE').format(date),
      state.dutyLabelForDate(date, log),
      formatDateTime(log?.timeIn),
      formatDateTime(log?.timeOut),
      hoursText(log?.actualHours ?? 0.0),
      hoursText(state.paidHoursForLog(date, log)),
      state.remarksFor(date, log),
    ];
  }).toList();

  pdf.addPage(
    pw.MultiPage(
      build: (context) => [
        pw.Text('N-Life DTR Summary', style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        pw.Text('Name: ${state.dtrName}'),
        if (state.hospitalName.trim().isNotEmpty) pw.Text('Hospital: ${state.hospitalName}'),
        if (state.position.trim().isNotEmpty) pw.Text('Position: ${state.position}'),
        if (state.department.trim().isNotEmpty) pw.Text('Department/Ward: ${state.department}'),
        pw.Text('Period: ${periodTitle(month, period)}'),
        pw.SizedBox(height: 16),
        pw.Table.fromTextArray(
          headers: ['Date', 'Day', 'Duty', 'In', 'Out', 'Actual', 'Paid', 'Remarks'],
          data: data,
          headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
          cellStyle: pw.TextStyle(fontSize: 9),
        ),
        pw.SizedBox(height: 16),
        pw.Text('Total Actual Hours: ${hoursText(totals.actualHours)}'),
        pw.Text('Total Paid Hours: ${hoursText(totals.paidHours)}'),
        pw.Text('Equivalent Paid Days: ${totals.equivalentPaidDays.toStringAsFixed(2)}'),
        pw.Text('Estimated Salary: ${pdfMoney(totals.estimatedSalary)}'),
        pw.SizedBox(height: 20),
        pw.Text('Generated by N-Life - Developed by $kDeveloperName', style: pw.TextStyle(fontSize: 9)),
      ],
    ),
  );
  return pdf.save();
}


List<CsForm48Row> csForm48Rows(AppState state, DateTime month, DtrPeriod period) {
  final last = DateTime(month.year, month.month + 1, 0).day;
  return List.generate(31, (index) {
    final day = index + 1;
    if (day > last) {
      return CsForm48Row(day: day, amArrival: '', amDeparture: '', pmArrival: '', pmDeparture: '', undertimeHours: '', undertimeMinutes: '', note: '');
    }
    final date = DateTime(month.year, month.month, day);
    final selected = datesForPeriod(month, period).any((d) => isSameDate(d, date));
    if (!selected) {
      return CsForm48Row(day: day, amArrival: '', amDeparture: '', pmArrival: '', pmDeparture: '', undertimeHours: '', undertimeMinutes: '', note: '');
    }
    final duty = state.dutyForDate(date);
    final log = state.logForDate(date);
    return csForm48RowForDate(state, date, duty, log);
  });
}

CsForm48Row csForm48RowForDate(AppState state, DateTime date, DutyItem? duty, DtrLog? log) {
  if (duty != null && duty.isOff) {
    final label = duty.templateKey == 'LEAVE' ? 'Leave' : 'OFF';
    return CsForm48Row(day: date.day, amArrival: label, amDeparture: '', pmArrival: '', pmDeparture: '', undertimeHours: '', undertimeMinutes: '', note: label);
  }

  DateTime? timeIn = log?.timeIn;
  DateTime? timeOut = log?.timeOut;

  if ((timeIn == null || timeOut == null) && duty != null && duty.startMinutes != null && duty.endMinutes != null && !duty.isOff) {
    timeIn ??= dateTimeFromMinutes(date, duty.startMinutes!);
    timeOut ??= dateTimeFromMinutes(date, duty.endMinutes!);
    if (timeOut.isBefore(timeIn)) timeOut = timeOut.add(const Duration(days: 1));
  }

  String amArrival = '';
  String amDeparture = '';
  String pmArrival = '';
  String pmDeparture = '';

  final key = duty?.templateKey ?? '';
  if (key == 'PM') {
    pmArrival = csTimeText(timeIn);
    pmDeparture = csTimeText(timeOut);
  } else if (key == 'GRAVEYARD' || key == '12H_PM') {
    pmArrival = csTimeText(timeIn);
    amDeparture = csTimeText(timeOut);
  } else if (key == 'AM' || key == '12H_AM') {
    amArrival = csTimeText(timeIn);
    pmDeparture = csTimeText(timeOut);
  } else {
    void placeTime(DateTime? value, bool isArrival) {
      if (value == null) return;
      final formatted = csTimeText(value);
      if (value.hour < 12) {
        if (isArrival) amArrival = formatted; else amDeparture = formatted;
      } else {
        if (isArrival) pmArrival = formatted; else pmDeparture = formatted;
      }
    }
    placeTime(timeIn, true);
    placeTime(timeOut, false);
  }

  return CsForm48Row(
    day: date.day,
    amArrival: amArrival,
    amDeparture: amDeparture,
    pmArrival: pmArrival,
    pmDeparture: pmDeparture,
    undertimeHours: csDutyHoursText(state, date, duty, log),
    undertimeMinutes: csDutyTimeCode(duty, timeIn, timeOut),
    note: duty == null ? '' : calendarLabelForDuty(duty),
  );
}

DateTime dateTimeFromMinutes(DateTime date, int minutes) {
  final hour = (minutes ~/ 60) % 24;
  final minute = minutes % 60;
  return DateTime(date.year, date.month, date.day, hour, minute);
}

String csTimeText(DateTime? value) {
  if (value == null) return '';
  return DateFormat('h:mm').format(value);
}

String csDutyHoursText(AppState state, DateTime date, DutyItem? duty, DtrLog? log) {
  if (duty != null && duty.isOff) return '';
  double hours = 0;
  if (duty != null && duty.scheduledHours > 0) {
    hours = duty.isTwelveHour ? 12.0 : duty.scheduledHours;
  } else {
    hours = state.paidHoursForLog(date, log);
  }
  if (hours <= 0) return '';
  if ((hours - hours.round()).abs() < 0.01) return hours.round().toString();
  return hours.toStringAsFixed(1);
}

String csDutyTimeCode(DutyItem? duty, DateTime? timeIn, DateTime? timeOut) {
  if (duty == null || duty.isOff) return '';
  switch (duty.templateKey) {
    case 'AM':
      return '7-3';
    case 'PM':
      return '3-11';
    case 'GRAVEYARD':
      return '11-7';
    case '12H_AM':
      return '7-7';
    case '12H_PM':
      return '7-7';
    default:
      if (duty.startMinutes != null && duty.endMinutes != null) return csMinutesCode(duty.startMinutes!, duty.endMinutes!);
      if (timeIn != null && timeOut != null) return '${DateFormat('h').format(timeIn)}-${DateFormat('h').format(timeOut)}';
      return '';
  }
}

String csMinutesCode(int start, int end) {
  int hour(int minutes) {
    final h24 = (minutes ~/ 60) % 24;
    final h12 = h24 % 12;
    return h12 == 0 ? 12 : h12;
  }
  return '${hour(start)}-${hour(end)}';
}

String csTotalHours(List<CsForm48Row> rows) {
  double total = 0;
  for (final row in rows) {
    final parsed = double.tryParse(row.undertimeHours);
    if (parsed != null) total += parsed;
  }
  if (total <= 0) return '';
  if ((total - total.round()).abs() < 0.01) return total.round().toString();
  return total.toStringAsFixed(1);
}

String csPeriodTitle(DateTime month, DtrPeriod period) {
  switch (period) {
    case DtrPeriod.firstHalf:
      return '${DateFormat('MMMM').format(month)} 1-15, ${month.year}';
    case DtrPeriod.secondHalf:
      final last = DateTime(month.year, month.month + 1, 0).day;
      return '${DateFormat('MMMM').format(month)} 16-$last, ${month.year}';
    case DtrPeriod.wholeMonth:
      return DateFormat('MMMM yyyy').format(month);
  }
}

String generateCsForm48Guide(AppState state, DateTime month, DtrPeriod period) {
  final buffer = StringBuffer();
  buffer.writeln('Civil Service Form No. 48 - Daily Time Record Guide');
  buffer.writeln('Name: ${state.dtrName}');
  if (state.hospitalName.trim().isNotEmpty) buffer.writeln('Hospital: ${state.hospitalName}');
  buffer.writeln('For the month of: ${csPeriodTitle(month, period)}');
  buffer.writeln('Note: rows outside the selected cut-off are intentionally blank.');
  buffer.writeln('');
  buffer.writeln('Day | AM Arrival | AM Departure | PM Arrival | PM Departure | Hours | Minutes');
  for (final row in csForm48Rows(state, month, period)) {
    buffer.writeln('${row.day} | ${row.amArrival.ifEmpty('--')} | ${row.amDeparture.ifEmpty('--')} | ${row.pmArrival.ifEmpty('--')} | ${row.pmDeparture.ifEmpty('--')} | ${row.undertimeHours.ifEmpty('--')} | ${row.undertimeMinutes.ifEmpty('--')}');
  }
  buffer.writeln('Total hours: ${csTotalHours(csForm48Rows(state, month, period)).ifEmpty('--')}');
  return buffer.toString();
}

Future<Uint8List> buildCsForm48Pdf(AppState state, DateTime month, DtrPeriod period) async {
  final pdf = pw.Document();
  final rows = csForm48Rows(state, month, period);
  const longBondPortrait = PdfPageFormat(612, 936);

  pdf.addPage(
    pw.Page(
      pageFormat: longBondPortrait,
      margin: const pw.EdgeInsets.fromLTRB(34, 34, 34, 38),
      build: (context) => pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: [
          pw.Expanded(child: _pdfCsForm48Copy(state, month, period, rows)),
          pw.SizedBox(width: 18),
          pw.Expanded(child: _pdfCsForm48Copy(state, month, period, rows)),
        ],
      ),
    ),
  );
  return pdf.save();
}

pw.Widget _pdfCsOrnament() {
  return pw.Row(
    mainAxisAlignment: pw.MainAxisAlignment.center,
    children: [
      pw.Container(width: 18, height: 0.55, color: PdfColors.black),
      pw.SizedBox(width: 3),
      pw.Text('o0o', style: const pw.TextStyle(fontSize: 6.5)),
      pw.SizedBox(width: 3),
      pw.Container(width: 18, height: 0.55, color: PdfColors.black),
    ],
  );
}

pw.Widget _pdfCsForm48Copy(AppState state, DateTime month, DtrPeriod period, List<CsForm48Row> rows) {
  final nurseName = state.dtrName.trim();
  return pw.Column(
    crossAxisAlignment: pw.CrossAxisAlignment.stretch,
    children: [
      pw.SizedBox(height: 22),
      pw.Text('Civil Service Form No. 48', style: pw.TextStyle(fontSize: 6.7, fontStyle: pw.FontStyle.italic)),
      pw.SizedBox(height: 10),
      pw.Text('DAILY TIME RECORD', textAlign: pw.TextAlign.center, style: pw.TextStyle(fontSize: 13.5, fontWeight: pw.FontWeight.bold)),
      pw.SizedBox(height: 2),
      _pdfCsOrnament(),
      pw.SizedBox(height: 25),
      pw.Text(nurseName, textAlign: pw.TextAlign.center, style: pw.TextStyle(fontSize: 7.6, fontWeight: pw.FontWeight.bold)),
      pw.Container(height: 0.65, color: PdfColors.black),
      pw.Text('(Name)', textAlign: pw.TextAlign.center, style: const pw.TextStyle(fontSize: 5.3)),
      pw.SizedBox(height: 9),
      pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.end,
        children: [
          pw.Text('For the month of', style: const pw.TextStyle(fontSize: 6.1)),
          pw.SizedBox(width: 4),
          pw.Expanded(
            child: pw.Container(
              padding: const pw.EdgeInsets.only(bottom: 1),
              decoration: const pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(width: 0.55))),
              child: pw.Text(csPeriodTitle(month, period), textAlign: pw.TextAlign.center, style: const pw.TextStyle(fontSize: 6.1)),
            ),
          ),
        ],
      ),
      pw.SizedBox(height: 4),
      pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Expanded(
            child: pw.Text('Official hours for\narrival and departure', style: const pw.TextStyle(fontSize: 5.6)),
          ),
          pw.SizedBox(width: 6),
          pw.Expanded(
            child: pw.Column(
              children: [
                _pdfCsLabelLine('Regular days'),
                pw.SizedBox(height: 2),
                _pdfCsLabelLine('Saturdays'),
              ],
            ),
          ),
        ],
      ),
      pw.SizedBox(height: 7),
      _pdfCsTable(rows),
      pw.SizedBox(height: 11),
      pw.Text(
        'I certify on my honor that the above is a true and correct report of the hours of work performed, record of which was made daily at the time of arrival and departure from office.',
        style: const pw.TextStyle(fontSize: 5.2),
      ),
      pw.SizedBox(height: 18),
      pw.Container(height: 0.75, color: PdfColors.black),
      pw.SizedBox(height: 10),
      pw.Text('VERIFIED as to the prescribed office hours:', style: const pw.TextStyle(fontSize: 5.3)),
      pw.SizedBox(height: 22),
      pw.Text(
        'ARLAN ROSEGRACE S. BALANE-GALICIA, MD,\nFPAFP, MMHoA',
        textAlign: pw.TextAlign.center,
        style: pw.TextStyle(fontSize: 6.4, fontWeight: pw.FontWeight.bold),
      ),
      pw.SizedBox(height: 2),
      pw.Container(height: 0.75, color: PdfColors.black),
      pw.Text('OIC-Chief of Hospital I', textAlign: pw.TextAlign.center, style: const pw.TextStyle(fontSize: 5.3)),
      pw.Spacer(),
    ],
  );
}

pw.Widget _pdfCsLabelLine(String label) {
  return pw.Row(
    crossAxisAlignment: pw.CrossAxisAlignment.end,
    children: [
      pw.Text(label, style: const pw.TextStyle(fontSize: 5.6)),
      pw.SizedBox(width: 3),
      pw.Expanded(child: pw.Container(height: 0.5, color: PdfColors.black)),
    ],
  );
}

pw.Widget _pdfCsTable(List<CsForm48Row> rows) {
  return pw.Table(
    border: pw.TableBorder.all(color: PdfColors.black, width: 0.42),
    columnWidths: const {
      0: pw.FixedColumnWidth(18),
      1: pw.FlexColumnWidth(),
      2: pw.FlexColumnWidth(),
      3: pw.FlexColumnWidth(),
      4: pw.FlexColumnWidth(),
      5: pw.FixedColumnWidth(25),
      6: pw.FixedColumnWidth(28),
    },
    children: [
      pw.TableRow(children: [
        _pdfCell('Day', bold: true, height: 11.5),
        _pdfCell('A.M.', bold: true, height: 11.5),
        _pdfCell('', height: 11.5),
        _pdfCell('P.M.', bold: true, height: 11.5),
        _pdfCell('', height: 11.5),
        _pdfCell('Undertime', bold: true, height: 11.5),
        _pdfCell('', height: 11.5),
      ]),
      pw.TableRow(children: [
        _pdfCell('', height: 12),
        _pdfCell('Arrival', bold: true, height: 12),
        _pdfCell('Depar-\nture', bold: true, height: 12),
        _pdfCell('Arrival', bold: true, height: 12),
        _pdfCell('Depar-\nture', bold: true, height: 12),
        _pdfCell('Hours', bold: true, height: 12),
        _pdfCell('Min-\nutes', bold: true, height: 12),
      ]),
      ...rows.map((row) => pw.TableRow(children: [
        _pdfCell(row.day.toString(), bold: true),
        _pdfCell(row.amArrival),
        _pdfCell(row.amDeparture),
        _pdfCell(row.pmArrival),
        _pdfCell(row.pmDeparture),
        _pdfCell(row.undertimeHours),
        _pdfCell(row.undertimeMinutes),
      ])),
      pw.TableRow(children: [
        _pdfCell('', height: 10),
        _pdfCell('', height: 10),
        _pdfCell('', height: 10),
        _pdfCell('', height: 10),
        _pdfCell('Total', bold: true, height: 10),
        _pdfCell(csTotalHours(rows), bold: true, height: 10),
        _pdfCell('', height: 10),
      ]),
    ],
  );
}

pw.Widget _pdfCell(String text, {bool bold = false, double height = 8.7}) {
  return pw.Container(
    height: height,
    alignment: pw.Alignment.center,
    padding: const pw.EdgeInsets.symmetric(horizontal: 0.7),
    child: pw.Text(
      text,
      textAlign: pw.TextAlign.center,
      maxLines: 2,
      style: pw.TextStyle(fontSize: 4.5, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal),
    ),
  );
}

const String kSpmsOicName = 'ARLAN ROSEGRACE S. BALANE-GALICIA MD, FPAFP, MMHoA';
const String kSpmsOicTitle = 'OIC-Chief of Hospital 1';
const List<String> kSpmsActivities = [
  'IV FLUIDS',
  'REFERRED ANY CHANGES IN PATIENTS STATUS',
  'CARRIED OUT DOCTORS RECEIVED/ASSIST PATIENT',
  'PROVIDED MEDICATIONS AS PRESCRIBED BY DOCTORS',
  'ADMINISTERED ORDER/ASSISTED DOCTORS DURING ROUNDS',
  'DOCUMENTED EVERY NURSING INTERVENTIONS THRU CHARTING',
];
final String spmsActivityPreviewText = kSpmsActivities.map((item) => '• $item').join('\n');

String spmsPeriodTitle(DateTime month, DtrPeriod period) {
  switch (period) {
    case DtrPeriod.firstHalf:
      return '${DateFormat('MMMM').format(month).toUpperCase()} 1-15, ${month.year}';
    case DtrPeriod.secondHalf:
      final last = DateTime(month.year, month.month + 1, 0).day;
      return '${DateFormat('MMMM').format(month).toUpperCase()} 16-$last, ${month.year}';
    case DtrPeriod.wholeMonth:
      final last = DateTime(month.year, month.month + 1, 0).day;
      return '${DateFormat('MMMM').format(month).toUpperCase()} 1-$last, ${month.year}';
  }
}

class SpmsRowData {
  const SpmsRowData({required this.date, required this.isOff, required this.quantity});
  final DateTime date;
  final bool isOff;
  final int quantity;
}

int _spmsRowWeight(SpmsRowData row) => row.isOff ? 1 : 3;

int _spmsPageWeight(List<SpmsRowData> rows) => rows.fold<int>(0, (sum, row) => sum + _spmsRowWeight(row));

List<List<SpmsRowData>> spmsPagesFor(AppState state, DateTime month, DtrPeriod period) {
  final rows = datesForPeriod(month, period).map((date) {
    final duty = state.dutyForDate(date);
    final isOff = duty == null || duty.isOff;
    return SpmsRowData(date: date, isOff: isOff, quantity: state.spmsPatientCountForDate(date));
  }).toList();

  final pages = <List<SpmsRowData>>[];
  var current = <SpmsRowData>[];
  var currentWeight = 0;
  var capacity = 6;

  for (final row in rows) {
    final weight = _spmsRowWeight(row);
    if (current.isNotEmpty && currentWeight + weight > capacity) {
      pages.add(current);
      current = <SpmsRowData>[];
      currentWeight = 0;
      capacity = 8;
    }
    current.add(row);
    currentWeight += weight;
  }
  if (current.isNotEmpty) pages.add(current);

  if (pages.isEmpty) pages.add(<SpmsRowData>[]);

  // Reserve enough room on the final page for Prepared by / Noted by.
  final last = pages.last;
  if (_spmsPageWeight(last) > 4) {
    final signaturePage = <SpmsRowData>[];
    while (last.length > 1 && _spmsPageWeight(signaturePage) < 3) {
      signaturePage.insert(0, last.removeLast());
    }
    if (signaturePage.isNotEmpty) pages.add(signaturePage);
  }

  return pages;
}

class SpmsPdfAssets {
  const SpmsPdfAssets({
    required this.header,
    required this.footer,
    required this.watermark,
    required this.building,
  });

  final pw.MemoryImage header;
  final pw.MemoryImage footer;
  final pw.MemoryImage watermark;
  final pw.MemoryImage building;
}

Future<SpmsPdfAssets> _loadSpmsPdfAssets() async {
  Future<pw.MemoryImage> load(String path) async {
    final data = await rootBundle.load(path);
    return pw.MemoryImage(data.buffer.asUint8List());
  }

  return SpmsPdfAssets(
    header: await load('assets/spms_header.png'),
    footer: await load('assets/spms_footer.png'),
    watermark: await load('assets/spms_watermark_clean.png'),
    building: await load('assets/spms_building_clean.png'),
  );
}

Future<Uint8List> buildSpmsPdf(AppState state, DateTime month, DtrPeriod period) async {
  final pdf = pw.Document();
  final assets = await _loadSpmsPdfAssets();
  final pages = spmsPagesFor(state, month, period);

  for (var i = 0; i < pages.length; i++) {
    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.all(0),
        build: (context) => _spmsPdfPage(
          state,
          month,
          period,
          pages[i],
          assets: assets,
          isFirstPage: i == 0,
          isLastPage: i == pages.length - 1,
        ),
      ),
    );
  }
  return pdf.save();
}

pw.Widget _spmsPdfPage(
  AppState state,
  DateTime month,
  DtrPeriod period,
  List<SpmsRowData> rows, {
  required SpmsPdfAssets assets,
  required bool isFirstPage,
  required bool isLastPage,
}) {
  return pw.Stack(
    children: [
      pw.Positioned(left: 0, right: 0, top: 0, bottom: 0, child: pw.Container(color: PdfColors.white)),
      pw.Positioned(
        top: 8,
        left: 0,
        right: 0,
        height: 92,
        child: pw.Image(assets.header, fit: pw.BoxFit.contain),
      ),
      pw.Positioned(
        top: 116,
        left: 190,
        right: 190,
        bottom: 68,
        child: pw.Image(assets.watermark, fit: pw.BoxFit.contain),
      ),
      pw.Positioned(
        bottom: 38,
        left: 235,
        right: 235,
        height: 70,
        child: pw.Image(assets.building, fit: pw.BoxFit.contain),
      ),
      pw.Positioned(
        bottom: 0,
        left: 0,
        right: 0,
        height: 38,
        child: pw.Image(assets.footer, fit: pw.BoxFit.fill),
      ),
      pw.Positioned(
        top: isFirstPage ? 108 : 112,
        left: 36,
        right: 36,
        bottom: 46,
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            if (isFirstPage) ...[
              pw.Text(
                'STRATEGIC PERFORMANCE MANAGEMENT SYSTEM',
                textAlign: pw.TextAlign.center,
                style: pw.TextStyle(fontSize: 13.3, fontWeight: pw.FontWeight.bold),
              ),
              pw.Text(
                'Monitoring Form',
                textAlign: pw.TextAlign.center,
                style: pw.TextStyle(fontSize: 11.5, fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(height: 7),
              pw.Text(
                'Individual Accomplishment',
                textAlign: pw.TextAlign.center,
                style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold),
              ),
              pw.Text(
                'For the week ${spmsPeriodTitle(month, period)}',
                textAlign: pw.TextAlign.center,
                style: pw.TextStyle(fontSize: 10.4, fontStyle: pw.FontStyle.italic, fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(height: 4),
            ],
            _spmsTable(rows, showHeader: isFirstPage),
            if (isLastPage) _spmsSignatureBlock(state),
          ],
        ),
      ),
    ],
  );
}

pw.Widget _spmsTable(List<SpmsRowData> rows, {required bool showHeader}) {
  return pw.Table(
    border: pw.TableBorder.all(color: PdfColors.grey700, width: 0.45),
    columnWidths: const {
      0: pw.FixedColumnWidth(128),
      1: pw.FixedColumnWidth(258),
      2: pw.FixedColumnWidth(176),
      3: pw.FlexColumnWidth(),
    },
    children: [
      if (showHeader)
        pw.TableRow(
          children: [
            _spmsCell('Day', bold: true, italic: true, height: 17, fontSize: 9),
            _spmsCell('Activity', bold: true, italic: true, height: 17, fontSize: 9),
            _spmsCell('Quantity', bold: true, italic: true, height: 17, fontSize: 9),
            _spmsCell('Innovations', bold: true, italic: true, height: 17, fontSize: 9),
          ],
        ),
      ...rows.map(_spmsPdfRow),
    ],
  );
}

pw.TableRow _spmsPdfRow(SpmsRowData row) {
  final rowHeight = row.isOff ? 30.0 : 108.0;
  return pw.TableRow(
    children: [
      _spmsCell(
        '${DateFormat('MMMM d').format(row.date).toUpperCase()}\n${DateFormat('EEEE').format(row.date).toUpperCase()}',
        height: rowHeight,
        fontSize: 9.7,
      ),
      row.isOff ? _spmsCell('OFF', height: rowHeight, fontSize: 10.5) : _spmsActivityCell(rowHeight),
      _spmsCell(row.isOff || row.quantity <= 0 ? '' : '${row.quantity} PATIENTS', height: rowHeight, fontSize: 9.8),
      _spmsCell('', height: rowHeight),
    ],
  );
}

pw.Widget _spmsActivityCell(double height) {
  return pw.Container(
    height: height,
    padding: const pw.EdgeInsets.fromLTRB(16, 7, 8, 5),
    child: pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      mainAxisAlignment: pw.MainAxisAlignment.center,
      children: kSpmsActivities.map((item) {
        return pw.Padding(
          padding: const pw.EdgeInsets.only(bottom: 3.2),
          child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Padding(
                padding: const pw.EdgeInsets.only(top: 3.1),
                child: pw.Container(
                  width: 4,
                  height: 4,
                  decoration: const pw.BoxDecoration(color: PdfColors.black, shape: pw.BoxShape.circle),
                ),
              ),
              pw.SizedBox(width: 8),
              pw.Expanded(child: pw.Text(item, style: const pw.TextStyle(fontSize: 9.2))),
            ],
          ),
        );
      }).toList(),
    ),
  );
}

pw.Widget _spmsCell(String text, {bool bold = false, bool italic = false, double height = 24, double fontSize = 9}) {
  return pw.Container(
    height: height,
    alignment: pw.Alignment.center,
    padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 2),
    child: pw.Text(
      text,
      textAlign: pw.TextAlign.center,
      style: pw.TextStyle(
        fontSize: fontSize,
        fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
        fontStyle: italic ? pw.FontStyle.italic : pw.FontStyle.normal,
      ),
    ),
  );
}

pw.Widget _spmsSignatureBlock(AppState state) {
  final nurseName = state.dtrName.trim().isEmpty ? '____________________________' : state.dtrName.trim().toUpperCase();
  final position = state.position.trim().isEmpty ? 'NURSE I' : state.position.trim().toUpperCase();

  return pw.Padding(
    padding: const pw.EdgeInsets.fromLTRB(62, 12, 62, 4),
    child: pw.Row(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Expanded(
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Prepared by:', style: const pw.TextStyle(fontSize: 9)),
              pw.SizedBox(height: 30),
              pw.Container(height: 0.65, color: PdfColors.black),
              pw.Text(nurseName, textAlign: pw.TextAlign.center, style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)),
              pw.Text(position, textAlign: pw.TextAlign.center, style: const pw.TextStyle(fontSize: 8.7)),
            ],
          ),
        ),
        pw.SizedBox(width: 120),
        pw.Expanded(
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Noted by:', style: const pw.TextStyle(fontSize: 9)),
              pw.SizedBox(height: 30),
              pw.Container(height: 0.65, color: PdfColors.black),
              pw.Text(kSpmsOicName, textAlign: pw.TextAlign.center, style: pw.TextStyle(fontSize: 8.3, fontWeight: pw.FontWeight.bold)),
              pw.Text(kSpmsOicTitle, textAlign: pw.TextAlign.center, style: const pw.TextStyle(fontSize: 8.5)),
            ],
          ),
        ),
      ],
    ),
  );
}

void showAboutNLifeDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('About N-Life'),
      content: const SingleChildScrollView(
        child: Text('N-Life is a personal hospital duty companion created for duty scheduling, DTR tracking, salary estimates, and printable DTR summaries. It is designed for nurses and healthcare workers who want a simple, organized, and professional way to manage duty life.'),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
    ),
  );
}

void showDeveloperDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Developer Credit'),
      content: const Text('''Developed by
Lester Andrei Lomboy, RN

Follow:
Instagram: @Itslester.l
Facebook: Lester Andrei Lomboy

Contact:
lomboylester.nursing@gmail.com'''),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
    ),
  );
}

DateTime dateOnly(DateTime date) => DateTime(date.year, date.month, date.day);

bool isSameDate(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

String formatMinutes(int minutes) {
  final hour = (minutes ~/ 60) % 24;
  final minute = minutes % 60;
  final date = DateTime(2020, 1, 1, hour, minute);
  return DateFormat('h:mm a').format(date);
}

String formatDateTime(DateTime? dateTime) {
  if (dateTime == null) return '--';
  return DateFormat('h:mm a').format(dateTime);
}

String hoursText(double hours) {
  if (hours <= 0) return '--';
  final whole = hours.floor();
  final minutes = ((hours - whole) * 60).round();
  if (minutes == 0) return '$whole hrs';
  return '$whole hrs $minutes mins';
}


String pdfMoney(double value) {
  final formatter = NumberFormat.currency(locale: 'en_PH', symbol: 'PHP ', decimalDigits: 2);
  return formatter.format(value);
}

String peso(double value) {
  final formatter = NumberFormat.currency(locale: 'en_PH', symbol: '₱', decimalDigits: 2);
  return formatter.format(value);
}

String greeting() {
  final hour = DateTime.now().hour;
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

List<DateTime> datesForMonth(DateTime month) {
  final last = DateTime(month.year, month.month + 1, 0).day;
  return List.generate(last, (i) => DateTime(month.year, month.month, i + 1));
}

List<DateTime> datesForPeriod(DateTime month, DtrPeriod period) {
  final last = DateTime(month.year, month.month + 1, 0).day;
  final startDay = period == DtrPeriod.secondHalf ? 16 : 1;
  final endDay = period == DtrPeriod.firstHalf ? 15 : last;
  return List.generate(endDay - startDay + 1, (i) => DateTime(month.year, month.month, startDay + i));
}

String periodTitle(DateTime month, DtrPeriod period) {
  final dates = datesForPeriod(month, period);
  return '${DateFormat('MMM d, yyyy').format(dates.first)} - ${DateFormat('MMM d, yyyy').format(dates.last)}';
}

extension StringFallback on String {
  String ifEmpty(String fallback) => trim().isEmpty ? fallback : trim();
}
