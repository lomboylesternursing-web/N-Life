# N-Life v1.0 Stable Launch

Final V1 launch package.

Included features:
- Duty schedule calendar
- Fast Add Monthly Duty
- Color-coded duty labels
- Today’s Duty and Tomorrow’s Duty
- DTR tracking
- DTR Sheet preview
- Copy Summary
- View DTR fullscreen with zoom/pan
- Print DTR
- Export DTR PDF
- Daily Rate / Hourly Rate salary mode
- Editable name and hospital name
- Light theme default and dark mode option
- Official N-Life branding/logo

Latest V1 addition:
- Added View Calendar button in the Duty tab.
- Added Print Calendar button in the Duty tab.
- Duty Calendar fullscreen preview supports pinch zoom and drag/pan.
- Duty Calendar PDF includes date, day, duty label, time, ward, and notes.

Launch name:
N-Life v1.0
Tagline: Schedule. Track. Manage. Thrive.

Developed by Lester Andrei Lomboy, RN.
