# N-Life Android App MVP

N-Life is a Flutter Android app prototype for hospital duty tracking.

## Included features

- Dark blue professional theme
- Home dashboard
- Duty schedule list with Add Duty form
- DTR tracking with Time In / Time Out
- Estimated salary based on daily rate and required hours
- Salary summary for 1-15 and 16-end cut-off
- Settings for daily rate and required hours
- Offline local storage using SharedPreferences

## Easiest APK build option: GitHub Actions

This project now includes an automatic APK builder:

```text
.github/workflows/build-android-apk.yml
```

### How to use it

1. Create a free GitHub account if you do not have one.
2. Create a new repository, for example: `n-life-app`.
3. Upload all files from this project folder to that repository.
4. Open your repository on GitHub.
5. Go to **Actions**.
6. Select **Build N-Life Android APK**.
7. Tap **Run workflow**.
8. Wait for the build to finish.
9. Open the finished workflow run.
10. Download the artifact named **N-Life-debug-apk**.
11. Extract the downloaded ZIP and install `app-debug.apk` on your Android phone.

This is the easiest way because GitHub will do the Flutter and Android build for you online.

## Manual APK build option

If you want to build it on your own laptop, install Flutter SDK and Android Studio, then run:

```bash
flutter create --platforms=android .
flutter pub get
flutter build apk --debug
```

The APK will be created at:

```text
build/app/outputs/flutter-apk/app-debug.apk
```

## Important note

The debug APK is okay for personal testing. Later, once the app is final, it should be built as a signed release APK or AAB for Play Store publishing.

## Future improvements

- Actual Android notification reminders
- Export DTR to Excel/PDF
- PIN lock
- Google Drive backup
- Google Calendar sync
- Duty checklist
- Custom ward/shift labels
