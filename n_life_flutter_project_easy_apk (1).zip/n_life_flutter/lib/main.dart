import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NLifeApp());
}

const Color kPrimary = Color(0xFF0B1F3A);
const Color kSecondary = Color(0xFF123B6D);
const Color kAccent = Color(0xFF2F80ED);
const Color kBackground = Color(0xFFF5F7FA);

class NLifeApp extends StatelessWidget {
  const NLifeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'N-Life',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kPrimary,
          primary: kPrimary,
          secondary: kAccent,
          surface: Colors.white,
        ),
        scaffoldBackgroundColor: kBackground,
        appBarTheme: const AppBarTheme(
          backgroundColor: kPrimary,
          foregroundColor: Colors.white,
          centerTitle: false,
          elevation: 0,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: kPrimary,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: kAccent, width: 1.5),
          ),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class DutyItem {
  DutyItem({
    required this.id,
    required this.date,
    required this.label,
    required this.startTime,
    required this.endTime,
    required this.ward,
    required this.notes,
    required this.reminderOn,
  });

  final String id;
  final DateTime date;
  final String label;
  final TimeOfDay startTime;
  final TimeOfDay endTime;
  final String ward;
  final String notes;
  final bool reminderOn;

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': DateFormat('yyyy-MM-dd').format(date),
        'label': label,
        'startHour': startTime.hour,
        'startMinute': startTime.minute,
        'endHour': endTime.hour,
        'endMinute': endTime.minute,
        'ward': ward,
        'notes': notes,
        'reminderOn': reminderOn,
      };

  factory DutyItem.fromJson(Map<String, dynamic> json) {
    return DutyItem(
      id: json['id'] as String,
      date: DateTime.parse(json['date'] as String),
      label: json['label'] as String,
      startTime: TimeOfDay(
        hour: json['startHour'] as int,
        minute: json['startMinute'] as int,
      ),
      endTime: TimeOfDay(
        hour: json['endHour'] as int,
        minute: json['endMinute'] as int,
      ),
      ward: json['ward'] as String,
      notes: json['notes'] as String,
      reminderOn: json['reminderOn'] as bool,
    );
  }
}

class DtrLog {
  DtrLog({
    required this.id,
    required this.date,
    this.timeIn,
    this.timeOut,
  });

  final String id;
  final DateTime date;
  DateTime? timeIn;
  DateTime? timeOut;

  double get hoursWorked {
    if (timeIn == null || timeOut == null) return 0;
    final diff = timeOut!.difference(timeIn!);
    if (diff.isNegative) return 0;
    return diff.inMinutes / 60.0;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': DateFormat('yyyy-MM-dd').format(date),
        'timeIn': timeIn?.toIso8601String(),
        'timeOut': timeOut?.toIso8601String(),
      };

  factory DtrLog.fromJson(Map<String, dynamic> json) {
    return DtrLog(
      id: json['id'] as String,
      date: DateTime.parse(json['date'] as String),
      timeIn: json['timeIn'] == null ? null : DateTime.parse(json['timeIn'] as String),
      timeOut: json['timeOut'] == null ? null : DateTime.parse(json['timeOut'] as String),
    );
  }
}

class AppState extends ChangeNotifier {
  List<DutyItem> duties = [];
  List<DtrLog> logs = [];
  double dailyRate = 1165;
  double requiredHours = 8;

  double get hourlyRate => requiredHours <= 0 ? 0 : dailyRate / requiredHours;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    dailyRate = prefs.getDouble('dailyRate') ?? 1165;
    requiredHours = prefs.getDouble('requiredHours') ?? 8;

    final dutyRaw = prefs.getStringList('duties') ?? [];
    duties = dutyRaw.map((e) => DutyItem.fromJson(jsonDecode(e) as Map<String, dynamic>)).toList();
    duties.sort((a, b) => a.date.compareTo(b.date));

    final logRaw = prefs.getStringList('logs') ?? [];
    logs = logRaw.map((e) => DtrLog.fromJson(jsonDecode(e) as Map<String, dynamic>)).toList();
    logs.sort((a, b) => b.date.compareTo(a.date));
    notifyListeners();
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('dailyRate', dailyRate);
    await prefs.setDouble('requiredHours', requiredHours);
    await prefs.setStringList('duties', duties.map((e) => jsonEncode(e.toJson())).toList());
    await prefs.setStringList('logs', logs.map((e) => jsonEncode(e.toJson())).toList());
  }

  Future<void> addDuty(DutyItem duty) async {
    duties.add(duty);
    duties.sort((a, b) => a.date.compareTo(b.date));
    await save();
    notifyListeners();
  }

  Future<void> deleteDuty(String id) async {
    duties.removeWhere((d) => d.id == id);
    await save();
    notifyListeners();
  }

  DutyItem? dutyForDate(DateTime date) {
    for (final duty in duties) {
      if (isSameDate(duty.date, date)) return duty;
    }
    return null;
  }

  DtrLog? logForDate(DateTime date) {
    for (final log in logs) {
      if (isSameDate(log.date, date)) return log;
    }
    return null;
  }

  Future<void> timeInNow() async {
    final now = DateTime.now();
    var log = logForDate(now);
    if (log == null) {
      log = DtrLog(id: now.microsecondsSinceEpoch.toString(), date: dateOnly(now), timeIn: now);
      logs.insert(0, log);
    } else {
      log.timeIn = now;
    }
    logs.sort((a, b) => b.date.compareTo(a.date));
    await save();
    notifyListeners();
  }

  Future<void> timeOutNow() async {
    final now = DateTime.now();
    var log = logForDate(now);
    if (log == null) {
      log = DtrLog(id: now.microsecondsSinceEpoch.toString(), date: dateOnly(now), timeOut: now);
      logs.insert(0, log);
    } else {
      log.timeOut = now;
    }
    logs.sort((a, b) => b.date.compareTo(a.date));
    await save();
    notifyListeners();
  }

  Future<void> addManualLog(DtrLog log) async {
    logs.removeWhere((e) => isSameDate(e.date, log.date));
    logs.add(log);
    logs.sort((a, b) => b.date.compareTo(a.date));
    await save();
    notifyListeners();
  }

  Future<void> deleteLog(String id) async {
    logs.removeWhere((l) => l.id == id);
    await save();
    notifyListeners();
  }

  Future<void> updateSettings({required double newDailyRate, required double newRequiredHours}) async {
    dailyRate = newDailyRate;
    requiredHours = newRequiredHours;
    await save();
    notifyListeners();
  }

  List<DtrLog> logsForCurrentCutoff() {
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day <= 15 ? 1 : 16);
    final end = today.day <= 15
        ? DateTime(today.year, today.month, 15, 23, 59, 59)
        : DateTime(today.year, today.month + 1, 0, 23, 59, 59);
    return logs.where((log) => !log.date.isBefore(start) && !log.date.isAfter(end)).toList();
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final AppState state = AppState();
  int selectedIndex = 0;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    state.load().then((_) => setState(() => isLoading = false));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(state: state),
      CalendarPage(state: state),
      DtrPage(state: state),
      SalaryPage(state: state),
      SettingsPage(state: state),
    ];

    return AnimatedBuilder(
      animation: state,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(
            title: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('N-Life', style: TextStyle(fontWeight: FontWeight.w800)),
                Text('Your Duty Companion', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w400)),
              ],
            ),
          ),
          body: isLoading ? const Center(child: CircularProgressIndicator()) : pages[selectedIndex],
          bottomNavigationBar: NavigationBar(
            selectedIndex: selectedIndex,
            onDestinationSelected: (i) => setState(() => selectedIndex = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
              NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Calendar'),
              NavigationDestination(icon: Icon(Icons.timer_outlined), selectedIcon: Icon(Icons.timer), label: 'DTR'),
              NavigationDestination(icon: Icon(Icons.payments_outlined), selectedIcon: Icon(Icons.payments), label: 'Salary'),
              NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
            ],
          ),
        );
      },
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    final today = DateTime.now();
    final duty = state.dutyForDate(today);
    final log = state.logForDate(today);
    final cutoffLogs = state.logsForCurrentCutoff();
    final totalCutoffHours = cutoffLogs.fold<double>(0, (sum, log) => sum + log.hoursWorked);
    final cutoffSalary = totalCutoffHours * state.hourlyRate;
    final todayPay = (log?.hoursWorked ?? 0) * state.hourlyRate;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(
          title: greeting(),
          subtitle: DateFormat('EEEE, MMMM d, yyyy').format(today),
          icon: Icons.local_hospital,
        ),
        const SizedBox(height: 14),
        SectionTitle(title: 'Today\'s Duty', actionText: null),
        DutySummaryCard(duty: duty),
        const SizedBox(height: 14),
        SectionTitle(title: 'DTR Today', actionText: null),
        NCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InfoRow(label: 'Time In', value: formatDateTime(log?.timeIn)),
              InfoRow(label: 'Time Out', value: formatDateTime(log?.timeOut)),
              InfoRow(label: 'Total Hours', value: '${(log?.hoursWorked ?? 0).toStringAsFixed(2)} hrs'),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () => state.timeInNow(),
                      icon: const Icon(Icons.login),
                      label: const Text('TIME IN'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => state.timeOutNow(),
                      icon: const Icon(Icons.logout),
                      label: const Text('TIME OUT'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SectionTitle(title: 'Salary Estimate', actionText: null),
        NCard(
          child: Column(
            children: [
              InfoRow(label: 'Today', value: peso(todayPay)),
              InfoRow(label: 'This Cut-off', value: peso(cutoffSalary)),
              InfoRow(label: 'Hourly Rate', value: '${peso(state.hourlyRate)} / hr'),
            ],
          ),
        ),
      ],
    );
  }
}

class CalendarPage extends StatelessWidget {
  const CalendarPage({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    final upcoming = state.duties.where((d) => !d.date.isBefore(dateOnly(DateTime.now()))).toList();
    final past = state.duties.where((d) => d.date.isBefore(dateOnly(DateTime.now()))).toList().reversed.toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(
          title: 'Duty Calendar',
          subtitle: 'Plan your shifts and duty areas.',
          icon: Icons.calendar_month,
        ),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: () => showDutyDialog(context, state),
          icon: const Icon(Icons.add),
          label: const Text('Add Duty'),
        ),
        const SizedBox(height: 18),
        SectionTitle(title: 'Upcoming Duties', actionText: null),
        if (upcoming.isEmpty)
          const EmptyCard(message: 'No upcoming duties yet. Tap Add Duty to create your schedule.'),
        ...upcoming.map((duty) => DutyTile(duty: duty, onDelete: () => state.deleteDuty(duty.id))),
        const SizedBox(height: 18),
        SectionTitle(title: 'Past Duties', actionText: null),
        if (past.isEmpty) const EmptyCard(message: 'No past duties recorded yet.'),
        ...past.map((duty) => DutyTile(duty: duty, onDelete: () => state.deleteDuty(duty.id))),
      ],
    );
  }
}

class DtrPage extends StatelessWidget {
  const DtrPage({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(
          title: 'DTR Tracker',
          subtitle: 'Record time in, time out, and total hours.',
          icon: Icons.timer,
        ),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: () => showManualLogDialog(context, state),
          icon: const Icon(Icons.edit_calendar),
          label: const Text('Add Manual DTR'),
        ),
        const SizedBox(height: 18),
        if (state.logs.isEmpty) const EmptyCard(message: 'No DTR logs yet.'),
        ...state.logs.map((log) => DtrTile(log: log, state: state)),
      ],
    );
  }
}

class SalaryPage extends StatelessWidget {
  const SalaryPage({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    final cutoffLogs = state.logsForCurrentCutoff();
    final totalHours = cutoffLogs.fold<double>(0, (sum, log) => sum + log.hoursWorked);
    final salary = totalHours * state.hourlyRate;
    final dutyDays = cutoffLogs.where((log) => log.hoursWorked > 0).length;
    final expectedHours = dutyDays * state.requiredHours;
    final overtime = totalHours > expectedHours ? totalHours - expectedHours : 0;
    final undertime = expectedHours > totalHours ? expectedHours - totalHours : 0;
    final today = DateTime.now();
    final cutOffText = today.day <= 15
        ? '${DateFormat('MMM d').format(DateTime(today.year, today.month, 1))} - ${DateFormat('MMM d').format(DateTime(today.year, today.month, 15))}'
        : '${DateFormat('MMM d').format(DateTime(today.year, today.month, 16))} - ${DateFormat('MMM d').format(DateTime(today.year, today.month + 1, 0))}';

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(
          title: 'Salary Summary',
          subtitle: '$cutOffText Cut-off',
          icon: Icons.payments,
        ),
        const SizedBox(height: 14),
        NCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Estimated Salary', style: TextStyle(fontSize: 14, color: Colors.black54)),
              const SizedBox(height: 6),
              Text(
                peso(salary),
                style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: kPrimary),
              ),
              const Divider(height: 28),
              InfoRow(label: 'Duty Days', value: dutyDays.toString()),
              InfoRow(label: 'Total Hours', value: '${totalHours.toStringAsFixed(2)} hrs'),
              InfoRow(label: 'Overtime', value: '${overtime.toStringAsFixed(2)} hrs'),
              InfoRow(label: 'Undertime', value: '${undertime.toStringAsFixed(2)} hrs'),
            ],
          ),
        ),
        const SizedBox(height: 18),
        SectionTitle(title: 'Breakdown', actionText: null),
        if (cutoffLogs.isEmpty) const EmptyCard(message: 'No logs for this cut-off yet.'),
        ...cutoffLogs.map(
          (log) => NCard(
            margin: const EdgeInsets.only(bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(DateFormat('MMM d, yyyy').format(log.date), style: const TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text('${log.hoursWorked.toStringAsFixed(2)} hrs', style: const TextStyle(color: Colors.black54)),
                  ],
                ),
                Text(peso(log.hoursWorked * state.hourlyRate), style: const TextStyle(fontWeight: FontWeight.w900, color: kPrimary)),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key, required this.state});

  final AppState state;

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late TextEditingController dailyRateController;
  late TextEditingController requiredHoursController;

  @override
  void initState() {
    super.initState();
    dailyRateController = TextEditingController(text: widget.state.dailyRate.toStringAsFixed(0));
    requiredHoursController = TextEditingController(text: widget.state.requiredHours.toStringAsFixed(0));
  }

  @override
  void dispose() {
    dailyRateController.dispose();
    requiredHoursController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        HeaderCard(
          title: 'Settings',
          subtitle: 'Customize salary and duty rules.',
          icon: Icons.settings,
        ),
        const SizedBox(height: 14),
        NCard(
          child: Column(
            children: [
              TextField(
                controller: dailyRateController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Daily Rate', prefixText: '₱ '),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: requiredHoursController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Required Hours per Duty'),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () async {
                  final dailyRate = double.tryParse(dailyRateController.text) ?? widget.state.dailyRate;
                  final requiredHours = double.tryParse(requiredHoursController.text) ?? widget.state.requiredHours;
                  await widget.state.updateSettings(newDailyRate: dailyRate, newRequiredHours: requiredHours);
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved.')));
                  }
                },
                icon: const Icon(Icons.save),
                label: const Text('Save Settings'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        NCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Current Rules', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              const SizedBox(height: 10),
              InfoRow(label: 'Hourly Rate', value: '${peso(widget.state.hourlyRate)} / hr'),
              const InfoRow(label: 'Cut-off', value: '1-15 / 16-End of Month'),
              const InfoRow(label: 'Theme', value: 'Dark Blue'),
            ],
          ),
        ),
        const SizedBox(height: 14),
        const EmptyCard(
          message: 'Reminder notification scheduling is prepared for the app plan, but needs Android notification setup in the next build.',
        ),
      ],
    );
  }
}

class HeaderCard extends StatelessWidget {
  const HeaderCard({super.key, required this.title, required this.subtitle, required this.icon});

  final String title;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [kPrimary, kSecondary]),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text(subtitle, style: const TextStyle(color: Colors.white70)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.13), shape: BoxShape.circle),
            child: Icon(icon, color: Colors.white, size: 30),
          ),
        ],
      ),
    );
  }
}

class NCard extends StatelessWidget {
  const NCard({super.key, required this.child, this.margin});

  final Widget child;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: margin,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: child,
      ),
    );
  }
}

class EmptyCard extends StatelessWidget {
  const EmptyCard({super.key, required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return NCard(
      margin: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline, color: kAccent),
          const SizedBox(width: 10),
          Expanded(child: Text(message, style: const TextStyle(color: Colors.black54))),
        ],
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({super.key, required this.title, this.actionText});

  final String title;
  final String? actionText;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: kPrimary))),
          if (actionText != null) Text(actionText!, style: const TextStyle(color: kAccent, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class InfoRow extends StatelessWidget {
  const InfoRow({super.key, required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: Colors.black54))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class DutySummaryCard extends StatelessWidget {
  const DutySummaryCard({super.key, required this.duty});

  final DutyItem? duty;

  @override
  Widget build(BuildContext context) {
    if (duty == null) {
      return const EmptyCard(message: 'No duty scheduled today.');
    }
    return NCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(duty!.ward.isEmpty ? duty!.label : duty!.ward, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: kPrimary)),
          const SizedBox(height: 6),
          Text(duty!.label, style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          InfoRow(label: 'Schedule', value: '${formatTime(duty!.startTime)} - ${formatTime(duty!.endTime)}'),
          InfoRow(label: 'Reminder', value: duty!.reminderOn ? 'ON' : 'OFF'),
          if (duty!.notes.trim().isNotEmpty) ...[
            const Divider(height: 24),
            Text(duty!.notes, style: const TextStyle(color: Colors.black87)),
          ],
        ],
      ),
    );
  }
}

class DutyTile extends StatelessWidget {
  const DutyTile({super.key, required this.duty, required this.onDelete});

  final DutyItem duty;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return NCard(
      margin: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Container(
            width: 58,
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(color: kPrimary.withOpacity(0.08), borderRadius: BorderRadius.circular(14)),
            child: Column(
              children: [
                Text(DateFormat('MMM').format(duty.date).toUpperCase(), style: const TextStyle(fontSize: 11, color: kPrimary, fontWeight: FontWeight.w900)),
                Text(DateFormat('d').format(duty.date), style: const TextStyle(fontSize: 22, color: kPrimary, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(duty.ward.isEmpty ? duty.label : duty.ward, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 4),
                Text('${duty.label} • ${formatTime(duty.startTime)} - ${formatTime(duty.endTime)}', style: const TextStyle(color: Colors.black54)),
                if (duty.reminderOn) const Text('Reminder ON', style: TextStyle(color: kAccent, fontWeight: FontWeight.w700, fontSize: 12)),
              ],
            ),
          ),
          IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_outline, color: Colors.redAccent)),
        ],
      ),
    );
  }
}

class DtrTile extends StatelessWidget {
  const DtrTile({super.key, required this.log, required this.state});

  final DtrLog log;
  final AppState state;

  @override
  Widget build(BuildContext context) {
    return NCard(
      margin: const EdgeInsets.only(bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(DateFormat('EEEE, MMM d, yyyy').format(log.date), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
              ),
              IconButton(onPressed: () => state.deleteLog(log.id), icon: const Icon(Icons.delete_outline, color: Colors.redAccent)),
            ],
          ),
          InfoRow(label: 'Time In', value: formatDateTime(log.timeIn)),
          InfoRow(label: 'Time Out', value: formatDateTime(log.timeOut)),
          InfoRow(label: 'Total Hours', value: '${log.hoursWorked.toStringAsFixed(2)} hrs'),
          InfoRow(label: 'Estimated Pay', value: peso(log.hoursWorked * state.hourlyRate)),
        ],
      ),
    );
  }
}

Future<void> showDutyDialog(BuildContext context, AppState state) async {
  DateTime selectedDate = DateTime.now();
  TimeOfDay start = const TimeOfDay(hour: 6, minute: 0);
  TimeOfDay end = const TimeOfDay(hour: 14, minute: 0);
  bool reminder = true;
  final labelController = TextEditingController(text: 'AM Duty');
  final wardController = TextEditingController();
  final notesController = TextEditingController();

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) {
      return StatefulBuilder(
        builder: (context, setSheetState) {
          return Container(
            padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 16,
              bottom: MediaQuery.of(context).viewInsets.bottom + 16,
            ),
            decoration: const BoxDecoration(
              color: kBackground,
              borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Add Duty', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: kPrimary)),
                  const SizedBox(height: 16),
                  TextField(controller: labelController, decoration: const InputDecoration(labelText: 'Shift Label')),
                  const SizedBox(height: 12),
                  TextField(controller: wardController, decoration: const InputDecoration(labelText: 'Ward / Area')),
                  const SizedBox(height: 12),
                  ListTile(
                    tileColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    title: const Text('Date'),
                    subtitle: Text(DateFormat('MMMM d, yyyy').format(selectedDate)),
                    trailing: const Icon(Icons.calendar_month),
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: selectedDate,
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2035),
                      );
                      if (picked != null) setSheetState(() => selectedDate = picked);
                    },
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () async {
                            final picked = await showTimePicker(context: context, initialTime: start);
                            if (picked != null) setSheetState(() => start = picked);
                          },
                          icon: const Icon(Icons.schedule),
                          label: Text('Start ${formatTime(start)}'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () async {
                            final picked = await showTimePicker(context: context, initialTime: end);
                            if (picked != null) setSheetState(() => end = picked);
                          },
                          icon: const Icon(Icons.schedule),
                          label: Text('End ${formatTime(end)}'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SwitchListTile(
                    tileColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    title: const Text('Reminder'),
                    subtitle: const Text('Reminder setting for this duty'),
                    value: reminder,
                    onChanged: (value) => setSheetState(() => reminder = value),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: notesController,
                    decoration: const InputDecoration(labelText: 'Notes'),
                    minLines: 2,
                    maxLines: 4,
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: () async {
                        await state.addDuty(
                          DutyItem(
                            id: DateTime.now().microsecondsSinceEpoch.toString(),
                            date: dateOnly(selectedDate),
                            label: labelController.text.trim().isEmpty ? 'Duty' : labelController.text.trim(),
                            startTime: start,
                            endTime: end,
                            ward: wardController.text.trim(),
                            notes: notesController.text.trim(),
                            reminderOn: reminder,
                          ),
                        );
                        if (context.mounted) Navigator.pop(context);
                      },
                      icon: const Icon(Icons.save),
                      label: const Text('Save Duty'),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}

Future<void> showManualLogDialog(BuildContext context, AppState state) async {
  DateTime selectedDate = DateTime.now();
  TimeOfDay timeIn = const TimeOfDay(hour: 6, minute: 0);
  TimeOfDay timeOut = const TimeOfDay(hour: 14, minute: 0);

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) {
      return StatefulBuilder(
        builder: (context, setSheetState) {
          return Container(
            padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 16,
              bottom: MediaQuery.of(context).viewInsets.bottom + 16,
            ),
            decoration: const BoxDecoration(
              color: kBackground,
              borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Add Manual DTR', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: kPrimary)),
                const SizedBox(height: 16),
                ListTile(
                  tileColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  title: const Text('Date'),
                  subtitle: Text(DateFormat('MMMM d, yyyy').format(selectedDate)),
                  trailing: const Icon(Icons.calendar_month),
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: selectedDate,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2035),
                    );
                    if (picked != null) setSheetState(() => selectedDate = picked);
                  },
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final picked = await showTimePicker(context: context, initialTime: timeIn);
                          if (picked != null) setSheetState(() => timeIn = picked);
                        },
                        icon: const Icon(Icons.login),
                        label: Text('In ${formatTime(timeIn)}'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final picked = await showTimePicker(context: context, initialTime: timeOut);
                          if (picked != null) setSheetState(() => timeOut = picked);
                        },
                        icon: const Icon(Icons.logout),
                        label: Text('Out ${formatTime(timeOut)}'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () async {
                      final date = dateOnly(selectedDate);
                      final inDate = DateTime(date.year, date.month, date.day, timeIn.hour, timeIn.minute);
                      final outDate = DateTime(date.year, date.month, date.day, timeOut.hour, timeOut.minute);
                      await state.addManualLog(
                        DtrLog(
                          id: DateTime.now().microsecondsSinceEpoch.toString(),
                          date: date,
                          timeIn: inDate,
                          timeOut: outDate,
                        ),
                      );
                      if (context.mounted) Navigator.pop(context);
                    },
                    icon: const Icon(Icons.save),
                    label: const Text('Save DTR'),
                  ),
                ),
              ],
            ),
          );
        },
      );
    },
  );
}

bool isSameDate(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

DateTime dateOnly(DateTime date) => DateTime(date.year, date.month, date.day);

String formatTime(TimeOfDay time) {
  final hour = time.hourOfPeriod == 0 ? 12 : time.hourOfPeriod;
  final minute = time.minute.toString().padLeft(2, '0');
  final period = time.period == DayPeriod.am ? 'AM' : 'PM';
  return '$hour:$minute $period';
}

String formatDateTime(DateTime? date) {
  if (date == null) return '--';
  return DateFormat('h:mm a').format(date);
}

String peso(double value) {
  final formatter = NumberFormat.currency(locale: 'en_PH', symbol: '₱', decimalDigits: 2);
  return formatter.format(value);
}

String greeting() {
  final hour = DateTime.now().hour;
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}
