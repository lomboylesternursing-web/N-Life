N-Life v1.3.1 Restore + DTR Time Edit Fix
- Restore backup is more tolerant and should not crash on minor paste/format issues.
- Added separate edit button for Time In and Time Out on DTR logs.
