# N-Life v1.0 Print Patch

Launch build with color patch plus DTR action update.

## Added
- Print DTR button beside View PDF in the DTR Sheet page.
- Version bumped to 1.0.8+8.

## Kept
- Light theme default
- Color-coded duty calendar
- DTR Sheet preview
- PDF export
- Fast Add Duty
- Official N-Life logo/assets
