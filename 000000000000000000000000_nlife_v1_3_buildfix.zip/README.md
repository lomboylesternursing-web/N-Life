# N-Life v1.3 Build Fix

Fixes missing DtrPeriod enum build error from the previous v1.3 package.
Keeps notification/widget native files and calendar-style Fast Add.
