# N-Life v1.6.2 — Compile Fix

This patch only fixes the `HeaderCard` constructor mismatch that prevented v1.6.1 from compiling.

- Restores the required named parameter `title`.
- Preserves the locked DTR layout and approved SPMS layout from v1.6.1.
- Bumps the app version to 1.6.2+162.
- No DTR/SPMS visual or calculation changes are introduced by this patch.
