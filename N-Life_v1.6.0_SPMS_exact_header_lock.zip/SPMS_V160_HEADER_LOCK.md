# N-Life v1.6.0 SPMS Header Lock

- First-page SPMS header uses an exact crop from the uploaded original SPMS PDF.
- Official provincial seal/banner, hospital name, SPMS title, and Monitoring Form spacing are preserved as one image.
- Dynamic text is limited to Individual Accomplishment period/date and table data.
- Continuation pages retain the shorter official hospital header.
- Letter landscape output remains unchanged.
