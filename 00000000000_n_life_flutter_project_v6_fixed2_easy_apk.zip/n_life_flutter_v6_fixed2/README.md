# N-Life v6 Fixed 2

Fixes:
- Fast Add crash when applying 3 or more dates.
- Delays state rebuild after dialog closes to avoid Flutter inherited-widget assertion.
- Keeps v6 features: light theme default, dark mode text fixes, Tomorrow's Duty, color-coded calendar, View PDF, Copy Summary, PDF salary format using PHP.

Build with GitHub Actions by uploading this ZIP and running the existing APK builder.
