N-Life v1.5.9 SPMS text/alignment revision
- Added safe bottom padding to the static SPMS title image so the final “p” in “Accomplishment” is not clipped.
- Prepared-by position is fixed to NURSE I.
- Nurse name and NURSE I are centered under the signature line.
- OIC name and OIC-Chief of Hospital I are centered under the noted-by signature line.
- No other SPMS or DTR layout changes.
