# N-Life v1.5.4 – SPMS Source-Template Update

This build uses the previously supplied San Miguel District Hospital SPMS PDF as the visual source for:
- US Letter landscape page size
- hospital header, watermark, building illustration, and footer
- page/table proportions and typography hierarchy
- five dynamic accomplishment pages for a 15-day cutoff (depending on Duty Calendar data)
- a dedicated Prepared by / Noted by signature page

Dynamic fields:
- cutoff/month dates
- Duty Calendar day and OFF status
- patient quantity per duty date
- editable nurse name and position

Also included:
- Civil Service Form No. 48 print-height adjustment for long bond paper
- version 1.5.4+154
