package com.example.n_life

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
  override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
    super.configureFlutterEngine(flutterEngine)
    MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "nlife/widget").setMethodCallHandler { call, result ->
      when (call.method) {
        "updateWidget" -> {
          NLifeWidgetProvider.updateAllWidgets(this)
          result.success(true)
        }
        "requestNotificationPermission" -> {
          requestNotificationPermissionIfNeeded()
          result.success(true)
        }
        "scheduleDutyNotifications" -> {
          val args = call.arguments as? Map<*, *>
          val items = args?.get("items") as? List<*>
          scheduleDutyNotifications(items ?: emptyList<Any>())
          result.success(true)
        }
        "showTestNotification" -> {
          sendTestNotification()
          result.success(true)
        }
        "pinWidget" -> {
          pinWidgetIfSupported()
          result.success(true)
        }
        else -> result.notImplemented()
      }
    }
  }

  private fun requestNotificationPermissionIfNeeded() {
    NLifeReminderReceiver.createNotificationChannel(this)
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1301)
    }
  }

  private fun sendTestNotification() {
    val intent = Intent(this, NLifeReminderReceiver::class.java).apply {
      putExtra("title", "N-Life Test Notification")
      putExtra("body", "Notifications are working for N-Life.")
      putExtra("id", 20260711)
    }
    sendBroadcast(intent)
  }

  private fun pinWidgetIfSupported() {
    if (Build.VERSION.SDK_INT >= 26) {
      val manager = getSystemService(AppWidgetManager::class.java)
      val provider = ComponentName(this, NLifeWidgetProvider::class.java)
      if (manager != null && manager.isRequestPinAppWidgetSupported) {
        manager.requestPinAppWidget(provider, null, null)
      }
    }
  }

  private fun scheduleDutyNotifications(rawItems: List<*>) {
    NLifeReminderReceiver.createNotificationChannel(this)
    val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val prefs = getSharedPreferences("nlife_native_reminders", Context.MODE_PRIVATE)

    val oldIds = prefs.getStringSet("ids", emptySet()) ?: emptySet()
    for (oldId in oldIds) {
      val requestCode = oldId.toIntOrNull() ?: continue
      val cancelIntent = Intent(this, NLifeReminderReceiver::class.java)
      val pending = PendingIntent.getBroadcast(this, requestCode, cancelIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
      alarmManager.cancel(pending)
    }

    val newIds = mutableSetOf<String>()
    for (item in rawItems) {
      val map = item as? Map<*, *> ?: continue
      val id = (map["id"] as? Number)?.toInt() ?: continue
      val triggerMillis = (map["triggerMillis"] as? Number)?.toLong() ?: continue
      if (triggerMillis <= System.currentTimeMillis()) continue
      val title = map["title"] as? String ?: "N-Life Duty Reminder"
      val body = map["body"] as? String ?: "You have scheduled duty today."

      val intent = Intent(this, NLifeReminderReceiver::class.java).apply {
        putExtra("title", title)
        putExtra("body", body)
        putExtra("id", id)
      }
      val pendingIntent = PendingIntent.getBroadcast(this, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
      alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
      newIds.add(id.toString())
    }
    prefs.edit().putStringSet("ids", newIds).apply()
  }
}
