package com.example.n_life

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

class NLifeReminderReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      return
    }
    createNotificationChannel(context)
    val title = intent.getStringExtra("title") ?: "N-Life Duty Reminder"
    val body = intent.getStringExtra("body") ?: "You have scheduled duty today."
    val id = intent.getIntExtra("id", System.currentTimeMillis().toInt())

    val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
    val contentIntent = if (launchIntent != null) {
      PendingIntent.getActivity(context, id, launchIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    } else null

    val builder = if (Build.VERSION.SDK_INT >= 26) {
      android.app.Notification.Builder(context, CHANNEL_ID)
    } else {
      android.app.Notification.Builder(context)
    }
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentTitle(title)
      .setContentText(body)
      .setStyle(android.app.Notification.BigTextStyle().bigText(body))
      .setAutoCancel(true)
      .setPriority(android.app.Notification.PRIORITY_HIGH)

    if (contentIntent != null) builder.setContentIntent(contentIntent)

    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    manager.notify(id, builder.build())
  }

  companion object {
    const val CHANNEL_ID = "nlife_duty_reminders"

    fun createNotificationChannel(context: Context) {
      if (Build.VERSION.SDK_INT >= 26) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val existing = manager.getNotificationChannel(CHANNEL_ID)
        if (existing == null) {
          val channel = NotificationChannel(CHANNEL_ID, "N-Life Duty Reminders", NotificationManager.IMPORTANCE_HIGH)
          channel.description = "Duty reminders for today and upcoming shifts."
          manager.createNotificationChannel(channel)
        }
      }
    }
  }
}
