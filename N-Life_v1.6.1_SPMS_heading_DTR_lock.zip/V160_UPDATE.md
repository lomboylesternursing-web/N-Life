# N-Life v1.6.0

## Locked CS Form No. 48 layout
- Portrait long bond paper (8.5 x 13 inches)
- Two identical forms centered independently in the left and right halves
- 2-inch top margin and approximately 3.5-inch bottom reserve
- Day 31 has its own complete row; Total is a separate row below
- Larger regular-weight names and time entries
- Thicker A.M./P.M./Undertime group dividers
- Full certification statement
- No printed signatures
- Editable nurse name; top line excludes RN, lower certification line adds RN
- NURSE I and fixed OIC details centered

## SPMS source-fidelity correction
- Letter/short-bond landscape retained
- Original hospital header asset retained at its correct aspect ratio
- First-page title block moved to the source PDF's vertical position
- Transparent title asset preserves the watermark/backdrop behind the headings
- Dynamic period line remains editable and underlined
- First-page table starts and fills at the source PDF proportions
- Continuation pages, footer, watermark, building illustration, and signature page remain unchanged
