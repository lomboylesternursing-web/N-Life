# N-Life v1.6.1

- SPMS: separated first-page subheadings to prevent overlap.
- SPMS: Monitoring Form, Individual Accomplishment, and For the week are regular weight.
- DTR: locked two centered forms on portrait long bond, Day 31 has a full row, and Total is separate.
- DTR: enlarged regular-weight names and time entries; thicker A.M./P.M./Undertime dividers.
- DTR: full certification statement, no printed signatures, 2-inch top margin and large bottom blank area.
