# N-Life v6 Color Fix

Color coding update only. Duty tab colors are now more distinct:

- AM: Blue
- PM: Red
- Graveyard: Night black
- 12H AM: Orange
- 12H PM: Cyan/teal
- OFF: Gray
- Leave: Green
- Manual: Purple

Keeps all v6 fixed2 functionality.


## N-Life v1.0 Color Patch
- AM: Sky Blue
- PM: Red
- Graveyard: Deep Purple
- 12H AM: Orange
- 12H PM: Teal
- OFF: Slate Gray
- Leave: Green
- Manual: Purple
