# N-Life v1.0 Hourly Rate + DTR View Fix

Launch package update.

Included changes:
- Added Salary Rate Mode in Settings: Daily Rate or Hourly Rate.
- When Hourly Rate is selected, Daily Rate field is disabled.
- When Daily Rate is selected, Hourly Rate field is disabled and computed from Daily Rate / Required Hours.
- Salary/DTR summary now shows Rate Mode and Hourly Rate Used.
- Changed DTR View button behavior: View DTR now opens a full-screen in-app preview.
- Full-screen DTR preview supports pinch zoom and drag/pan.
- Print DTR remains dedicated for Android print/share dialog.
- Keeps previous fixes: Fast Add Notes stability, Print DTR, color patch, light theme default, DTR sheet preview, and PDF export.

Build with GitHub Actions as before.
