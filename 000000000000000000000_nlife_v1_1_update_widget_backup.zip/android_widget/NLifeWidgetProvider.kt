package com.example.n_life

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews

class NLifeWidgetProvider : AppWidgetProvider() {
  override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
    for (appWidgetId in appWidgetIds) {
      updateAppWidget(context, appWidgetManager, appWidgetId)
    }
  }

  companion object {
    fun updateAllWidgets(context: Context) {
      val manager = AppWidgetManager.getInstance(context)
      val ids = manager.getAppWidgetIds(ComponentName(context, NLifeWidgetProvider::class.java))
      for (id in ids) updateAppWidget(context, manager, id)
    }

    private fun readPref(context: Context, key: String, fallback: String): String {
      val prefs = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
      return prefs.getString("flutter.$key", fallback) ?: fallback
    }

    fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
      val views = RemoteViews(context.packageName, R.layout.nlife_widget)
      val todayTitle = readPref(context, "widget_today_title", "Today")
      val todayDate = readPref(context, "widget_today_date", "Open N-Life")
      val todayValue = readPref(context, "widget_today_value", "No scheduled duty")
      val tomorrowTitle = readPref(context, "widget_tomorrow_title", "Tomorrow")
      val tomorrowDate = readPref(context, "widget_tomorrow_date", "")
      val tomorrowValue = readPref(context, "widget_tomorrow_value", "No scheduled duty")
      val updated = readPref(context, "widget_updated", "")

      views.setTextViewText(R.id.widget_today_title, todayTitle)
      views.setTextViewText(R.id.widget_today_date, todayDate)
      views.setTextViewText(R.id.widget_today_value, todayValue)
      views.setTextViewText(R.id.widget_tomorrow_title, tomorrowTitle)
      views.setTextViewText(R.id.widget_tomorrow_date, tomorrowDate)
      views.setTextViewText(R.id.widget_tomorrow_value, tomorrowValue)
      views.setTextViewText(R.id.widget_updated, if (updated.isNotBlank()) "Updated $updated" else "Tap to open N-Life")

      val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
      if (launchIntent != null) {
        val pendingIntent = PendingIntent.getActivity(
          context,
          0,
          launchIntent,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
      }

      appWidgetManager.updateAppWidget(appWidgetId, views)
    }
  }
}
