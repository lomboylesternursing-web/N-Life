package com.example.n_life

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
  override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
    super.configureFlutterEngine(flutterEngine)
    MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "nlife/widget").setMethodCallHandler { call, result ->
      if (call.method == "updateWidget") {
        NLifeWidgetProvider.updateAllWidgets(this)
        result.success(true)
      } else {
        result.notImplemented()
      }
    }
  }
}
