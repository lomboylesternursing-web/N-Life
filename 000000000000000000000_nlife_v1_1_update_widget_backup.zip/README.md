# N-Life v1.1 Update Package

N-Life is a personal hospital duty companion app for duty scheduling, DTR tracking, salary estimates, PDF/print export, and calendar views.

## v1.1 additions

- Android home-screen widget for Today’s Duty and Tomorrow’s Duty.
- Widget refresh button in Settings.
- Backup / Restore using copy-paste backup text.
- Version updated to v1.1.
- Keeps v1.0 stable features:
  - Graphic Duty Calendar export
  - Save Calendar as PNG
  - Print DTR and Print Calendar
  - Daily Rate / Hourly Rate mode
  - Default daily rate PHP 1,165.46

## Build via GitHub Actions

Upload this ZIP to your repository, then run **Actions > Build N-Life Android APK > Run workflow**.

The artifact will be named **N-Life-v1.1-update-apk**.

## Important update note

Try installing the v1.1 APK directly over your current N-Life app first. If Android accepts it, your duty schedules and DTR data will remain.

If Android says the app cannot be installed because of signature mismatch, that means the older APK was signed with a different temporary debug key from a previous GitHub build. From this v1.1 package onward, a fixed debug signing key is included so future updates can be smoother.
