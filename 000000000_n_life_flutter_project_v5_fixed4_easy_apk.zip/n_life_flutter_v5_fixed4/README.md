# N-Life v5 Fixed 4

Fixes:
- PDF Estimated Salary now uses `PHP` instead of peso symbol to avoid missing-glyph square boxes in generated PDFs.
- Keeps v5 fixed3 Fast Add crash fix, DTR day column, dark mode readability improvements, 12H duty label fixes, and official logo assets.

Build through the existing GitHub Actions workflow by uploading the ZIP to the repository root.
