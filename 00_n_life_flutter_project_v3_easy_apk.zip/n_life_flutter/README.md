# N-Life Flutter Android App

N-Life is a dark-blue Android hospital duty companion app for personal duty scheduling, DTR tracking, and salary estimation.

## Version

v3 prototype

## Developer Credit

Developed by Lester Andrei Lomboy, RN

## Current features

- Splash screen with N + heartbeat logo
- Tagline: Your Duty Companion
- Developer credit on app opening screen
- In-app N-Life logo and About section
- Home dashboard
- One-tap Time In / Time Out
- Automatic date and time logging
- Night-shift friendly Time Out support
- Duty calendar list
- Manual DTR entry
- DTR Summary for current cut-off
- OFF display for days without DTR logs
- Copy DTR Summary text
- Salary summary based on daily rate and required hours
- 12-hour duty credit computation using 8 hours = 1 day
- Offline local storage using SharedPreferences
- Dark blue professional theme

## Notes

This is a prototype/debug APK project for personal testing. Android may show an "Install anyway" or risky app warning because the APK is manually installed and not yet published through Google Play.

## Build APK with GitHub Actions

Upload this ZIP to your GitHub repository and run the workflow named `Build N-Life Android APK`.

The APK will appear as an artifact named:

`N-Life-debug-apk`

Inside it, install:

`app-debug.apk`

## Local build commands

```bash
flutter create --platforms=android .
flutter pub get
flutter build apk --debug
```
